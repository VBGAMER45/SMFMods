*******************************
New Topic Button
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x , SMF 2.0.x, SMF 1.1.x and SMF 1.0.x

Addeds a new topic button on viewing a topic.
Works for default theme only!



Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Trader System
SMF Archive
SMF Staff
SMF Links
SMF Store
SMF Classifieds
Newsletter Pro
EzPortal

SMFHacks package server address is:
http://www.smfhacks.com