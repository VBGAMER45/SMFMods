*******************************
Tagging System
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x And SMF 1.1.x

A tagging system for SMF.
Features:
Tag Cloud
Tagging of Topics
Thread owner can add and remove tags to the topic.
Tag Admins can tag topics and remove tags.
Clicking a tag returns a list of tagged topics that have that tag.

Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Newsletter Pro
Download System Pro
EzPortal
Ad Seller Pro
Social Login Pro


SMFHacks package server address is:
http://www.smfhacks.com