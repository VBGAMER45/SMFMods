*******************************
Signature Option on Posting
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x, SMF 2.0.x SMF 1.1.x

Adds a checkbox if you want to show your signature on a post or not.
Alters the message table adds a field for showing the signature



Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Downloads System Pro
Newsletter Pro
EzPortal


SMFHacks package server address is:
http://www.smfhacks.com