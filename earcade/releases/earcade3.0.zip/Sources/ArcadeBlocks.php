<?php
/************************************************************************************
* E Arcade 3.0 (http://www.smfhacks.com)                                            *
* Copyright (C) 2014  http://www.smfhacks.com                                       *
* Copyright (C) 2007  Eric Lawson (http://www.ericsworld.eu)                        *
* based on the original SMFArcade mod by Nico - http://www.smfarcade.info/          *                                                                           *
*************************************************************************************
* This program is free software; you can redistribute it and/or modify         *
* it under the terms of the GNU General Public License as published by         *
* the Free Software Foundation; either version 2 of the License, or            *
* (at your option) any later version.                                          *
*                                                                              *
* This program is distributed in the hope that it will be useful,              *
* but WITHOUT ANY WARRANTY; without even the implied warranty of               *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                *
* GNU General Public License for more details.                                 *
*                                                                              *
* You should have received a copy of the GNU General Public License            *
* along with this program; if not, write to the Free Software                  *
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *
********************************************************************************
ArcadeBlocks.php

This file contains functions for the top info blocks
********************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

function ArcadeQuickSearchBlock()
{
	global $txt, $context, $scripturl;

	echo '
	<tr>
		<td align="right">
			<form action="', $scripturl, '?action=arcade" onsubmit="ArcadeQuickSearch(); return false;" method="post">
				<input id="quick_name" type="text" value="" name="name[', rand(0, 1000), ']" onkeyup="ArcadeQuickSearch();" />
			</form>
		</td>
		<td align="center" width="275">
			<div id="quick_div" class="smalltext">', $txt['arcade_quick_search'], '</div>
		</td>
		<td align="left">
			<script type="text/javascript">
			function go()
			{
			location = document.cmform.gowhere.value;
			}
			</script>
			<form name="cmform" action="">
				<select id="gowhere" onchange="go()">
					<option>',$txt['arcade_list_games'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=name;">',$txt['arcade_nameAZ'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=name;desc=DESC">',$txt['arcade_nameZA'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=id;desc=DESC">',$txt['arcade_LatestList'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=plays;desc=DESC">',$txt['arcade_g_i_b_3'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=champs;desc=DESC">',$txt['arcade_g_i_b_8'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=plays">',$txt['arcade_LeastPlayed'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=category">',$txt['arcade_category'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=rating;desc=DESC">',$txt['arcade_rating_sort'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=myscore;desc=DESC">',$txt['arcade_personal_best'],'</option>
					<option value="',$scripturl,'?action=arcade;sort=champion">',$txt['arcade_champion'],'</option>
				</select>
			</form>
		</td>
	</tr>';
}

function ArcadeUserBlock()
{
	global $context, $txt, $user_info, $scripturl, $settings, $arcSettings;

	echo'
	<div align="center">
	<table width="100%" border="0" cellpadding="1">
		<tr>
			<td colspan="2"><div align="center"><span><i><b>',$txt['arcade_u_b_1'],' ',$context['user']['name'],'</b></i></span></div></td>
		</tr>
		<tr>
			<td height="155px"><div align="center"> ';
				if (isset($context['user']['avatar']['image']))
				{
					echo  $context['user']['avatar']['image'];
				}
				else
				{
					echo' <img border="0" src="',$settings['images_url'],'/icons/online.gif" alt="ico" width="50" height="50" title="Default Avatar"/>';
				}
				echo'<br />';
				echo'<br /><div class="smalltext"><a href="',$scripturl,'?action=arcade;favorites"><img border="0" src="',$settings['images_url'],'/arc_icons/arcade_cat1.gif" alt="ico" width="15" height="15" title="Show favs"/> ',$txt['arcade_u_b_2'],'
				<img border="0" src="',$settings['images_url'],'/arc_icons/arcade_cat1.gif" alt="ico" width="15" height="15" title="Show favs"/></a>
				</div></div>
			</td>
		</tr>
		<tr>
			<td colspan="2" class="smalltext"><div align="center">',sprintf($txt['arcade_game_we_have_games'], $arcSettings['arcade_total_games']),'</div></td>
		</tr>';
		if ((!$user_info['is_guest'] && $arcSettings['enable_shout_box_members']==1)||$context['arcade']['can_admin'])
		{
		echo'
		<tr>
		 <td>
       <form accept-charset="', $context['character_set'], '" class="smalltext" style="padding: 0; margin: 0; margin-top: 5px; text-align: center;" name="arcade_shout" action="'.$scripturl.'?action=arcade;sa=shout" method="post">
				<textarea class="smalltext" name="the_shout" style="width: 80%;margin-top: 1ex; height: 25px;" wrap="auto"></textarea><br />
         <input style="margin-top: 4px;" class="smalltext" type="submit" name="shout" value="'.$txt['arcade_shout'].'">
       </form>
      </td>
     </tr>';
    }
    echo'
	</table>
	</div>';
}



function ArcadeInfoPanelBlock()
{
	global $context, $txt, $arcSettings, $scripturl;

$no = 5;
	echo'
	<table width="100%" border="0" cellpadding="1">
		<tr>
			<td colspan="2"><div align="center"><span><i><b>',$txt['arcade_info'],'</b></i></span></div></td>
		</tr>
		<tr>
			<td><span class="middletext">';

			echo'
	<script type="text/javascript">
		var pausecontent=new Array()
		';
	if ($arcSettings['enable_arcade_cache']==1)
	{
		ob_start();
		if (!$cache3Best = readCache('arcadeinfopanel.cache', 86400))
		{
			echo 'pausecontent[0]="',addslashes(ArcadeInfoBestPlayers($no)),'";
			';
			echo 'pausecontent[1]="',addslashes(ArcadeInfoNewestGames($no)),'";
			';
			echo 'pausecontent[2]="',addslashes(Arcade3champsBlock($no)),'";
			';
			echo 'pausecontent[3]="',addslashes(ArcadeInfoMostPlayed($no)),'";
			';
			echo 'pausecontent[4]="',addslashes(ArcadeInfoLongestChamps($no)),'";
			';
			$cache3Best = ob_get_contents();
			ob_clean();
			writeCache($cache3Best,'arcadeinfopanel.cache');
			ob_end_clean();
		}
		echo $cache3Best;

		ob_start();
		if (!$cacheGotd = readCache('gotd.cache', 86400))
		{
			echo 'pausecontent[5]="',addslashes(ArcadeGOTDBlock()),'";
			';
			$cacheGotd = ob_get_contents();
			ob_clean();
			writeCache($cacheGotd,'gotd.cache');
			ob_end_clean();
		}
		echo $cacheGotd;
	}
	else
	{
		echo 'pausecontent[0]="',addslashes(ArcadeInfoBestPlayers($no)),'";
			';
			echo 'pausecontent[1]="',addslashes(ArcadeInfoNewestGames($no)),'";
			';
			echo 'pausecontent[2]="',addslashes(Arcade3champsBlock($no)),'";
			';
			echo 'pausecontent[3]="',addslashes(ArcadeInfoMostPlayed($no)),'";
			';
			echo 'pausecontent[4]="',addslashes(ArcadeInfoLongestChamps($no)),'";
			';
			echo 'pausecontent[5]="',addslashes(ArcadeGOTDBlock()),'";
			';
	}
	echo 'pausecontent[6]="',addslashes(ArcadeRandomGameBlock()),'";
	';

	echo'</script>
	<style type="text/css">
	#pescroller1{
	height: 220px;
	border: 0px solid black;
	padding: 5px;
	}

	.someclass{ //class to apply to your escroller(s) if desired
	}

	</style>
	<script type="text/javascript">

	/***********************************************
	* Pausing up-down escroller- � Dynamic Drive (www.dynamicdrive.com)
	* This notice MUST stay intact for legal use
	* Visit http://www.dynamicdrive.com/ for this script and 100s more.
	***********************************************/

	function pauseescroller(content, divId, divClass, delay){
	this.content=content //message array content
	this.tickerid=divId //ID of ticker div to display information
	this.delay=delay //Delay between msg change, in miliseconds.
	this.mouseoverBol=0 //Boolean to indicate whether mouse is currently over escroller (and pause it if it is)
	this.hiddendivpointer=1 //index of message array for hidden div
	document.write(\'<div id="\'+divId+\'" class="\'+divClass+\'" style="position: relative; overflow: hidden"><div class="innerDiv" style="position: absolute; width: 100%" id="\'+divId+\'1">\'+content[0]+\'</div><div class="innerDiv" style="position: absolute; width: 100%; visibility: hidden" id="\'+divId+\'2">\'+content[1]+\'</div></div>\')
	var escrollerinstance=this
	if (window.addEventListener) //run onload in DOM2 browsers
	window.addEventListener("load", function(){escrollerinstance.initialize()}, false)
	else if (window.attachEvent) //run onload in IE5.5+
	window.attachEvent("onload", function(){escrollerinstance.initialize()})
	else if (document.getElementById) //if legacy DOM browsers, just start escroller after 0.5 sec
	setTimeout(function(){escrollerinstance.initialize()}, 500)
	}
	// -------------------------------------------------------------------
	// initialize()- Initialize escroller method.
	// -Get div objects, set initial positions, start up down animation
	// -------------------------------------------------------------------

	pauseescroller.prototype.initialize=function(){
	this.tickerdiv=document.getElementById(this.tickerid)
	this.visiblediv=document.getElementById(this.tickerid+"1")
	this.hiddendiv=document.getElementById(this.tickerid+"2")
	this.visibledivtop=parseInt(pauseescroller.getCSSpadding(this.tickerdiv))

	this.visiblediv.style.width=this.hiddendiv.style.width=this.tickerdiv.offsetWidth-(this.visibledivtop*2)+"px"
	this.getinline(this.visiblediv, this.hiddendiv)
	this.hiddendiv.style.visibility="visible"
	var escrollerinstance=this
	document.getElementById(this.tickerid).onmouseover=function(){escrollerinstance.mouseoverBol=1}
	document.getElementById(this.tickerid).onmouseout=function(){escrollerinstance.mouseoverBol=0}
	if (window.attachEvent) //Clean up loose references in IE
	window.attachEvent("onunload", function(){escrollerinstance.tickerdiv.onmouseover=escrollerinstance.tickerdiv.onmouseout=null})
	setTimeout(function(){escrollerinstance.animateup()}, this.delay)
	}

	// -------------------------------------------------------------------
	// animateup()- Move the two inner divs of the escroller up and in sync
	// -------------------------------------------------------------------

	pauseescroller.prototype.animateup=function(){
	var escrollerinstance=this
	if (parseInt(this.hiddendiv.style.top)>(this.visibledivtop+5)){
	this.visiblediv.style.top=parseInt(this.visiblediv.style.top)-5+"px"
	this.hiddendiv.style.top=parseInt(this.hiddendiv.style.top)-5+"px"
	setTimeout(function(){escrollerinstance.animateup()}, 50)
	}
	else{
	this.getinline(this.hiddendiv, this.visiblediv)
	this.swapdivs()
	setTimeout(function(){escrollerinstance.setmessage()}, this.delay)
	}
	}

	// -------------------------------------------------------------------
	// swapdivs()- Swap between which is the visible and which is the hidden div
	// -------------------------------------------------------------------

	pauseescroller.prototype.swapdivs=function(){
	var tempcontainer=this.visiblediv
	this.visiblediv=this.hiddendiv
	this.hiddendiv=tempcontainer
	}

	pauseescroller.prototype.getinline=function(div1, div2){
	div1.style.top=this.visibledivtop+"px"
	div2.style.top=Math.max(div1.parentNode.offsetHeight, div1.offsetHeight)+"px"
	}

	// -------------------------------------------------------------------
	// setmessage()- Populate the hidden div with the next message before it\'s visible
	// -------------------------------------------------------------------

	pauseescroller.prototype.setmessage=function(){
	var escrollerinstance=this
	if (this.mouseoverBol==1) //if mouse is currently over scoller, do nothing (pause it)
	setTimeout(function(){escrollerinstance.setmessage()}, 100)
	else{
	var i=this.hiddendivpointer
	var ceiling=this.content.length
	this.hiddendivpointer=(i+1>ceiling-1)? 0 : i+1
	this.hiddendiv.innerHTML=this.content[this.hiddendivpointer]
	this.animateup()
	}
	}

	pauseescroller.getCSSpadding=function(tickerobj){ //get CSS padding value, if any
	if (tickerobj.currentStyle)
	return tickerobj.currentStyle["paddingTop"]
	else if (window.getComputedStyle) //if DOM2
	return window.getComputedStyle(tickerobj, "").getPropertyValue("padding-top")
	else
	return 0
	}

	</script>
	<script type="text/javascript">

	//new pauseescroller(name_of_message_array, CSS_ID, CSS_classname, pause_in_miliseconds)
	new pauseescroller(pausecontent, "pescroller1", "someclass", 2000)
	document.write("<br />")
	</script>
	</span>
	</td>
	</tr>
	</table>
	';

}

function ArcadeInfoFader()
{
	global $context, $txt, $arcSettings, $scripturl;

	$a_news = arcade_news_fader($arcSettings['arcadeNewsFader'], $arcSettings['arcadeNewsNumber']);
	$i=0;

	echo'
	<div align="center">

	<td height="50" class="windowbg2" colspan = "3"><span>
	<script type="text/javascript"><!-- // --><![CDATA[

	/***********************************************
	* Fading Scroller- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
	* This notice MUST stay intact for legal use
	* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
	***********************************************/

	var delay = 5000; //set delay between message change (in miliseconds)
	var maxsteps=30; // number of steps to take to change from start color to endcolor
	var stepdelay=40; // time in miliseconds of a single step
	//**Note: maxsteps*stepdelay will be total time in miliseconds of fading effect
	var startcolor= new Array(255,255,255); // start color (red, green, blue)
	var endcolor=new Array(0,0,0); // end color (red, green, blue)

	var fcontent=new Array();
	begintag=\'<div align="center"style=" padding: 5px;">\'; //set opening tag, such as font declarations
	';
	foreach($a_news as $news_out)
	{
			echo 'fcontent[',$i,']="',addslashes($news_out['body']),'";
			';
		$i++;
	}
	echo '
	closetag=\'</div>\';

	var fwidth=\'100%\'; //set scroller width
	var fheight=\'30px\'; //set scroller height
	var ie4=document.all&&!document.getElementById;
	var DOM2=document.getElementById;
	var index=0;

	function changecontent(){
	if (index>=fcontent.length)
	index=0
	if (DOM2){
	document.getElementById("fscroller").innerHTML=begintag+fcontent[index]+closetag
	setTimeout("changecontent()", delay);
	}
	else if (ie4)
	document.all.fscroller.innerHTML=begintag+fcontent[index]+closetag;
	index++
	}

	if (ie4||DOM2)
	document.write(\'<div id="fscroller" style="border:0px solid black;width:\'+fwidth+\';height:\'+fheight+\'"></div>\');

	if (window.addEventListener)
	window.addEventListener("load", changecontent, false)
	else if (window.attachEvent)
	window.attachEvent("onload", changecontent)
	else if (document.getElementById)
	window.onload=changecontent
	// ]]></script>
	</span>
	</td>

	</div>';
}

function Arcade3champsBlock($no)
{
	global $scripturl, $txt, $settings;

	$top_player = ArcadeLatestChamps($no);
	$content = '<div align="center"><table width="100%" border="0" cellpadding="1"><tr><td colspan="2"><div align="center"><i><b>'.$no.' '.$txt['arcade_g_i_b_8'].'</b></i></div></td></tr>';
	if ($top_player != false)
	{
		foreach ($top_player as $row)
		{
			$content.= '<tr><td height="25"><div align="right"><img src="'.$settings['images_url'].'/arc_icons/cup_g.gif" alt="ico"/></div></td><td><div class="middletext"><div align="left"> - '.$row['member_link'].' '.$txt['is_champ_of'].' '.$row['game_link'].'</div></div></td></tr>';
		}
	}
	$content.='</table></div>';

	return $content;
}

function ArcadeGOTDBlock()
{
	global $context, $txt, $arcSettings, $settings;

	$condition = 'AND g.id_game = ' . (int) $arcSettings['arcadegotd'] .' LIMIT 0,1';
	$gamex = small_game_query($condition);
	$ratecode = '';

	$content ='<div align="center"><table width="100%" border="0" cellpadding="1"><tr><td><div align="center"><i><b>'.$txt['arcade_game_of_day'].'</b></i></div></td></tr>';

	foreach($gamex as $game)
	{
		$rating = $game['rating'];

		if ($rating > 0)
		{
			$ratecode = str_repeat('<img src="' . $settings['images_url'] . '/arc_icons/star.gif" alt="s" />' , $rating);
			$ratecode .= str_repeat('<img src="' . $settings['images_url'] . '/arc_icons/star2.gif" alt="s" />' , 5 - $rating);
		}

		$content .='<tr><td><div align="center">';

		if ($game['thumbnail'] != '')
		{
			$content .='<br /><a href="' . $game['url']['play'] . '"><img src="' . $game['thumbnail'] . '" width="80" height="80" alt="ico" title="'.$txt['arcade_play'].' '.$game['name'].'"/></a><br /><br />';

		}

		$content .='<div class="middletext"><a href="'. $game['url']['play']. '">'. $game['name']. '</a></div></div></td></tr>';


		if ($rating > 0)
		$content .='<tr><td align="center">'. $ratecode. '</td></tr>';

		$content .='<tr><td align="center"><div class="middletext">';

		if ($game['isChampion'])
		$content .= '<strong>'. $txt['arcade_champion']. ':</strong> '. $game['champion']['memberLink']. ' - '. $game['champion']['score']. '</div>';

		else
		$content .= $txt['arcade_no_scores'];
	}
	$content .= '</div></td></tr></table></div>';
	return $content;
}

function ArcadeRandomGameBlock()
{
	global $context, $txt, $arcSettings, $settings;

	$condition = 'ORDER BY RAND() LIMIT 0,1';
	$gamex = small_game_query($condition);
	foreach($gamex as $game)
	{
	$ratecode = '';
	$rating = $game['rating'];

	if ($rating > 0)
	{
		$ratecode = str_repeat('<img src="' . $settings['images_url'] . '/arc_icons/star.gif" alt="*" />' , $rating);
		$ratecode .= str_repeat('<img src="' . $settings['images_url'] . '/arc_icons/star2.gif" alt="*" />' , 5 - $rating);
	}

	$content ='<div align="center"><table width="100%" border="0" cellpadding="1"><tr><td colspan="2"><div align="center"><i><b>'.$txt['arcade_random_game'].'</b></i></div></td></tr>';
	$content .='<tr><td align="center"><br /><a href="'.$game['url']['play'] .'"><img src="'.$game['thumbnail'].'" width="80" height="80" alt="ico" title="'.$txt['arcade_play'].' '.$game['name'].'"/></a><div class="middletext"><a href="'.$game['url']['play'].'"><br />'.$game['name'].'</a></div></td></tr>';

	//echo $content;
	if ($rating > 0)
		$content .='<tr><td align="center">'.$ratecode.'</td></tr>';

	$content .='<tr><td align="center"><div class="middletext">';

	if ($game['isChampion'])
		$content .='<strong>'.$txt['arcade_champion'].':</strong> '.$game['champion']['memberLink'].' - '.$game['champion']['score'].'</div>';

	else
		$content .=$txt['arcade_no_scores'];

	$content .='</div></td></tr></table></div>';

	return $content;
	}
}


function ArcadeInfoNewestGames($no)
{
	global $smcFunc, $scripturl, $txt, $arcSettings;

		$result = $smcFunc['db_query']('', '
		SELECT id_game, game_name, thumbnail, game_directory
		FROM {db_prefix}arcade_games
		WHERE enabled = 1
		ORDER BY id_game DESC
		LIMIT 0, {int:limit}',
		array(
		'limit' => $no,
		)
	);
	$content = '<div align="center"><table width="100%" border="0" cellpadding="3"><tr><td colspan="2"><div align="center"><i><b>'.$no.' '.$txt['arcade_LatestGames'].'</b></i></div></td></tr>';
	while ($popgame = $smcFunc['db_fetch_assoc']($result))
	{
	$popgameico = !$popgame['game_directory'] ?	$arcSettings['gamesUrl'].$popgame['thumbnail'] : $arcSettings['gamesUrl'].$popgame['game_directory']."/".$popgame['thumbnail'];
	$content .='<tr><td><div align="right"><a href="'.$scripturl.'?action=arcade;sa=play;game='.$popgame['id_game'].'"><img border="0" src="'.$popgameico. '" alt="ico" width="25" height="25" title="'.$txt['arcade_champions_play'].' '. $popgame['game_name'].'"/></a></div></td><td class="middletext"><div align="left"><a href="'.$scripturl.'?action=arcade;sa=play;game='.$popgame['id_game'].'">'.$popgame['game_name'].'</a></div></td></tr>';
	}

	$content .='</table></div>' ;

	return $content;
}

function ArcadeInfoLongestChamps($no)
{
	global $scripturl, $txt, $arcSettings;

	$mostgame = ArcadeStats_LongestChampions($no);

	$content = '<div align="center"><table width="100%" border="0" cellpadding="3"><tr><td colspan="3"><div align="center"><i><b>'.$no.' '.$txt['arcade_g_i_b_11'].'</b></i></div></td></tr>';
	foreach($mostgame as $popgame)
	{
	$popgameico = !$popgame['game_directory'] ?	$arcSettings['gamesUrl'].$popgame['thumbnail'] : $arcSettings['gamesUrl'].$popgame['game_directory']."/".$popgame['thumbnail'];
	$content .='<tr><td width="25"><a href="'.$scripturl.'?action=arcade;sa=play;game='.$popgame['id'].'"><img border="0" src="'.$popgameico. '" alt="ico" width="25" height="25" title="'.$txt['arcade_champions_play'].' '. $popgame['game_name'].'"/></a></td><td class="middletext"><div align="left">'.$popgame['member_link'].' '.$txt['arcade_g_i_b_9'].' '.$popgame['game_name'].' '.$txt['arcade_g_i_b_5'].' '.$popgame['duration'].'</div></td></tr>';
	}

	$content .='</table></div>' ;

	return $content;
}

function ArcadeInfoMostPlayed($no)
{
	global $scripturl, $txt, $arcSettings;

	$mostgame = ArcadeStats_MostPlayed($no);

	$content = '<div align="center"><table width="100%" border="0" cellpadding="3"><tr><td colspan="3"><div align="center"><i><b>'.$no.' '.$txt['arcade_g_i_b_10'].'</b></i></div></td></tr>';
	foreach($mostgame as $popgame)
	{
	$popgameico = !$popgame['game_directory'] ?	$arcSettings['gamesUrl'].$popgame['thumbnail'] : $arcSettings['gamesUrl'].$popgame['game_directory']."/".$popgame['thumbnail'];
	$content .='<tr><td width="25"><a href="'.$scripturl.'?action=arcade;sa=play;game='.$popgame['id'].'"><img border="0" src="'.$popgameico. '" alt="ico" width="25" height="25" title="'.$txt['arcade_champions_play'].' '. $popgame['name'].'"/></a></td><td class="middletext"><div align="left">'.$popgame['link'].' '.$txt['arcade_g_i_b_6'].' '.$popgame['plays'].' '.$txt['arcade_g_i_b_7'].'</div></td></tr>';
	}

	$content .='</table></div>' ;

	return $content;
}

function ArcadeInfoBestPlayers($no)
{
	global $scripturl, $txt, $settings;

	$top_player = ArcadeStats_BestPlayers($no);
	$i=0; //players position

	//array for icons
	$poz = array('/first.gif','/second.gif','/third.gif',);

	$content = '<div align="center"><table width="100%" border="0" cellpadding="1"><tr><td colspan="2"><div align="center"><i><b>'.$no.' '.$txt['arcade_b3pb_1'].'</b></i></div></td></tr>';

	if ($top_player != false)
	{
		foreach ($top_player as $row)
		{
			$content.= '<tr><td height="25"><div align="right"><img src="'.$settings['images_url'].'/arc_icons'.$poz[$i].'" alt="ico"/></div></td><td><div class="middletext"><div align="left"> - '.$row['link'].' '.$txt['arcade_b3pb_2'].' '.$row['champions'].' '.$txt['arcade_b3pb_3'].'</div></div></td></tr>';
			$i++;
			if ($i > 2)
			{
				$poz[$i]= '/star2.gif';
			}
		}
	}
	$content.='</table></div>';

	return $content;

}

function ArcadeInfoShouts()
{
    global $smcFunc, $scripturl, $settings, $txt, $sourcedir, $arcSettings;
	require_once($sourcedir . '/Subs.php');

			$result = $smcFunc['db_query']('', '
				SELECT
				s.id_shout, s.id_member,
				s.content, s.time, m.real_name
				FROM {db_prefix}arcade_shouts AS s
				LEFT JOIN {db_prefix}members AS m ON (m.id_member = s.id_member)
				ORDER BY id_shout DESC
				LIMIT 0, {int:limit}',
				array(
				'limit' => $arcSettings['arcade_show_shouts'],
				)
			);

			echo '
				<table cellpadding="0"  align="center" width="100%" cellspacing="0" style="table-layout: fixed;">
				<tr>
					<td align="center">
						<span><i><b>', $txt['arcade_shouts'], '</b></i></span>
					</td>
				</tr>
					<tr><td>
					<div class="smalltext" style="width: 99%; height: 250px; overflow: auto;">';
					while ($shout = $smcFunc['db_fetch_assoc']($result))
					{
					echo'
						<div style="margin: 4px;">
							<div style="border: dotted 1px; padding: 2px 4px 2px 4px;" class="windowbg2">';

							if (allowedTo('arcade_admin'))
								echo'<a href="'.$scripturl.'?action=arcade;sa=shout;del='.$shout['id_shout'].'"><img border="0" src="' . $settings['images_url'] . '/arc_icons/del1.png" alt="X"  title="'.$txt['arcade_shout_del'].'"/></a>&nbsp;';

								echo'<b>'.$shout['real_name'].'</b>
							</div>
							<div style="padding: 2px;">
								'.timeformat($shout['time']).'
							</div>
							<div style="padding: 4px;">
								'.wordwrap(parse_bbc(censorText($shout['content'])), 34, "\n", true).'
							</div>
					</div>';

		}
					echo'</div></td>
					</tr>
				</table>';




}

//////////////////////////////////////////////////////////////////////////////
//Below here - Functions required to generate the blocks and read/write cache
function ArcadeShout()
{
	global $smcFunc, $txt, $arcSettings, $user_info;

	if (isset($_REQUEST['del']))
	{
	   // Only allow admins to delete shouts
       
       if (allowedTo('arcade_admin'))
       {
    		$id = (int)$_REQUEST['del'];
    
    		$smcFunc['db_query']('', '
    			DELETE FROM {db_prefix}arcade_shouts
    			WHERE id_shout = {int:ids}',
    			array(
    				'ids' => $id,
    			)
    		);
    
    		if ( file_exists($arcSettings['cacheDirectory'].'shout.cache'))
            {
                unlink($arcSettings['cacheDirectory'].'shout.cache');
            }
      }
	}
	elseif (!$user_info['is_guest'])
	{
		$shout = $txt['arcade_shouted'].$smcFunc['htmlspecialchars']($_REQUEST['the_shout'], ENT_QUOTES);
		add_to_arcade_shoutbox($shout);
	}
	redirectexit('action=arcade');
}

function ArcadeLatestChamps($no)
{
	global $smcFunc, $scripturl, $txt;

	$result = $smcFunc['db_query']('', '
		SELECT g.id_game, g.game_name, g.thumbnail, g.game_directory, m.id_member, m.real_name, s.id_member
		FROM {db_prefix}arcade_games AS g
		LEFT JOIN {db_prefix}arcade_scores AS s ON ( g.id_score_first = s.id_score )
		LEFT JOIN {db_prefix}members AS m ON ( m.id_member = s.id_member )
		WHERE g.id_member_first > 0
		ORDER BY s.champion_from DESC
		LIMIT 0, {int:limit}',
		array(
		'limit' => $no,
		)
	);

	$top = array();
	while ($score = $smcFunc['db_fetch_assoc']($result))
	{
		$top[] = array(
			'id' => $score['id_game'],
			'game_name' => $score['game_name'],
			'thumbnail' => $score['thumbnail'],
			'game_directory' => $score['game_directory'],
			'game_link' => '<a href="' . $scripturl . '?action=arcade;sa=play;game=' . $score['id_game'] . '">' .  $score['game_name'] . '</a>',
			'real_name' => $score['real_name'],
			'member_link' => !empty($score['real_name']) ? '<a href="' . $scripturl . '?action=profile;u=' . $score['id_member'] . '">' .  $score['real_name'] . '</a>' : $txt['arcade_guest'],
		);
	}
		return $top;
}

function category_games()
{
	//gets the category names and counts the games in each category
	global $smcFunc;

	$no = 30;
	// Load Category information
 	$result = $smcFunc['db_query']('', '
		SELECT
		c.id_category,
		count(g.id_category) AS games,
		c.category_name,
		c.category_icon
		FROM {db_prefix}arcade_games g, {db_prefix}arcade_categories c
		WHERE g.id_category = c.id_category AND g.enabled = 1
 		GROUP BY g.id_category
 		ORDER BY c.category_order
 		LIMIT 0, {int:limit}',
		array(
		'limit' => $no,
		)
	);
	while ($cat = $smcFunc['db_fetch_assoc']($result))
	{
		$cats[$cat['id_category']] = $cat;
	}
	return $cats;
}

function writeCache($content, $filename)
{
	// Writes a cache file
	global $arcSettings;

	$fp = fopen($arcSettings['cacheDirectory'].$filename, 'w');
	fwrite($fp, $content);
	fclose($fp);
}

function readCache($filename, $expiry)
{
	//Reads a cache file
	global $arcSettings;

	if (file_exists($arcSettings['cacheDirectory'].$filename))
	{
	  if ((time() - $expiry) > filemtime($arcSettings['cacheDirectory'].$filename))
	  {
	    return FALSE;
	  }
	  $cache = file($arcSettings['cacheDirectory'].$filename);
	  return implode('', $cache);
	}
	return FALSE;
}

function arcade_news_fader($board, $limit)
{
	global $smcFunc;

	$result = $smcFunc['db_query']('', '
		SELECT
		id_first_msg
		FROM {db_prefix}topics
		WHERE id_board = {int:board}
 		ORDER BY id_first_msg DESC
 		LIMIT 0, {int:limit}',
		array(
		'limit' => $limit,
		'board' => $board,
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{
		$posts[] = $row['id_first_msg'];
	}

	if (empty($posts))
		return array();

	$result = $smcFunc['db_query']('', '
		SELECT
		m.body,
		m.smileys_enabled,
		m.id_msg
		FROM {db_prefix}topics AS t, {db_prefix}messages AS m
		WHERE t.id_first_msg IN (' . implode(', ', $posts) . ')
 		AND m.id_msg = t.id_first_msg
		ORDER BY t.id_first_msg DESC
 		LIMIT 0, {int:limit}',
		array(
		'limit' => count($posts),
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{

		$find  = '<br';
		$pos = strpos($row['body'], $find);

		if ($pos !== false)
		{
			$row['body'] = substr($row['body'], 0, $pos);
		}

		$row['body'] = parse_bbc($row['body'], $row['smileys_enabled'], $row['id_msg']);
		censorText($row['body']);
		$return[] = array(
			'body' => $row['body'],
			'is_last' => false
		);
	}

	$return[count($return) - 1]['is_last'] = true;

	return $return;
}
?>