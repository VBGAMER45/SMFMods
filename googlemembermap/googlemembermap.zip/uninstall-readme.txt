Thank you for trying this modification out.  
If you leave the "Remove all data associated with this modification" [b]unchecked[/b] then there are a couple of things that will be left alone. 
	
	1) Any permissions you may have set for the mod 
	2) The member table modification which is all the pins your members have placed. These are left so you can choose to reinstall and not loose any data.
	
If you instead check that option, then all member data associated with this modification will also be removed