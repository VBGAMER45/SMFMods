*******************************
Avif and Webp Support
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x
Adds Avif and Webp image support to SMF.
Thumbnail generation

Notes: Requires PHP 8.1 or higher.
PHP 8.2+ to resizing Avif files for thumbnail generation

You must also modify your SMF attachment settings in Admin -> Forum -> Attachment settings to allow .wepb and .avif support

Other modifications can be found at SMFHacks.com
Include:
SMF Classifieds
SMF Store
Newsletter Pro
Downloads System Pro
Ad Seller Pro
EzPortal