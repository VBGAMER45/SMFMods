*******************************
Auto Twitter Embed
Devloped by:  L'arri : voici.l.arriviste@gmail.com
Packaged By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x

Auto embeds twitter tweets. Caches twitter status posts to handle many tweets being posted due to api limits of Twitter.

Install Information:
Install via the SMF's Package Manager via upload package.


Other mods can be found at SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
Download System Pro
SMF Store
Newsletter Pro

Licensed under: https://creativecommons.org/licenses/by-nd/4.0/ Attribution-NoDerivs
CC BY-ND 