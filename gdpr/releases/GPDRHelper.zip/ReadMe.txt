*******************************
GPDR Addon
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x

Warning does not guarantee GPDR compliance. No warranty provided.



Includes:
Allows member to export their data
On member deletion clears IP address and email from posts and assigns a new username to all old posts.
Includes a privacy policy page and adds a section for consent on registration
Stores the date/time that the privacy policy was changed and option to force to reagree
Stores the date/time that the registration agreement was changed and option to force to reagree



############################################
License Information:

Links to https://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at
SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
SMF Store
Newsletter Pro
EzPortal
Downloads Pro
AdSeller Pro

