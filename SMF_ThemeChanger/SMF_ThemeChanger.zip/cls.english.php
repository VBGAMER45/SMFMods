<?php
//Last modified: 2012/04/16

// Important! Before editing these language files please read the text at the top of index.english.php.

//Start ClickSafe Menu strings
  $txt['cls-head'] = 'Change the Theme';
  $txt['cls_title'] = 'ClickSafe Theme Changer';
  $txt['change_theme_check_top'] = 'Place at top';
  $txt['change_theme_check_bot'] = 'Place at the bottom<p style="height:150px; margin-top:30px; margin-left:150px;"><a href="http://www.smfhacks.com" target="_new">Visit SMFHacks.com</a><br />English support</p>';
//End ClickSafe Menu strings
?>