Ad Management Mod
Support site: www.smfads.com

----------
This mod will display ads on various parts of your forum on the default theme in SMF Version 1.1
---------
Version 3.1
+ New easy copyright removal system!

Version 2.3.1 June 09, 2009
- Added Ads.english-utf8.php file
- Updated error in install.php

Version 2.3 Jan 11, 2007
- New setting: Disable ads for admins
- New setting: Disable reports(one less query)
- New setting: Disable all ads
- New setting: Ability to make post ads not look like posts.
- Added the ability to display ads between categories
- Added the ability to display ads after the last post
- Added the ability to display ads under child boards
- Fixed issues about not finding functions(caused forums to crash)


Version 2.0 Jun 13, 2006
- Enabled per board ads
- Ability to add multiple ads
- HTML/PHP style ads
- Ad reports
- Disabled ads in certain sections of the admin panel
- Many more minor improvments

Version 1.5 Mar 19, 2006
- Fixed an issue with the xml
- Added the ability to display ads on top of the menu on every page
- Added help files
- Revised some of the code in previous versions.

Version 1.4.1 Feb 8, 2006
- Fixed an issue when installing on a forum that has TinyPortal installed

Version 1.4 Feb 2, 2006
- Added the ability to disable ads according to their membergroup.

Version 1.3 Feb 1, 2006
- Updated database settings so that they wont be removed on re-installation.
- Added the ability to display ads on the bottom of every page.
- Added the ability to display an ad after the first post. (Idea courtesy Joomlaspan)

Version 1.2 Jan 30, 2006
- Offically released on simplemachines.org. No offical changes from previous version.


Version 1.0 Jan 5, 2006
- Not publicly released.
- Displayed ads only under the menu bar.


