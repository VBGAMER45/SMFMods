*******************************
Profile Comments
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x, 1.1.x and 1.0.x

Adds a comments section to a user's profile page.
User's can leave multiple comments.
User's can edit/delete their own comments.
Spell Check for comments
BBC for comments.


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Trader System
SMF Archive
SMF Staff Page
SMF Links
User Email System
SMF Classifieds
Newsletter Pro
Downloads System Pro
EzPortal

SMFHacks package server address is:
http://www.smfhacks.com