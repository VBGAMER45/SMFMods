<?php
/*
Simple Audio Video Embedder
Version 2.6
by:vbgamer45
http://www.smfhacks.com

License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
*/
global $modSettings;
$modSettings['mediapro_disablesig'] = 0;

function MediaProMain()
{
	global $mediaProVersion;

	// Only admins can access MediaPro Settings
	isAllowedTo('admin_forum');

	// Hold Current Version
	$mediaProVersion = '2.6';

	// Load the language files
	if (loadlanguage('AutoEmbedMediaPro') == false)
		loadLanguage('AutoEmbedMediaPro','english');

	// Load template
	loadtemplate('AutoEmbedMediaPro2');

	// Sub Action Array
	$subActions = array(
		'settings' => 'MediaProSettings',
		'settings2' => 'MediaProSettings2',
		'mega' => 'MegaThanks',
		'copyright' => 'MediaProCopyright',
	);

	if (isset($_REQUEST['sa']))
		$sa = $_GET['sa'];
	else
		$sa = '';

	if (!empty($subActions[$sa]))
		$subActions[$sa]();
	else
		MediaProSettings();
}

function MediaProCopyright()
{
    global $context, $mbname, $txt;
	isAllowedTo('admin_forum');
    
    if (isset($_REQUEST['save']))
    {
        
        $mediapro_copyrightkey = mysql_escape_string($_REQUEST['mediapro_copyrightkey']);
        
        updateSettings(
    	array(
    	'mediapro_copyrightkey' => $mediapro_copyrightkey,
    	)
    
    	);
    }
    
    $context[$context['admin_menu_name']]['tab_data'] = array(
			'title' =>  $txt['mediapro_admin'],
			'description' => '',
			'tabs' => array(
				'settings' => array(
					'description' => $txt['mediapro_settings'],
				),
                'copyright' => array(
					'description' => $txt['mediapro_txt_copyrightremoval'],
				),
			),
		);


	
	$context['page_title'] = $mbname . ' - '  . $txt['mediapro_txt_copyrightremoval'];

	$context['sub_template']  = 'mediapro_copyright';
}


function MediaProSettings()
{
	global $txt, $context, $smcFunc;

	// Query all the sites
	$context['mediapro_sites'] = array();

	$result = $smcFunc['db_query']('', "
	SELECT
		id, title, website, enabled
	FROM {db_prefix}mediapro_sites
	ORDER BY title ASC
	");
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{
		$context['mediapro_sites'][] = $row;
	}


	// Set template
	$context['sub_template'] = 'mediapro_settings';

	// Set page title
	$context['page_title'] = $txt['mediapro_admin'];


	$context[$context['admin_menu_name']]['tab_data'] = array(
			'title' =>  $txt['mediapro_admin'],
			'description' => '',
			'tabs' => array(
				'settings' => array(
					'description' => $txt['mediapro_settings2'],
				),
				'copyright' => array(
					'description' =>$txt['mediapro_txt_copyrightremoval'],
			
				),
				
				
				
			),
		);


}

function MediaProSettings2()
{
	global $smcFunc;

	// Security Check
	checkSession('post');

	// Disable all sites
	$smcFunc['db_query']('', "
	UPDATE {db_prefix}mediapro_sites SET enabled = 0
	");

	// Check for enabled sites
	if (isset($_REQUEST['site']))
	{
		$sites = $_REQUEST['site'];
		$siteArray = array();
		foreach($sites as $site  => $key)
		{
			$site = (int) $site;
			$siteArray[] = $site;
		}

		if (count($siteArray) != 0)
		{
			$smcFunc['db_query']('', "
			UPDATE {db_prefix}mediapro_sites SET enabled = 1 WHERE id IN(" . implode(',',$siteArray) .")");
		}

	}


	// Write the cache
	MediaProWriteCache();
	
	// Settings
	$mediapro_default_height = (int) $_REQUEST['mediapro_default_height'];
	$mediapro_default_width = (int) $_REQUEST['mediapro_default_width'];
    $mediapro_disablesig = isset($_REQUEST['mediapro_disablesig']) ? 1 : 0;
	
		updateSettings(
	array(
	'mediapro_default_height' => $mediapro_default_height,
	'mediapro_default_width' => $mediapro_default_width,
    'mediapro_disablesig' => $mediapro_disablesig,
	));
	
	// Redirect to the admin area
	redirectexit('action=admin;area=mediapro;sa=settings');
}

function MediaProProcess($message)
{
	global $boarddir, $modSettings;

	// If it is short don't do anything
	if (strlen($message) < 7)
		return $message;
        
    if (isset($_REQUEST['action']))
    {
        if ($_REQUEST['action'] == 'post' || $_REQUEST['action'] == 'post2')
            return $message;
    }

	// Load the cache file
	if (file_exists($boarddir . "/cache/mediaprocache.php"))
	{
		global $mediaProCache;
		require_once($boarddir . "/cache/mediaprocache.php");


		$mediaProItems =  unserialize($mediaProCache);


	}
	else
		$mediaProItems = MediaProWriteCache();

	// Loop though main array of enabled sites to process
	if (count($mediaProItems) > 0)
	foreach($mediaProItems as $mediaSite)
	{
		
		if (!empty($modSettings['mediapro_default_width']))
			$movie_width = $modSettings['mediapro_default_width'];
		else 
			$movie_width  = $mediaSite['width'];
		
		if (!empty($modSettings['mediapro_default_height']))	
			$movie_height = $modSettings['mediapro_default_height'];
		else 
			$movie_height = $mediaSite['height'];
			
	
		
			$mediaSite['embedcode'] = str_replace('width="480"','width="' . $movie_width  .'"', $mediaSite['embedcode']);
			$mediaSite['embedcode'] = str_replace('width:480','width="' . $movie_width  .'px', $mediaSite['embedcode']);
			$mediaSite['embedcode'] = str_replace('width=480','width=' . $movie_width , $mediaSite['embedcode']);
		
		
		
			 $mediaSite['embedcode'] = str_replace('height="600"','height="' . $movie_height .'"', $mediaSite['embedcode']);
			 $mediaSite['embedcode'] = str_replace('height:600','height:' . $movie_height.'px', $mediaSite['embedcode']);
			 $mediaSite['embedcode'] = str_replace('height=600','height=' . $movie_height, $mediaSite['embedcode']);
	
		
		$message = preg_replace('#<a href="' . $mediaSite['regexmatch'] . '"(.*?)</a>#i', $mediaSite['embedcode'], $message);
	}

	// Return the updated message content
	return $message;
}

function MediaProWriteCache()
{
	global $smcFunc, $boarddir;

	$mediaProItems = array();

	// Get list of sites that are enabled
	$result = $smcFunc['db_query']('', "
	SELECT
		id, title, website, regexmatch,
		embedcode, height,  width
	FROM {db_prefix}mediapro_sites
	WHERE enabled = 1");
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{
		$mediaProItems[] = $row;
	}

	// Data to write
	$data = '<?php
$mediaProCache = \'' . serialize($mediaProItems)  . '\';
?>';

	// Write the cache to the file
	$fp = fopen($boarddir . "/cache/mediaprocache.php", 'w');
	if ($fp)
	{
		fwrite($fp, $data);
	}

	fclose($fp);


	// Return the items in the array
	return $mediaProItems;

}

function MegaThanks()
{
	global $context, $txt;
	
	// Set template
	$context['sub_template'] = 'mega';

	// Set page title
	$context['page_title'] = $txt['mediapro_megauploadtometoday'];
}
?>