<?php
$mediaProCache = 'a:1:{i:0;a:7:{s:2:"id";s:1:"1";s:5:"title";s:7:"Youtube";s:7:"website";s:22:"http://www.youtube.com";s:10:"regexmatch";s:78:"http://[w.]+youtube.[w]+/watch[?#!]+v=([w-]+)[w&;+=-]*[#t=]*([d]*)[&;10shdq=]*";s:9:"embedcode";s:346:"<object width="640" height="385">
<param name="movie" value="http://www.youtube.com/v/$p1&fs=1&start=$p2"></param>
<param name="allowFullScreen" value="true"></param>
<embed src="http://www.youtube.com/v/$p1&fs=1&start=$p2" type="application/x-shockwave-flash" allowfullscreen="true" width="640" height="385" wmode="transparent"></embed></object>";s:6:"height";s:1:"0";s:5:"width";s:1:"0";}}';
?>