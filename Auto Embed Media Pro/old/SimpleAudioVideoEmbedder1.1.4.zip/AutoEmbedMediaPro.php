<?php
/*
Simple Audio Video Embedder
Version 1.1
by:vbgamer45
http://www.smfhacks.com

License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
*/

function MediaProMain()
{
	global $mediaProVersion;

	// Only admins can access MediaPro Settings
	isAllowedTo('admin_forum');

	// Hold Current Version
	$mediaProVersion = '1.1.4';

	// Load the language files
	if (loadlanguage('AutoEmbedMediaPro') == false)
		loadLanguage('AutoEmbedMediaPro','english');

	// Load template
	loadtemplate('AutoEmbedMediaPro');

	// Sub Action Array
	$subActions = array(
		'settings' => 'MediaProSettings',
		'settings2' => 'MediaProSettings2',
	);

	if (isset($_REQUEST['sa']))
		$sa = $_GET['sa'];
	else
		$sa = '';

	if (!empty($subActions[$sa]))
		$subActions[$sa]();
	else
		MediaProSettings();
}

function MediaProSettings()
{
	global $txt, $context, $db_prefix;

	// Query all the sites
	$context['mediapro_sites'] = array();

	$result = db_query("
	SELECT
		id, title, website, enabled
	FROM {$db_prefix}mediapro_sites
	ORDER BY title ASC
	", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($result))
	{
		$context['mediapro_sites'][] = $row;
	}


	// Set template
	$context['sub_template'] = 'mediapro_settings';

	// Set page title
	$context['page_title'] = $txt['mediapro_admin'];

	adminIndex('mediapro_admin');

}

function MediaProSettings2()
{
	global $db_prefix;

	// Security Check
	checkSession('post');

	// Disable all sites
	db_query("
	UPDATE {$db_prefix}mediapro_sites SET enabled = 0
	", __FILE__, __LINE__);

	// Check for enabled sites
	if (isset($_REQUEST['site']))
	{
		$sites = $_REQUEST['site'];
		$siteArray = array();
		foreach($sites as $site  => $key)
		{
			$site = (int) $site;
			$siteArray[] = $site;
		}

		if (count($siteArray) != 0)
		{
			db_query("
			UPDATE {$db_prefix}mediapro_sites SET enabled = 1 WHERE id IN(" . implode(',',$siteArray) .")", __FILE__, __LINE__);
		}

	}


	// Write the cache
	MediaProWriteCache();
	
	// Settings
	$mediapro_default_height = (int) $_REQUEST['mediapro_default_height'];
	$mediapro_default_width = (int) $_REQUEST['mediapro_default_width'];
	
		updateSettings(
	array(
	'mediapro_default_height' => $mediapro_default_height,
	'mediapro_default_width' => $mediapro_default_width,
	));
	
	

	// Redirect to the admin area
	redirectexit('action=mediapro;sa=settings');
}

function MediaProProcess($message)
{
	global $boarddir, $modSettings;

	// If it is short don't do anything
	if (strlen($message) < 7)
		return $message;

	// Load the cache file
	if (file_exists($boarddir . "/cache/mediaprocache.php"))
	{
		global $mediaProCache;
		require_once($boarddir . "/cache/mediaprocache.php");


		$mediaProItems =  unserialize($mediaProCache);


	}
	else
		$mediaProItems = MediaProWriteCache();

	// Loop though main array of enabled sites to process
	if (count($mediaProItems) > 0)
	foreach($mediaProItems as $mediaSite)
	{
		if (!empty($modSettings['mediapro_default_width']))
		{
			$mediaSite['embedcode'] = str_replace('width="480"','width="' . $modSettings['mediapro_default_width'] .'"', $mediaSite['embedcode']);
			$mediaSite['embedcode'] = str_replace('width:480','width:' . $modSettings['mediapro_default_width'] .'px', $mediaSite['embedcode']);
			$mediaSite['embedcode'] = str_replace('width=480','width=' . $modSettings['mediapro_default_width'], $mediaSite['embedcode']);
		}
		
		if (!empty($modSettings['mediapro_default_height']))
		{
			 $mediaSite['embedcode'] = str_replace('height="600"','height="' . $modSettings['mediapro_default_height'] .'"', $mediaSite['embedcode']);
			 $mediaSite['embedcode'] = str_replace('height:600','height:' . $modSettings['mediapro_default_height'] .'px', $mediaSite['embedcode']);
			 $mediaSite['embedcode'] = str_replace('height=600','height=' . $modSettings['mediapro_default_height'], $mediaSite['embedcode']);
			  
		}		
		
		$message = preg_replace('#<a href="' . $mediaSite['regexmatch'] . '"(.*?)</a>#i', $mediaSite['embedcode'], $message);
	}

	// Return the updated message content
	return $message;
}

function MediaProWriteCache()
{
	global $db_prefix, $boarddir;

	$mediaProItems = array();

	// Get list of sites that are enabled
	$result = db_query("
	SELECT
		id, title, website, regexmatch,
		embedcode, height,  width
	FROM {$db_prefix}mediapro_sites
	WHERE enabled = 1 ORDER BY title ASC", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($result))
	{
		$mediaProItems[] = $row;
	}

	// Data to write
	$data = '<?php
$mediaProCache = \'' . serialize($mediaProItems)  . '\';
?>';

	// Write the cache to the file
	$fp = fopen($boarddir . "/cache/mediaprocache.php", 'w');
	if ($fp)
	{
		fwrite($fp, $data);
	}

	fclose($fp);

	// Return the items in the array
	return $mediaProItems;

}

function MediaProFetchRemoteData()
{

}

?>