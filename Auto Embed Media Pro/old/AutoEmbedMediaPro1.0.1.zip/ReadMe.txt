*******************************
Auto Embed Media Pro
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 1.1.x
An auto embed media modification for SMF that takes links for popular video websites and adds a player directly into the post or bbc area of your website

Supports the following sites:
Facebook	
Metacafe
Youtube	
Vimeo
College Humor
Google Video

Install Information:
Install via the SMF's Package Manager via upload package.


############################################
License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
Download System Pro
SMF Store
Newsletter Pro

