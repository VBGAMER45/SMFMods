<?php
/*
Auto Embed Media Pro
Version 1.0.1
by:vbgamer45
http://www.smfhacks.com

License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
*/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
  require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
  die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');
  

db_query("CREATE TABLE IF NOT EXISTS {$db_prefix}mediapro_sites (
  id int(11) NOT NULL auto_increment, 
  title varchar(255),
  enabled tinyint default 0,
  website varchar(255),
  regexmatch text,
  embedcode text,
  processregex text,
  height int(5) default 0,
  width int(5) default 0,
  
  PRIMARY KEY (id)
) ", __FILE__, __LINE__);


db_query("INSERT IGNORE INTO {$db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(1, 'Youtube','http://www.youtube.com', 'http://[" . '\\' .'\\' . "w.]+youtube" . '\\' .'\\' . ".[" . '\\' .'\\' . "w]+/watch[" . '\\' .'\\' . "?" . '\\' .'\\' . "#!]+v=([" . '\\' .'\\' . "w-]+)[" . '\\' .'\\' . "w&;+=-]*[" . '\\' .'\\' . "#t=]*([" . '\\' .'\\' . "d]*)[&;10shdq=]*','" . '<object width="640" height="385">
<param name="movie" value="http://www.youtube.com/v/$1&fs=1&start=$2"></param>
<param name="allowFullScreen" value="true"></param>
<embed src="http://www.youtube.com/v/$1&fs=1&start=$2" type="application/x-shockwave-flash" allowfullscreen="true" width="640" height="385" wmode="transparent"></embed></object>' . "'),

(2, 'Metacafe','http://www.metacafe.com', 'http://www" . '\\' .'\\' . ".metacafe" . '\\' .'\\' . ".com/watch/([" . '\\' .'\\' . "w-]+/[" . '\\' .'\\' . "w_]*)[" . '\\' .'\\' . "w&;=" . '\\' .'\\' . "+_" . '\\' .'\\' . "-" . '\\' .'\\' . "/]*','" . '<embed src="http://www.metacafe.com/fplayer/$1.swf" width="540" height="334" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent"></embed>' . "'),

(3, 'Facebook','http://www.facebook.com', 'http://www" . '\\' .'\\' . ".facebook" . '\\' .'\\' . ".com/video/video" . '\\' .'\\' . ".php" . '\\' .'\\' . "?v=([" . '\\' .'\\' . "w]+)&*[" . '\\' .'\\' . "w;=]*','" . '<object width="640" height="385" > 
       <param name="allowfullscreen" value="true" /> 
       <param name="allowscriptaccess" value="always" /> 
       <param name="movie" value="http://www.facebook.com/v/$1" /> 
       <embed src="http://www.facebook.com/v/$1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="385"></embed></object>' . "'),

(4, 'Vimeo','http://www.vimeo.com', 'http://[w" . '\\' .'\\' . ".]*vimeo" . '\\' .'\\' . ".com/([" . '\\' .'\\' . "d]+)[" . '\\' .'\\' . "w&;=" . '\\' .'\\' . "?+%/-]*','" . '<object type="application/x-shockwave-flash" width="640" height="385" data="http://vimeo.com/moogaloop.swf?clip_id=$1&amp;server=vimeo.com&amp;fullscreen=1&amp;video_info=1">	<param name="quality" value="best"><param name="allowfullscreen" value="true"><param name="scale" value="showAll"><param name="movie" value="http://vimeo.com/moogaloop.swf?clip_id=$1&amp;server=vimeo.com&amp;fullscreen=1&amp;video_info=1"></object>' . "'),


(5, 'College Humor','http://www.collegehumor.com', 'http://]*[a-z]*?[" . '\\' .'\\' . ".]?collegehumor" . '\\' .'\\' . ".com/video:([0-9]+)','" . '<embed src="http://www.collegehumor.com/moogaloop/moogaloop.swf?clip_id=$1" quality="best" width="640" height="385" type="application/x-shockwave-flash"></embed>' . "'),

(6, 'Google Video', 'http://video.google.com','[http://]*video" . '\\' .'\\' . ".google" . '\\' .'\\' . ".[" . '\\' .'\\' . "w.]+/videoplay" . '\\' .'\\' . "?docid=([-" . '\\' .'\\' . "d]+)[&" . '\\' .'\\' . "w;=" . '\\' .'\\' . "+.-]*','" . '<embed style="width:640px; height:385px;" id="VideoPlayback" type="application/x-shockwave-flash" src="http://video.google.com/googleplayer.swf?docId=$1" flashvars="" wmode="transparent"> </embed>' . "')

", __FILE__, __LINE__);

db_query("INSERT IGNORE INTO {$db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(7, 'Veoh', 'http://www.veoh.com', 'http://www" . '\\' .'\\' . ".veoh" . '\\' .'\\' . ".com/(.*)/watch/([A-Z0-9]*)','" . '<object width="410" height="341" id="veohFlashPlayer" name="veohFlashPlayer"><param name="movie" value="http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.5.2.1066&permalinkId=$2&player=videodetailsembedded&videoAutoPlay=0&id=anonymous"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.5.2.1066&permalinkId=$2&player=videodetailsembedded&videoAutoPlay=0&id=anonymous" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="410" height="341" id="veohFlashPlayerEmbed" name="veohFlashPlayerEmbed"></embed></object>' . "'),
(8, 'Youku', 'http://www.youku.com', 'http://([A-Z0-9]*).youku.com/v_show/id_([A-Z0-9]*).html','" . '
<embed src="http://player.youku.com/player.php/sid/$2/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"></embed>' . "'),


(9, 'USteam.tv', 'http://www.ustream.tv', 'http://([A-Z0-9]*).ustream.tv/recorded/([0-9]*)','" . '
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="480" height="386" id="utv159159" name="utv_n_278276"><param name="flashvars" value="beginPercent=0.4193&amp;endPercent=0.4316&amp;autoplay=false&locale=en_US" /><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /><param name="src" value="http://www.ustream.tv/flash/video/$2" /><embed flashvars="beginPercent=0.4193&amp;endPercent=0.4316&amp;autoplay=false&locale=en_US" width="480" height="386" allowfullscreen="true" allowscriptaccess="always" id="utv159159" name="utv_n_278276" src="http://www.ustream.tv/flash/video/$2" type="application/x-shockwave-flash" /></object>

' . "')


", __FILE__, __LINE__);



?>