<?php
/*
Auto Embed Media Pro
Version 1.0.1
by:vbgamer45
http://www.smfhacks.com

License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
*/

// Latest Version:
$txt['mediapro_txt_latestversion'] = 'Latest Version: ';
$txt['mediapro_txt_yourversion'] = 'Your Version: ';
$txt['mediapro_txt_version_outofdate'] = 'Your Auto Embed Media Pro version is not up to date!<br /><a href=\"http://custom.simplemachines.org/mods/index.php?mod=2681\" target=\"_blank\">Download a the latest version now!</a>';

?>