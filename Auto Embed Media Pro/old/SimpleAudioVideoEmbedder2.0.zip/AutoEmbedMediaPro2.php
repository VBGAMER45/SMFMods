<?php
/*
Simple Audio Video Embedder
Version 2.0
by:vbgamer45
http://www.smfhacks.com

License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
*/

function MediaProMain()
{
	global $mediaProVersion;

	// Only admins can access MediaPro Settings
	isAllowedTo('admin_forum');

	// Hold Current Version
	$mediaProVersion = '2.0';

	// Load the language files
	if (loadlanguage('AutoEmbedMediaPro') == false)
		loadLanguage('AutoEmbedMediaPro','english');

	// Load template
	loadtemplate('AutoEmbedMediaPro2');

	// Sub Action Array
	$subActions = array(
		'settings' => 'MediaProSettings',
		'settings2' => 'MediaProSettings2',
	);

	if (isset($_REQUEST['sa']))
		$sa = $_GET['sa'];
	else
		$sa = '';

	if (!empty($subActions[$sa]))
		$subActions[$sa]();
	else
		MediaProSettings();
}

function MediaProSettings()
{
	global $txt, $context, $smcFunc;

	// Query all the sites
	$context['mediapro_sites'] = array();

	$result = $smcFunc['db_query']('', "
	SELECT
		id, title, website, enabled
	FROM {db_prefix}mediapro_sites
	ORDER BY title ASC
	");
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{
		$context['mediapro_sites'][] = $row;
	}


	// Set template
	$context['sub_template'] = 'mediapro_settings';

	// Set page title
	$context['page_title'] = $txt['mediapro_admin'];


	$context[$context['admin_menu_name']]['tab_data'] = array(
			'title' =>  $txt['mediapro_admin'],
			'description' => '',
			'tabs' => array(
				'settings' => array(
					'description' => $txt['mediapro_settings'],
				),
			),
		);


}

function MediaProSettings2()
{
	global $smcFunc;

	// Security Check
	checkSession('post');

	// Disable all sites
	$smcFunc['db_query']('', "
	UPDATE {db_prefix}mediapro_sites SET enabled = 0
	");

	// Check for enabled sites
	if (isset($_REQUEST['site']))
	{
		$sites = $_REQUEST['site'];
		$siteArray = array();
		foreach($sites as $site  => $key)
		{
			$site = (int) $site;
			$siteArray[] = $site;
		}

		if (count($siteArray) != 0)
		{
			$smcFunc['db_query']('', "
			UPDATE {db_prefix}mediapro_sites SET enabled = 1 WHERE id IN(" . implode(',',$siteArray) .")");
		}

	}


	// Write the cache
	MediaProWriteCache();
	
	// Settings
	$mediapro_default_height = (int) $_REQUEST['mediapro_default_height'];
	$mediapro_default_width = (int) $_REQUEST['mediapro_default_width'];
	
		updateSettings(
	array(
	'mediapro_default_height' => $mediapro_default_height,
	'mediapro_default_width' => $mediapro_default_width,
	));
	
	// Redirect to the admin area
	redirectexit('action=admin;area=mediapro;sa=settings');
}

function MediaProProcess($message)
{
	global $boarddir, $modSettings;

	// If it is short don't do anything
	if (strlen($message) < 7)
		return $message;

	// Load the cache file
	if (file_exists($boarddir . "/cache/mediaprocache.php"))
	{
		global $mediaProCache;
		require_once($boarddir . "/cache/mediaprocache.php");


		$mediaProItems =  unserialize($mediaProCache);


	}
	else
		$mediaProItems = MediaProWriteCache();

	// Loop though main array of enabled sites to process
	if (count($mediaProItems) > 0)
	foreach($mediaProItems as $mediaSite)
	{
		
		if (!empty($modSettings['mediapro_default_width']))
		{
			$mediaSite['embedcode'] = str_replace('width="480"','width="' . $modSettings['mediapro_default_width'] .'"', $mediaSite['embedcode']);
			$mediaSite['embedcode'] = str_replace('width:480','width="' . $modSettings['mediapro_default_width'] .'px', $mediaSite['embedcode']);
			$mediaSite['embedcode'] = str_replace('width=480','width=' . $modSettings['mediapro_default_width'], $mediaSite['embedcode']);
		}
		
		if (!empty($modSettings['mediapro_default_height']))
		{
			 $mediaSite['embedcode'] = str_replace('height="600"','height="' . $modSettings['mediapro_default_height'] .'"', $mediaSite['embedcode']);
			 $mediaSite['embedcode'] = str_replace('height:600','height:' . $modSettings['mediapro_default_height'] .'px', $mediaSite['embedcode']);
			 $mediaSite['embedcode'] = str_replace('height=600','height=' . $modSettings['mediapro_default_height'], $mediaSite['embedcode']);
		}	
		
		$message = preg_replace('#<a href="' . $mediaSite['regexmatch'] . '"(.*?)</a>#i', $mediaSite['embedcode'], $message);
	}

	// Return the updated message content
	return $message;
}

function MediaProWriteCache()
{
	global $smcFunc, $boarddir;

	$mediaProItems = array();

	// Get list of sites that are enabled
	$result = $smcFunc['db_query']('', "
	SELECT
		id, title, website, regexmatch,
		embedcode, height,  width
	FROM {db_prefix}mediapro_sites
	WHERE enabled = 1");
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{
		$mediaProItems[] = $row;
	}

	// Data to write
	$data = '<?php
$mediaProCache = \'' . serialize($mediaProItems)  . '\';
?>';

	// Write the cache to the file
	$fp = fopen($boarddir . "/cache/mediaprocache.php", 'w');
	if ($fp)
	{
		fwrite($fp, $data);
	}

	fclose($fp);


	// Return the items in the array
	return $mediaProItems;

}

?>