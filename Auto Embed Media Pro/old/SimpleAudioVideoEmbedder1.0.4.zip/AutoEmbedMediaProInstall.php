<?php
/*
Simple Audio Video Embedder
Version 1.0.3
by:vbgamer45
http://www.smfhacks.com

License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
*/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
  require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
  die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');


db_query("CREATE TABLE IF NOT EXISTS {$db_prefix}mediapro_sites (
  id int(11) NOT NULL auto_increment,
  title varchar(255),
  enabled tinyint default 0,
  website varchar(255),
  regexmatch text,
  embedcode text,
  processregex text,
  height int(5) default 0,
  width int(5) default 0,

  PRIMARY KEY (id)
) ", __FILE__, __LINE__);


db_query("INSERT IGNORE INTO {$db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(1, 'Youtube','http://www.youtube.com', 'http://[" . '\\' .'\\' . "w.]+youtube" . '\\' .'\\' . ".[" . '\\' .'\\' . "w]+/watch[" . '\\' .'\\' . "?" . '\\' .'\\' . "#!]+v=([" . '\\' .'\\' . "w-]+)[" . '\\' .'\\' . "w&;+=-]*[" . '\\' .'\\' . "#t=]*([" . '\\' .'\\' . "d]*)[&;10shdq=]*','" . '<object width="640" height="385">
<param name="movie" value="http://www.youtube.com/v/$1&fs=1&start=$2"></param>
<param name="allowFullScreen" value="true"></param>
<embed src="http://www.youtube.com/v/$1&fs=1&start=$2" type="application/x-shockwave-flash" allowfullscreen="true" width="640" height="385" wmode="transparent"></embed></object>' . "'),

(2, 'Metacafe','http://www.metacafe.com', 'http://www" . '\\' .'\\' . ".metacafe" . '\\' .'\\' . ".com/watch/([" . '\\' .'\\' . "w-]+/[" . '\\' .'\\' . "w_]*)[" . '\\' .'\\' . "w&;=" . '\\' .'\\' . "+_" . '\\' .'\\' . "-" . '\\' .'\\' . "/]*','" . '<embed src="http://www.metacafe.com/fplayer/$1.swf" width="540" height="334" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent"></embed>' . "'),

(3, 'Facebook','http://www.facebook.com', 'http://www" . '\\' .'\\' . ".facebook" . '\\' .'\\' . ".com/video/video" . '\\' .'\\' . ".php" . '\\' .'\\' . "?v=([" . '\\' .'\\' . "w]+)&*[" . '\\' .'\\' . "w;=]*','" . '<object width="640" height="385" >
       <param name="allowfullscreen" value="true" />
       <param name="allowscriptaccess" value="always" />
       <param name="movie" value="http://www.facebook.com/v/$1" />
       <embed src="http://www.facebook.com/v/$1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="385"></embed></object>' . "'),

(4, 'Vimeo','http://www.vimeo.com', 'http://[w" . '\\' .'\\' . ".]*vimeo" . '\\' .'\\' . ".com/([" . '\\' .'\\' . "d]+)[" . '\\' .'\\' . "w&;=" . '\\' .'\\' . "?+%/-]*','" . '<object type="application/x-shockwave-flash" width="640" height="385" data="http://vimeo.com/moogaloop.swf?clip_id=$1&amp;server=vimeo.com&amp;fullscreen=1&amp;video_info=1">	<param name="quality" value="best"><param name="allowfullscreen" value="true"><param name="scale" value="showAll"><param name="movie" value="http://vimeo.com/moogaloop.swf?clip_id=$1&amp;server=vimeo.com&amp;fullscreen=1&amp;video_info=1"></object>' . "'),


(5, 'College Humor','http://www.collegehumor.com', 'http://]*[a-z]*?[" . '\\' .'\\' . ".]?collegehumor" . '\\' .'\\' . ".com/video:([0-9]+)','" . '<embed src="http://www.collegehumor.com/moogaloop/moogaloop.swf?clip_id=$1" quality="best" width="640" height="385" type="application/x-shockwave-flash"></embed>' . "'),

(6, 'Google Video', 'http://video.google.com','[http://]*video" . '\\' .'\\' . ".google" . '\\' .'\\' . ".[" . '\\' .'\\' . "w.]+/videoplay" . '\\' .'\\' . "?docid=([-" . '\\' .'\\' . "d]+)[&" . '\\' .'\\' . "w;=" . '\\' .'\\' . "+.-]*','" . '<embed style="width:640px; height:385px;" id="VideoPlayback" type="application/x-shockwave-flash" src="http://video.google.com/googleplayer.swf?docId=$1" flashvars="" wmode="transparent"> </embed>' . "')

", __FILE__, __LINE__);

db_query("INSERT IGNORE INTO {$db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(7, 'Veoh', 'http://www.veoh.com', 'http://www" . '\\' .'\\' . ".veoh" . '\\' .'\\' . ".com/(.*)/watch/([A-Z0-9]*)','" . '<object width="410" height="341" id="veohFlashPlayer" name="veohFlashPlayer"><param name="movie" value="http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.5.2.1066&permalinkId=$2&player=videodetailsembedded&videoAutoPlay=0&id=anonymous"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.5.2.1066&permalinkId=$2&player=videodetailsembedded&videoAutoPlay=0&id=anonymous" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="410" height="341" id="veohFlashPlayerEmbed" name="veohFlashPlayerEmbed"></embed></object>' . "'),
(8, 'Youku', 'http://www.youku.com', 'http://([A-Z0-9]*).youku.com/v_show/id_([A-Z0-9]*).html','" . '
<embed src="http://player.youku.com/player.php/sid/$2/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"></embed>' . "'),


(9, 'USteam.tv', 'http://www.ustream.tv', 'http://([A-Z0-9]*).ustream.tv/recorded/([0-9]*)','" . '
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="480" height="386" id="utv159159" name="utv_n_278276"><param name="flashvars" value="beginPercent=0.4193&amp;endPercent=0.4316&amp;autoplay=false&locale=en_US" /><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /><param name="src" value="http://www.ustream.tv/flash/video/$2" /><embed flashvars="beginPercent=0.4193&amp;endPercent=0.4316&amp;autoplay=false&locale=en_US" width="480" height="386" allowfullscreen="true" allowscriptaccess="always" id="utv159159" name="utv_n_278276" src="http://www.ustream.tv/flash/video/$2" type="application/x-shockwave-flash" /></object>

' . "')


", __FILE__, __LINE__);



//1.0.2
db_query("INSERT IGNORE INTO {$db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES

(10, 'Rutube', 'http://rutube.ru', 'http://rutube.ru/tracks/([A-Z0-9]*).html" . '\\' .'\\' . "?v=([A-Z0-9]*)','" . '
<OBJECT width="470" height="353"><PARAM name="movie" value="http://video.rutube.ru/$2"></PARAM><PARAM name="wmode" value="window"></PARAM><PARAM name="allowFullScreen" value="true"></PARAM><EMBED src="http://video.rutube.ru/$2" type="application/x-shockwave-flash" wmode="window" width="470" height="353" allowFullScreen="true" ></EMBED></OBJECT>
' . "'),

(11, 'Novamov', 'http://www.novamov.com', 'http://www.novamov.com/video/([A-Z0-9]*)','" . '
<iframe style="overflow: hidden; border: 0; width: 600px; height: 480px" src="http://embed.novamov.com/embed.php?width=600&height=480&v=$1" scrolling="no"></iframe>
' . "'),

(12, 'MyVideo.de', 'http://www.MyVideo.de', 'http://www.myvideo.de/watch/([A-Z0-9]*)/(.*)','" . '
<object style="width:470px;height:285px;" width="470" height="285"><param name="movie" value="http://www.myvideo.de/movie/$1"></param><param name="AllowFullscreen" value="true"></param><param name="AllowScriptAccess" value="always"></param><embed src="http://www.myvideo.de/movie/$1" width="470" height="285" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"></embed></object>
' . "'),

(13, 'LiveLeak', 'http://www.liveleak.com', 'http://www.liveleak.com/view" . '\\' .'\\' . "?i=(.*)','" . '
<object width="450" height="370"><param name="movie" value="http://www.liveleak.com/e/$1"></param><param name="wmode" value="transparent"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.liveleak.com/e/8ee_1281467692" type="application/x-shockwave-flash" wmode="transparent" allowscriptaccess="always" width="450" height="370"></embed></object>

' . "'),


(14, 'Sevenload', 'http://www.sevenload.com', 'http://([A-Z0-9]*).sevenload.com/videos/([A-Z0-9]*)-(.*)','" . '
<object type="application/x-shockwave-flash" data="http://$1.sevenload.com/pl/$2/500x408/swf" width="500" height="408"><param name="allowFullscreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="movie" value="http://$1.sevenload.com/pl/$2/500x408/swf" /></object>

' . "'),

(15, 'Gametrailers', 'http://www.gametrailers.com', 'http://www.gametrailers.com/video/(.*)/([0-9]*)(.*)','" . '
<div style="width: 480px;">
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" id="gtembed" width="480" height="392">	<param name="allowScriptAccess" value="sameDomain" /> <param name="allowFullScreen" value="true" /> <param name="movie" value="http://www.gametrailers.com/remote_wrap.php?mid=$2"/><param name="quality" value="high" /> <embed src="http://www.gametrailers.com/remote_wrap.php?mid=$2" swLiveConnect="true" name="gtembed" align="middle" allowScriptAccess="sameDomain" allowFullScreen="true" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="480" height="392"></embed> </object>
</div>
' . "'),

(16, 'Funnyordie.com', 'http://www.funnyordie.com', 'http://www.funnyordie.com/videos/([A-Z0-9]*)/(.*)','" . '
<object width="480" height="400" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" id="ordie_player_$1"><param name="movie" value="http://player.ordienetworks.com/flash/fodplayer.swf" /><param name="flashvars" value="key=$1" /><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always"></param><embed width="480" height="400" flashvars="key=$1" allowfullscreen="true" allowscriptaccess="always" quality="high" src="http://player.ordienetworks.com/flash/fodplayer.swf" name="ordie_player_$1" type="application/x-shockwave-flash"></embed></object>

' . "'),

(17, 'Mevio', 'http://www.mevio.com', 'http://www.mevio.com/channels/" . '\\' .'\\' . "?cId=([0-9]*)" . '\\' .'\\' . "&amp;mId=([0-9]*)','" . '
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="600" height="336" id="MevioWM" align="middle"><param name="allowScriptAccess" value="never" /><param name="allowFullScreen" value="true" /><param name="movie" value="http://ui.mevio.com/widgets/mwm/MevioWM.swf?r=36745 " /><param name="quality" value="high" /><param name="FlashVars"     value="distribConfig=http://www.mevio.com/widgets/configFiles/distribconfig_mwm_pcw_default.php?r=36745&autoPlay=false&container=false&rssFeed=/%3FcId=$1%26cMediaId=$2%26format=json&playerIdleEnabled=false&fwSiteSection=DistribGeneric" /><param name="bgcolor" value="#000000" />	<embed src="http://ui.mevio.com/widgets/mwm/MevioWM.swf?r=36745 " quality="high" bgcolor="#000000"width="600" height="336" FlashVars="distribConfig=http://www.mevio.com/widgets/configFiles/distribconfig_mwm_pcw_default.php?r=36745&autoPlay=false&container=false&rssFeed=/%3FcId=$1%26cMediaId=$2%26format=json&playerIdleEnabled=false&fwSiteSection=DistribGeneric"name="MevioWM"align="middle"allowScriptAccess="never"allowFullScreen="true"type="application/x-shockwave-flash"pluginspage="http://www.macromedia.com/go/getflashplayer" /></object>

' . "')


", __FILE__, __LINE__);
//1.0.3

db_query("INSERT IGNORE INTO {$db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES

(18, 'Crackle', 'http://www.crackle.com', 'http://www.crackle.com/c/(.*)/(.*)/([0-9]*)','" . '
<embed src="http://www.crackle.com/p/$1/$2.swf" quality="high" bgcolor="#869ca7" width="500" height="281" name="mtgPlayer" align="middle" play="true" loop="false" allowFullScreen="true" flashvars="id=$3&mu=0&ap=0" quality="high" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer"> </embed>

' . "'),

(19, 'justin.tv', 'http://www.justin.tv', 'http://www.justin.tv/([A-Z0-9]*)(.*)','" . '
<object type="application/x-shockwave-flash" height="300" width="400" id="live_embed_player_flash" data="http://www.justin.tv/widgets/live_embed_player.swf?channel=$1" bgcolor="#000000"><param name="allowFullScreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="allowNetworking" value="all" /><param name="movie" value="http://www.justin.tv/widgets/live_embed_player.swf" /><param name="flashvars" value="channel=$1&auto_play=false&start_volume=25" /></object>

' . "'),

(20, 'SchoolTube', 'http://www.schooltube.com', 'http://www.schooltube.com/video/([A-Z0-9]*)/(.*)','" . '
<object width="500" height="375"><param name="movie" value="http://www.schooltube.com/v/$1" /><param name="allowFullScreen" value="true" /><param name="allowscriptaccess" value="always" /><embed src="http://www.schooltube.com/v/16483926ba522476e7ae" type="application/x-shockwave-flash" allowFullScreen="true" allowscriptaccess="always" width="500" height="375" FlashVars="gig_lt=1281633293655&gig_pt=1281633309820&gig_g=2"></embed> <param name="FlashVars" value="gig_lt=1281633293655&gig_pt=1281633309820&gig_g=2" /></object>

' . "'),


(21, 'MySpace', 'http://www.myspace.com', 'http://vids.myspace.com/index.cfm" . '\\' .'\\' . "?fuseaction=vids.individual" . '\\' .'\\' . "&amp;videoid=([0-9]*)','" . '
<object width="425px" height="360px" ><param name="allowFullScreen" value="true"/><param name="wmode" value="transparent"/><param name="movie" value="http://mediaservices.myspace.com/services/media/embed.aspx/m=$1,t=1,mt=video"/><embed src="http://mediaservices.myspace.com/services/media/embed.aspx/m=$1,t=1,mt=video" width="425" height="360" allowFullScreen="true" type="application/x-shockwave-flash" wmode="transparent"></embed></object>

' . "'),

(22, 'Mefeedia', 'http://www.mefeedia.com', 'http://www.mefeedia.com/watch/([0-9]*)','" . '
<iframe scrolling="no" frameborder="0" width="640" height="450" src="http://www.mefeedia.com/watch/$1&iframe"></iframe>
' . "'),


(24, 'DailyMotion', 'http://www.dailymotion.com', 'http://www.dailymotion.com/video/([A-Z0-9]*)_(.*)','" . '
<object width="480" height="360"><param name="movie" value="http://www.dailymotion.com/swf/video/$1?additionalInfos=0"></param><param name="allowFullScreen" value="true"></param><param name="allowScriptAccess" value="always"></param><embed type="application/x-shockwave-flash" src="http://www.dailymotion.com/swf/video/$1?additionalInfos=0" width="480" height="360" allowfullscreen="true" allowscriptaccess="always"></embed></object>
' . "'),


(25, 'Clipfish.de', 'http://www.clipfish.de', 'http://www.clipfish.de/video/([0-9]*)/(.*)/','" . '
<object codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="464" height="384" > <param name="allowScriptAccess" value="always" /> <param name="movie" value="http://www.clipfish.de/cfng/flash/clipfish_player_3.swf?as=0&videoid=$1&r=1&area=e&c=990000" /> <param name="bgcolor" value="#ffffff" /> <param name="allowFullScreen" value="true" /> <embed src="http://www.clipfish.de/cfng/flash/clipfish_player_3.swf?as=0&vid=$1&r=1&area=e&c=990000" quality="high" bgcolor="#990000" width="464" height="384" name="player" align="middle" allowFullScreen="true" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></embed></object>

' . "'),

(26, 'Goear', 'http://www.goear.com', 'http://www.goear.com/listen/([A-Z0-9]*)/(.*)','" . '
<object width="353" height="132"><embed src="http://www.goear.com/files/external.swf?file=$1" type="application/x-shockwave-flash" wmode="transparent" quality="high" width="353" height="132"></embed></object>

' . "'),


(27, 'Clipmoon', 'http://www.clipmoon.com', 'http://www.clipmoon.com/videos/([0-9]*)/(.*).html','" . '
<embed src="http://www.clipmoon.com/flvplayer.swf" FlashVars="config=http://www.clipmoon.com/flvplayer.php?viewkey=$1&external=no" quality="high" bgcolor="#000000" wmode="transparent" width="460" height="357" loop="false" align="middle" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"  scale="exactfit" > </embed>

' . "')


", __FILE__, __LINE__);

// 1.0.4
db_query("INSERT IGNORE INTO {$db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(28, 'Stagevu', 'http://www.stagevu.com', 'http://stagevu.com/video/([A-Z0-9]*)','" . '
<iframe style="overflow: hidden; border: 0; width: 720px; height: 362px" src="http://stagevu.com/embed?width=720&amp;height=306&amp;background=000&amp;uid=$1" scrolling="no"></iframe>
' . "'),
(29, 'Mail.ru', 'http://www.mail.ru', 'http://video.mail.ru/mail/([0-9]*)/([0-9]*)/([0-9]*).html','" . '
<object width=626 height=367><param name="allowScriptAccess" value="always" /><param name="movie" value="http://img.mail.ru/r/video2/player_v2.swf?movieSrc=mail/$1/$2/$3" /><embed src=http://img.mail.ru/r/video2/player_v2.swf?movieSrc=mail/$1/$2/$3 type="application/x-shockwave-flash" width=626 height=367 allowScriptAccess="always"></embed></object>
' . "'),
(30, 'Twitvid', 'http://www.twitvid.com', 'http://www.twitvid.com/([A-Z0-9]*)','" . '
<object width="425" height="344"><param name="movie" value="http://www.twitvid.com/player/$1"></param><param name="allowscriptaccess" value="always"></param><param name="allowFullScreen" value="true"></param><embed type="application/x-shockwave-flash" src="http://www.twitvid.com/player/$1" quality="high" allowscriptaccess="always" allowNetworking="all" allowfullscreen="true" wmode="transparent" height="344" width="425"></object>
' . "'),
(31, 'Trtube', 'http://www.trtube.com', 'http://www.trtube.com/(.*)-([0-9]*).html','" . '
<object width="425" height="350"><param name="allowScriptAccess" value="always"><param name="movie" value="http://www.trtube.com/mediaplayer_3_15.swf?file=http://www.trtube.com/playlist.php?v=$2&image=http://resim.trtube.com/a/102/$2.gif&logo=http://load.trtube.com/img/logoembed.gif&linkfromdisplay=false&linktarget=_blank&autostart=false"><param name="quality" value="high"><param name="bgcolor" value="#ffffff"><param name="allowfullscreen" value="true"><embed src="http://www.trtube.com/mediaplayer_3_15.swf?file=http://www.trtube.com/playlist.php?v=$2&image=http://resim.trtube.com/a/102/$2.gif&logo=http://load.trtube.com/img/logoembed.gif&linkfromdisplay=false&linktarget=_blank&autostart=false" quality="high" bgcolor="#ffffff" allowfullscreen="true" width="450" height="370" name="player" align="middle" type="application/x-shockwave-flash" allowScriptAccess="always" pluginspage="http://www.macromedia.com/go/getflashplayer"></object>
' . "'),
(32, 'BlogTV', 'http://www.blogtv.com', 'http://www.blogtv.com/Shows/([0-9]*)/([A-Z_0-9]*)(.*)','" . '
<embed width="445" height="374" src="http://www.blogtv.com/vb/$2" type="application/x-shockwave-flash" allowFullScreen="true"></embed>
' . "'),
(33, 'MegaVideo', 'http://www.megavideo.com', 'http://www.megavideo.com/" . '\\' .'\\' . "?v=([A-Z_0-9]*)','" . '
<object width="640" height="344"><param name="movie" value="http://www.megavideo.com/v/$1.0.0"></param><param name="allowFullScreen" value="true"></param><embed src="http://www.megavideo.com/v/$1.0.0" type="application/x-shockwave-flash" allowfullscreen="true" width="640" height="344"></embed></object>
' . "'),
(34, 'VH1', 'http://www.vh1.com', 'http://www.vh1.com/video/(.*)/([0-9]*)/(.*).jhtml(.*?)','" . '
<embed src="http://media.mtvnservices.com/mgid:uma:video:vh1.com:$2" width="512" height="319" wmode="transparent" type="application/x-shockwave-flash" flashVars="configParams=vid%3D$2%26uri%3Dmgid%3Auma%3Avideo%3Avh1.com%3A$2%26instance%3Dvh1" allowFullScreen="true" allowScriptAccess="always" base="."></embed>
' . "'),
(35, 'BET', 'http://www.bet.com', 'http://www.bet.com/video/([0-9]*)','" . '
<embed src="http://media.mtvnservices.com/mgid:media:video:bet.com:$1" width="512" height="319" wmode="transparent" type="application/x-shockwave-flash" flashVars="" allowFullScreen="true" allowScriptAccess="always" base="."></embed>
' . "')


", __FILE__, __LINE__);            

/*
(23, 'MaYoMo', 'http://www.mayomo.com', 'http://www.mayomo.com/([0-9]*)-(.*)','" . '
<object id="flowplayer" width="480" height="360" data="http://www.mayomo.com/flash/flowplayer-3.1.5.swf" type="application/x-shockwave-flash"><param name="movie" value="http://www.mayomo.com/flash/flowplayer-3.1.5.swf" /><param name="allowfullscreen" value="true" /><param name="flashvars" value=\'\'config={"clip":{"autoPlay":false,"autoBuffering":true,"url":"http://c0368312.cdn.cloudfiles.rackspacecloud.com/$1.mp4"}}\'\' /></object>
' . "')
*/

?>