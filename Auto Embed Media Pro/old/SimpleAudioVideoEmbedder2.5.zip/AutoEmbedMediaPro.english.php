<?php
/*
Simple Audio Video Embedder
Version 2.1
by:vbgamer45
http://www.smfhacks.com

License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
*/

// Latest Version:
$txt['mediapro_txt_latestversion'] = 'Latest Version: ';
$txt['mediapro_txt_yourversion'] = 'Your Version: ';
$txt['mediapro_txt_version_outofdate'] = 'Your Simple Audio Video Embedder version is not up to date!<br /><a href=\"http://custom.simplemachines.org/mods/index.php?mod=2681\" target=\"_blank\">Download a the latest version now!</a>';

$txt['mediapro_txt_settings'] = 'Settings';
$txt['mediapro_txt_default_width'] = 'Default Video Player Width:';
$txt['mediapro_txt_default_height'] = 'Default Video Player Height:';
$txt['mediapro_txt_default_info'] = 'Use 0 to use media player defaults';

$txt['mediapro_txt_checkall'] = 'Check All';

$txt['mediapro_megauploadtometoday'] = 'MegaUpload/KimDotcom';
$txt['mediapro_megauploadsong'] = 'MegaUpload Song';
$txt['mediapro_megamegatribute'] = 'Tribute to MegaUpload';
$txt['mediapro_dedication'] = 'Dedicated to MegaUpload and Kim DotCom was great while it lasted and lived well.';
$txt['mediapro_megamegacopterandfire']  = 'New Zealand Fireworks 2011';
$txt['mediapro_megaracer']  = 'MegaRacer #1 Kills MW3';

$txt['mediapro_txt_copyright'] = 'Copyright';
$txt['mediapro_txt_copyrightremoval'] = 'Copyright Removal';
$txt['mediapro_txt_copyrightkey'] = 'Copyright Key';
$txt['mediapro_txt_ordercopyright'] = 'Order Copyright Removal';


$txt['mediapro_txt_copyremovalnote'] = 'Copyright removal removes the copyright line "Simple Audio Video Embedder"';


$txt['mediapro_disablesig'] = 'Disable embeding of signatures';
?>