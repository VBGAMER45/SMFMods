*******************************
Quick Register
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 1.1.3

Adds a Quick Registration form to the default template

Other mods can be found at SMFHacks.com
Include:
SMF Trader System
SMF Archive
SMF Staff
Reg Bar
SMF Gallery
SMF Email System
SMF Store


SMFHacks package server address is:
http://www.smfhacks.com