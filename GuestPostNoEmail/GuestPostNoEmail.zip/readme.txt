Guest Post No Email Field

For SMF 2.0.x

Adds an interface to turn off the email for guests posts

Found under Admin -> Posts and Topics -> Post Settings

License: BSD License