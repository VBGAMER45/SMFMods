<?php
/*
Post Scheduler
Version 1.0
by:vbgamer45
http://www.smfhacks.com
Copyright 2012 http://www.samsonsoftware.com
*/
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
  require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
  die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');


// Create Feeds Poster Table
$smcFunc['db_query']('', "CREATE TABLE IF NOT EXISTS {db_prefix}postscheduler
(ID_POST mediumint(8) NOT NULL auto_increment,
ID_BOARD smallint(5) unsigned NOT NULL default '0',
id_topic mediumint(8) unsigned NOT NULL default '0',
subject varchar(255),
body text NOT NULL,
postername tinytext,
ID_MEMBER mediumint(8) unsigned,
post_time int(10),
msgicon varchar(50) default 'xx',
locked tinyint(1) NOT NULL default '0',
hasposted tinyint(1) NOT NULL default '0',
PRIMARY KEY  (ID_POST),
KEY (post_time)
 )");


// Fake cron setting default false
$smcFunc['db_query']('', "INSERT IGNORE INTO {db_prefix}settings VALUES ('post_fakecron', '0')");



// Add the scheduled task
$dbresult = $smcFunc['db_query']('', "
SELECT 
	COUNT(*) as total 
FROM {db_prefix}scheduled_tasks
WHERE task = 'update_scheduleposts'");
$row = $smcFunc['db_fetch_assoc']($dbresult);
if ($row['total'] == 0)
{
	$smcFunc['db_query']('', "INSERT INTO {db_prefix}scheduled_tasks
	   (time_offset, time_regularity, time_unit, disabled, task)
	VALUES ('0', '1', 'h', '0', 'update_scheduleposts')");
}

?>