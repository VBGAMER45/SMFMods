*******************************
Post Scheduler
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 


Allows you to schedule posts to post on a certain date
You can either use a real cron job, Or you can run cron jobs via php
Using the following file
http://www.yourforums.com/cronpost.php


Setup unlimited number of posts
Set Poster Name Or Member Id for post
Option to select message icon
Option to lock topics


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Downloads System
EzPortal.com


SMFHacks package server address is:
http://www.smfhacks.com

Licensed under: https://creativecommons.org/licenses/by-nd/4.0/ Attribution-NoDerivs
CC BY-ND 