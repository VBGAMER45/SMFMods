Mudim is a Vietnamese writing script on Javascript that integrates into web pages. Mudim was developed based on MrChuoi's CHIM percussion , in addition to consulting ideas and thus bringing many advantages of other percussion types of the same type. Combined, Mudim is an exceptionally easy-to-use, installable keyboard for web developers as well as handy for website visitors.

For even more convenience for those who use the Firefox browser, Mudim has a version of Firefox Extension directly integrated into Firefox, which lets you type Vietnamese on any web page, especially without conflict with the integrated percussion on the page. web if available.

In the process of using if you have any comments or questions, please read the wiki page in the right column, if the question is not answered, please create a new item in the Issues page , but you should also look In previous issues, there may be people who have come up with the same idea.

You can also visit the PhanHoi page for opinions of people who have successfully implemented Mudim. If you have successfully applied Mudim to your site, go there to introduce people.

Function
The control panel is very convenient
Save your settings corresponding to each site (you need to accept cookies)
Supports 3 popular input methods Telex, VNI and VIQR.
Uncheck the new rule (recommended) or if you really dislike this unchecked type, you can switch back to the old unmarking rule.
Intelligent diacritic function, automatically unmarked in place
Works well on many popular web browsers (Firefox, Internet Explorer, Opera, Konqueror)