Refferal System

Supports SMF 2.0.x and SMF 1.1.x

This mod allows you track how many people a member has reffered to the forum.
Tracks by either a cookie or the username entered on registration.


Changelog.txt
3.1
+Now recording the data of the referral