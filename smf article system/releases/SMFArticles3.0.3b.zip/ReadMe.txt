*******************************
SMF Article System
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x and SMF 2.0.x AND SMF 1.1.x

An SMF Article System for SMF
-Articles with bbcode
-Article categories
-Rating of articles
-Comments on articles
-Searching and my articles function


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Trader System
SMF Links
SMF Classifieds
NewsLetter Pro
SMF Store
EzPortal
Downloads System Pro
Community Suite
Ad Seller Pro

SMFHacks package server address is:
http://www.smfhacks.com