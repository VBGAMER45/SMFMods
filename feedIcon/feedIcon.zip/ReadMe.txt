*******************************
Feed Icon Board Index
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x, SMF 2.0.x AND SMF 1.1.x

Adds a RSS Feed Icon to the Board Index for each board. Allows users to easly subscribe to an RSS feed.

Version 1.1
Added support for child boards.


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Trader System
SMF Archive
SMF Staff
Avatar Select
SMF Classifieds
Newsletter Pro
Ad Seller Pro

SMFHacks package server address is:
http://www.smfhacks.com