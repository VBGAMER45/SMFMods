[center][color=red][size=16pt][b]SMFShop 3.1.4 Installation[/b][/size][/color][/center]

[color=blue][b][size=12pt]Introduction[/size][/b][/color]
This MOD will add a cash system to your forum, and a shop to go with it. With this shop, members can 'purchase' various items using the cash (credits) obtained by posting in your forum.
This is the FRESH INSTALL package!

[color=blue][b][size=12pt]Changes in this release[/size][/b][/color]
[b]Major:[/b]
 - Support for SMF 2.0 RC 2
[color=blue][b][size=12pt]Internal Server Error?[/size][/b][/color]
Please read the following BEFORE you install.

If you get a 'Internal Server Error' message while installing (this happens rarely, but does happen), do the following:
  1. Proceed with installation until "Internal Server Error" page appears. LEAVE THIS PAGE AS IS.
  2. FTP into your account. Look for the folder which has been chmodded to 777. This is typically the root folder of your forum. (eg. /public_html/forums)
  3. CHMOD the directory back to 755.
  4. Refresh the "Internal Server Error" page. You may need to : a) IE - hold CTRL and press Refresh; b) Firefox - hold SHIFT and press Reload.


(c) 2009-2010 http://www.smfhacks.com
(c) 2005, 2006, 2007 DanSoft Australia - http://www.dansoftaustralia.net/
Version: 3.1.4 (Build 23)
Release Date: 14th November 2009