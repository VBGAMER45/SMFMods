[center][color=red][size=16pt][b]SMFShop 3.0 Installation[/b][/size][/color][/center]

[color=blue][b][size=12pt]Introduction[/size][/b][/color]
This MOD will add a cash system to your forum, and a shop to go with it. With this shop, members can 'purchase' various items using the cash (credits) obtained by posting in your forum.
This is the FRESH INSTALL package. If you've installed SMFShop 2.3, please download the SMFShop 2.3 to 3.0 update package instead!

[color=blue][b][size=12pt]Changes in this release[/size][/b][/color]
[b]Major:[/b]
 - Lots of code cleanup
 - Category support: You can now categorise your items
 - Permissions: You can disable access to the shop for certain membergroups
 - Bonuses per character and word: Give bonuses to a user depending on the number of characters or words in their post
 - Bank deposit/withdrawl fees
 - Option to not delete item after use: Great for items you'd like members to keep
 - When editing an item, you can now edit the item_info (custom info entered when adding the item)
 
[b]Minor[/b]
 - Several minor formatting changes
 - Fixed problem with SMF 1.1's "Find Members" popup
 - Bold the current section on the left menu
 - In "10 Richest Members" list, have links to their profiles
 - When sending an item to someone, show an error if they don't exist
 - Allow floating point values for interest
 - And several other (minor things)

[color=blue][b][size=12pt]Internal Server Error?[/size][/b][/color]
Please read the following BEFORE you install.

If you get a 'Internal Server Error' message while installing (this happens rarely, but does happen), do the following:
  1. Proceed with installation until "Internal Server Error" page appears. LEAVE THIS PAGE AS IS.
  2. FTP into your account. Look for the folder which has been chmodded to 777. This is typically the root folder of your forum. (eg. /public_html/forums)
  3. CHMOD the directory back to 755.
  4. Refresh the "Internal Server Error" page. You may need to : a) IE - hold CTRL and press Refresh; b) Firefox - hold SHIFT and press Reload.


(c) 2009 vbgamer45 SMFHacks.com
(c) 2005, 2006, 2007 DanSoft Australia - http://www.dansoftaustralia.net/


More mods can be found at SMFHacks.com
SMF Gallery
SMF Store
SMF Classifieds
Newsletter Pro
Downloads System Pro
EzPortal