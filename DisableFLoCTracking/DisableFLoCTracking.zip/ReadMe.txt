*******************************
Disable FLoC Tracking
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information:
For SMF 2.1.x and SMF 2.0.x A

Disable's Google's new cookieless ad tracking system called FloC.


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Trader System
SMF Archive
SMF Staff
Avatar Select
SMF Classifieds
Newsletter Pro
Ad Seller Pro

SMFHacks package server address is:
http://www.smfhacks.com