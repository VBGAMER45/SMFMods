*******************************
User Email System
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 1.1.x and SMF 1.0.x
Replaces all user email links in their profile to email form.
This helps stop against spammers from harvesting email links.

There is permission called Send User Email and you need to enable it for each membergroup you want to have it.

Version 1.3
Changed the from email address when a sender is sending an email

Version 1.1.3
Moved text strings to language files
Added CAPTCHA support for SMF 1.1.x

Version 1.1.2
Added better guest email support


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
SMF Trader System
SMF Archive
SMF Staff
Reg Bar
Avatar Select


SMFHacks package server address is:
http://www.smfhacks.com