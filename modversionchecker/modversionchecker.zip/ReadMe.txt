*******************************
Mod Version Checker
Packaged By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x and SMF 2.0.x

Adds a system to auto check for updates for modifications that are installed from simplemachines.org mod site.

Install Information:
Install via the SMF's Package Manager via upload package.


Other mods can be found at SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
Download System Pro
SMF Store
Newsletter Pro
