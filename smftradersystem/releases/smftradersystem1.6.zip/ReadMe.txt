**************************************
SMF Trader System
http://www.smfhacks.com
**************************************

Contents:

1. About
2. Requirements
3. License
4. Contact


1. About
   SMF Trader System - Is a trader system for the Simple Machines Forum software.

2. Requirements   
   Currently SMF Trader System supports SMF Versions
   SMF 1.1.x and 1.0.x and SMF 2.0.x

3. License
   Just keep the textlink to smfhacks.com in the files and the templates.

4. Contact
   For support and more information visit http://www.smfhacks.com

Other Mods
SMF Gallery
SMF Store
SMF Links
Staff Page Mod
SMF Classifieds
SMF Store
Newsletter Pro
EzPortal
Downloads Pro
Ad Seller Pro
