**************************************
SMF Trader System
https://www.smfhacks.com
**************************************

Contents:

1. About
2. Requirements
3. License
4. Contact


1. About
   SMF Trader System - Is a trader system for the Simple Machines Forum software.

2. Requirements   
   Currently SMF Trader System supports SMF Versions
   SMF 2.1.x, SMF 2.0.X, SMF 1.1.

3. License
   Just keep the textlink to smfhacks.com in the files and the templates or buy copyright removal at https://www.smfhacks.com

4. Contact
   For support and more information visit https://www.smfhacks.com

Other Mods
SMF Gallery
SMF Store
SMF Links
SMF Classifieds
SMF Store
Newsletter Pro
EzPortal
Downloads Pro
Ad Seller Pro
