[center][size=4][color=green]Board PageRank Mod v1.0 - vicram10[/color][/size]
[color=green]Display PageRank of your forum, into ManageBoards[/color][/center]

[b]Author[/b]:
- vicram10

[color=blue][b]Detalles - English[/b]:[/color]
o Display PageRank of your forum, into ManageBoards
[b]o Support only SMF 1.1.X[/b]

[color=red][b]Detalles - Espa�ol[/b]:[/color]
o Visualizacion del PageRank de cada Foro, dentro del Manejador de Foros en Administracion
[b]o Soporte o compatibilidad solo para las versiones SMF 1.1.X[/b]

[color=green][b]Manual Installation / Instalacion Manual[/b]:[/color] in the [b]ZIP[/b]

[b]Visit:[/b] [url=http://www.customsmf.net][color=red][b]CustomSMF[/b][/color][/url]

