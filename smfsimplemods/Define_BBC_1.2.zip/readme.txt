[size=12pt][color=#8811FF][b]Define BBC[/b][/color][/size]

[hr][b]Author: [url=http://www.simplemachines.org/community/index.php?action=profile;u=263975]S-M-F Modders Team[/url][/b]
[b]Latest Version:[/b] 1.2
[b]Compatible With SMF:[/b] 1.1.11, 1.1.12, 2.0 RC3, 2.0 RC4
[b]Website:[/b] [url=http://www.smfmodders.com]SMFModders.com[/url][hr]


[hr][size=12pt][color=#8811FF]Summary[/color][/size][hr]
The define BBC mod allows you to define words within a post, by simply wrapping the define BBC tags around any word.

[color=#8811FF]Primary Tags:[/color]
[define]Simple Machines[/define]

[color=#8811FF]Alternative Tags:[/color]
[define=Simple Machines]What's up?[/define]

Note that no tags may be nested inside the [define][/define] tags or it will break the link.

SMFModders.com, nor any of it's team is affiliated with Dictionary.com.
[hr]


[hr][size=12pt][color=#8811FF]Languages[/color][/size][hr]
[img]http://www.simplemachines.org/site_images/lang/english.gif[/img]
[hr]


[hr][size=12pt][color=#8811FF]Installation[/color][/size][hr]
[b]Package Manager[/b] should work in most cases. If you need to make any edits, the full list can be obtained from the Parse function on the right.

[b]Useful links[/b]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]
[hr]


[hr][size=12pt][color=#8811FF]Support[/color][/size][hr]
Questions should be addressed to the designated support topic for the mod on [url=http://www.smfmodders.com]SMFModders.com[/url].

[url=http://smfmodders.com/index.php?board=15.0]Mod Support Board[/url]
[hr]


[hr][size=12pt][color=#8811FF]1.3 Changelog[/color][/size][hr]
[b][color=green]+[/color][/b]) 1.1.12 Compatibility Added
[b][color=green]+[/color][/b]) 2.0 RC4 Compatibility Added
[b][color=green]+[/color][/b]) Multiple Bugfixes
[hr]


[hr][size=12pt][color=#8811FF]Files modified by Define BBC[/color][/size][hr]
[b]SMF 2.0 RC3, & SMF 2.0 RC4[/b]
[b][i]Source Files (./Sources)[/i][/b][list]
[li]Subs.php[/li]
[li]Subs-Editor.php[/li][/list]
[b][i]Language Files (./Themes/default/languages)[/i][/b][list]
[li]Modifications.english.php[/li][/list]
[b][i]Files Added[/i][/b][list]
[li]define_bbc.gif added to $imagesdir/bbc[/li][/list]
[b]SMF 1.1.11, & SMF 1.1.12[/b]
[b][i]Source Files (./Sources)[/i][/b][list]
[li]Subs.php[/li][/list]
[b][i]Template Files (./Themes/default)[/i][/b][list]
[li]Post.template.php[/li][/list]
[b][i]Language Files (./Themes/default/languages)[/i][/b][list]
[li]Modifications.english.php[/li][/list]
[b][i]Files Added[/i][/b][list]
[li]define_bbc.gif added to $imagesdir/bbc[/li][/list]
[hr]


[hr][url=http://custom.simplemachines.org/mods/index.php?mod=2572]Link to Mod[/url] | [url=https://www.paypal.com/cgi-bin/webscr&cmd=_s-xclick&hosted_button_id=10240245]Support the S-M-F Modders Team[/url][hr]