[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]IGNORE TOPICS[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[b]Created by[/b] [b][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=63186]Karl Benson[/url][/b]
[i][b]2.0.1[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Adds the ability to ignore individual topics for the purposes of RecentPosts/Recent/UnreadReplies/Unread sections of SMF.[/b][/i]
[b][color=red]�You will need to enable Quick Moderation to use the feature. (which enables the checkboxes)![/color][/b]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Agrega la funcionalidad de ignorar cada topic de la lista de Temas Recientes/Respuesta No Leidas/Temas No Leidos[/b][/i]
[b][color=red]�Debe activar la moderacion rapida para usar el mod (usando los checkboxes)![/color][/b]
[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
o IgnoreTopics Profile Section
- Select to Un-Ignore topics
- Un-Ignore All My Ignored Topics
o Settings (via Admin > Boards > Settings)
- Enable mod 
- (int) Limit allowed no. of ignored topics
- Function to Clear ALL ignored topics for all users.
o Permissions (Admin > Permissions
- Permission for ignore topics
- Permission to allow unlimited ignored topics
o Alters RecentPosts/Recent/UnreadReplies/Unread sections of SMF to enable Ignore Topics
o Need to enable your Quick Moderation checkboxes via Profile > Look and Layout

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
o Perfil Seccion: IgnoreTopics
- Seleccionar Designorar Temas
- Designorar todos los temas ignorados
o Configuracion: (via Admin > Boards > Settings)
- Habilitar Mod
- (int) Limitar el numero de temas ignorados
- Funcion que permite designorar todos los temas de todos los usuarios
o Permisos: Admin > Permissions
- Permisos para ignorar temas
- Permiso para ignorar ilimitados temas
o Necesita activar la moderacion rapida (Checkboxes) en Perfil > Look and Layout

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center]
[IMG]http://i.imgur.com/4yhP2.png[/IMG]	
[IMG]http://i.imgur.com/uprlE.png[/IMG]
[IMG]http://i.imgur.com/913Ub.png[/IMG]
[IMG]http://i.imgur.com/ycDhB.png[/IMG]
[IMG]http://i.imgur.com/oHl0S.png[/IMG]
[/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]
English & English British 
Spanish Latin - Es
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]IGNORE TOPICS[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]