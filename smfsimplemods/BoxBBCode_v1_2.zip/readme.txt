﻿[size=3][color=navy][b]Box BBCode v1.2[/b][/color][/size]
[hr]

[right][table]
[tr][td][color=navy][b]Compatible With:[/b][/color][/td][td]SMF 1.1.X - SMF 2 Beta & RC1[/td][/tr]
[tr][td][color=navy][b]Created By:[/b][/color][/td][td][url=http://www.simplemachines.org/community/index.php?action=profile;u=192278][b].LORD.[/b][/url][/td][td][/td][/tr]
[tr][td][color=navy][b]Version:[/b][/color][/td][td]1.2[/td][/tr]
[tr][td][/td][td][/td][/tr]
[tr][td][color=navy][b]Languajes:[/b][/color][/td]
[td][url=http://www.simplemachines.org/community/index.php?topic=296629.msg1980822#msg1980822]Swedish translation by Nas[/url]
[url=http://www.simplemachines.org/community/index.php?topic=296629.msg2011390#msg2011390]Spanish translation by phpMyTony[/url]
[/td][/tr]
[/table][/right]

[center]
[url=http://custom.simplemachines.org/mods/index.php?action=download;mod=1676;id=88630;image][color=navy]Image 1[/color][/url]
[url=http://custom.simplemachines.org/mods/index.php?action=download;mod=1676;id=88632;image][color=navy]Image 2[/color][/url][/center]

You can include boxes and separate the message text into sections.

You can also edit the style of the box using the css rule [b]box_bbcode[/b] or other styles through the attribute [b]class[/b].

After install you should do 'hard refresh'.

[b][color=navy]Version 1.1:[/color][/b] attribute [b]link[/b] added.
[b][color=navy]Version 1.2:[/color][/b] attribute [b]hlink[/b] added. Change validation in title (beta)

[b]Total Attributes:[/b]
[list]
[li]class[/li]
[li]title[/li]
[li]link[/li]
[li]hlink[/li]
[/list]

[size=1]
[box]Example[/box]

[box title=Abstract]Example[/box]

[box class=titlebg]Example[/box]

[box title=More Info: link=http://en.wikipedia.org/wiki/Simple_Machines_Forum]
Simple Machines Forum (abbreviated as SMF) is a freeware Internet forum application...[/box]

[box title=SMF link=http://www.simplemachines.org/community/index.php]
Example with link attribute.
[/box]

[box title=SMF hlink=http://www.simplemachines.org/community/index.php]
Example with hlink attribute.
[/box]
[/size]