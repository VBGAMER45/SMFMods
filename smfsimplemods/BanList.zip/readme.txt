[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Ban List[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[b]Created by[/b] [b][url=http://www.simplemachines.org/community/index.php?action=profile;u=118168][SiNaN][/url][/b]
[i][b]1.1.x and 2.0.1[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]This modification adds a new page showing the banlist. It also adds a permission for viewing it.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Agregar la posibilidad de ver una pagina con una lista de los usuarios baneados. Agrega permisos para decidir quien puede ver la lista[/b][/i]
[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]Members with view_banlist permissions can see the Lite Banlist[/li]
	[li]Members with manage_bans (& view_banlist) permissions will see the Extended Banlist[/li]
    [li]Banlist action in Who's Online only be displayed to users who can see the list.[/li]
	[li]Order List view in diferents ways[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Usuarios con permisos de view_banlist pueden ver la lista[/li]
	[li]Usuarios con permisos de manage_bans y view_banlist pueden ver una lista extendida[/li]
    [li]BanList accion en el Who's Online solo es mostrado a los usuarios con permisos para ver la lista[/li]
	[li]Ordenar la lista de varias formas distintas[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center]
[IMG]http://i.imgur.com/kkhTS.png[/IMG]
[IMG]http://i.imgur.com/HmJiG.png[/IMG]
[/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]
English
Spanish Latin - Es
[url=http://www.smfsimple.com/index.php/topic,4674]More Translations[/url]
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Ban List[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]