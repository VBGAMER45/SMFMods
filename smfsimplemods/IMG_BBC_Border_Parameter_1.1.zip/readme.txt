[size=12pt][color=#8811FF][b]IMG BBC Border Parameter[/b][/color][/size]

[hr][b]Author: [url=http://www.simplemachines.org/community/index.php?action=profile;u=263975]S-M-F Modders Team[/url][/b]
[b]Latest Version:[/b] 1.1
[b]Compatible With SMF:[/b] 1.1.11, 1.1.12, 2.0 RC2, 2.0 RC3, 2.0 RC4
[b]Website:[/b] [url=http://www.smfmodders.com]SMFModders.com[/url][hr]


[hr][size=12pt][color=#8811FF]Summary[/color][/size][hr]
This mod adds an optional "border" parameter to the IMG BBC tag.
[hr]


[hr][size=12pt][color=#8811FF]Languages[/color][/size][hr]
N/A (No strings added or modified)
[hr]


[hr][size=12pt][color=#8811FF]Installation[/color][/size][hr]
[b]Package Manager[/b] should work in most cases. If you need to make any edits, the full list can be obtained from the Parse function on the right.

[b]Useful links[/b]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]
[hr]


[hr][size=12pt][color=#8811FF]Support[/color][/size][hr]
Questions should be addressed to the designated support topic for the mod on [url=http://www.smfmodders.com]SMFModders.com[/url].

[url=http://smfmodders.com/index.php?board=15.0]Mod Support Board[/url]
[hr]


[hr][size=12pt][color=#8811FF]Changelog[/color][/size][hr]
[b][color=green]+[/color][/b]) SMF 2.0 RC4 Compatibility Added
[b][color=green]+[/color][/b]) SMF 1.1.12 Compatibility Added
[b][color=green]+[/color][/b]) SMF 1.1.11 Compatibility Added
[hr]


[hr][size=12pt][color=#8811FF]Files modified by IMG BBC Border Parameter[/color][/size][hr]
[b]SMF 2.0 RC3, & SMF 2.0 RC4[/b]
[b][i]Source Files (./Sources)[/i][/b][list]
[li]Subs.php[/li][/list]
[b][i]CSS Files (./Themes/default/css)[/i][/b][list]
[li]index.css[/li][/list]
[b]SMF 1.1.11, & SMF 1.1.12[/b]
[b][i]Source Files (./Sources)[/i][/b][list]
[li]Subs.php[/li][/list]
[hr]


[hr][url=http://custom.simplemachines.org/mods/index.php?mod=2771]Link to Mod[/url] | [url=https://www.paypal.com/cgi-bin/webscr&cmd=_s-xclick&hosted_button_id=10240245]Support the S-M-F Modders Team[/url][hr]