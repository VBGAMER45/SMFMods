[center][img width=443 height=115]http://bit.ly/kZVDB6[/img][/center]
[center]
[color=purple][size=16pt][b][BBCode] PlayStation Network[/b][/size][/color]
[b]Updated by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[b]Created by[/b] [b]JBlaze[/b]
[i][b]SMF 2.0 RC2, 2.0 RC3, 2.0.X[/b][/i][/center]
[hr]

[color=orange][size=13pt][b]Description:[/b][/size][/color]
[i][b]This mod will add a BBCode for posts, sigs, etc. It will display a PSN GamerCard from PlayStation.

When entering the BBCode on posts and sigs, use the follwing example:
[psn]JBlaze+of+EK[/psn]

Make sure all spaces are replaced with a plus sign (+).[/b][/i]

[color=orange][size=13pt][b]Descripcion:[/b][/size][/color]
[i][b]Este mod agregar un BBCODE para los posts, firmas, etc el cual mostrara una PSN GAMECARD de playstation.

Cuando ingreses el bbcode sigue este ejemplo:
[psn]JBlaze+of+EK[/psn]

Asegurandote de que si hay espacios en blancos sean remplazados por "+".[/b][/i]

[hr]
[center][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/center]
[center]
[img width=600 height=428]http://i.imgur.com/PJr72.png[/img]

[IMG]http://i.imgur.com/bVKTk.png[/img]
[/center]

[hr]

[color=teal][b]Language Support | Lenguajes Soportados[/b][/color]
[color=teal][b]

- English
- Spanish_latin
- Spanish_latin
- Spanish_es[/b][/color]