[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Auto Refresh Who Online (action=who)[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.simplemachines.org/community/index.php?action=profile;u=171824]Vicram10[/url] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]With this mod, you can determinate, how many seconds the "who online" is  automaticly refresh
[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Con este mod, tu puedes determinar, cuantos segundos el "Quien Esta en Linea" se actualiza automaticamente[/b][/i]

[hr]
[glow=black,2,300][color=orange][size=13pt][u][b]Settings/Configuracion:[/b][/u][/size][/color][/glow]
o SMF 1.1.X => Admin ---> Feature and Options
o SMF 2.0   => Admin ---> Feature and Options

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Auto Refresh Who Online (action=who)[/b][/size][/color][/glow][/center]