[center][color=blue][size=4][color=green]CueTable BBCode Mod v1.0.0 - vicram10[/color][/size][/color]
[color=green]Special CueTable Player For Other Forums On The Web[/color][/center]
[hr]
[b]Author[/b]:
- vicram10

[color=red][b]Detalles[/b]:[/color]

CueTable is a free billiard diagramming tool for communication, practice training and studies of strategy between players.
Think of it as a virtual canvas that gives everyone the ability to diagram billiard shots in a visually accurate and dynamic way.
Through its advanced features, table diagrams can be readily charted, saved, emailed, posted, blogged, and archived to the far reaches of the Web.
[b]Oficial WebSite:[/b] http://talk.cuetable.com/

[b]Compatible with 1.1.X[/b]


[color=red][b]Rules for Post your Cuetable Layout[/b]:[/color]

You can post, direct link [b]http://CueTable.com/P/?@4DPmn3GXSK3HGys3IMGd4PFUI3bXSK2beGA2beGA4kFUI3kUYJ2kUjb@[/b]. 

[center][b]Example:[/b] [color=green][b][cuetable][/b][/color]http://CueTable.com/P/?@4DPmn3GXSK3HGys3IMGd4PFUI3bXSK2beGA2beGA4kFUI3kUYJ2kUjb@[b][color=green][/cuetable][/color]
[/center]

Or you can post in this way [b]http://CueTable.com/P/?[color=blue]@4DPmn3GXSK3HGys3IMGd4PFUI3bXSK2beGA2beGA4kFUI3kUYJ2kUjb@[/color][/b], copie ID. 

[center][b]Example:[/b] [color=green][b][cuetable][/b][/color]@4DPmn3GXSK3HGys3IMGd4PFUI3bXSK2beGA2beGA4kFUI3kUYJ2kUjb@[color=green][b][/cuetable][/b][/center]

[hr]

[color=blue][b]Detalles - Spanish[/b]:[/color]

CueTable es una herramienta de diagramaci�n gratuita para la comunicaci�n, la pr�ctica de formaci�n y estudios de estrategia entre los Jugadores. 
Piensa que es como un lienzo virtual que ofrece a todos la capacidad de diagrama en un billar disparos precisos y visualmente din�mica. 
A trav�s de sus caracter�sticas avanzadas, el cuadro puede ser f�cilmente diagramas de trazado, guardado, por correo electr�nico, enviar, Blogged, archivados 
y ahora llega a la de la Web.
[b]Pagina Oficial:[/b] http://talk.cuetable.com/

[b]Compatible solo con las versiones 1.1.X[/b]


[color=red][b]Reglas para Postear el Diagrama de tu Cuetable[/b]:[/color]

Puedes postear, introduciendo el link directo [b]http://CueTable.com/P/?@4DPmn3GXSK3HGys3IMGd4PFUI3bXSK2beGA2beGA4kFUI3kUYJ2kUjb@[/b]. 

[center][b]Ejemplo:[/b] [color=green][b][cuetable][/b][/color]http://CueTable.com/P/?@4DPmn3GXSK3HGys3IMGd4PFUI3bXSK2beGA2beGA4kFUI3kUYJ2kUjb@[b][color=green][/cuetable][/color]
[/center]

O puedes postear, de la siguiente manera [b]http://CueTable.com/P/?[color=blue]@4DPmn3GXSK3HGys3IMGd4PFUI3bXSK2beGA2beGA4kFUI3kUYJ2kUjb@[/color][/b], copiando el ID de tu CueTable. 

[center][b]Ejemplo:[/b] [color=green][b][cuetable][/b][/color]@4DPmn3GXSK3HGys3IMGd4PFUI3bXSK2beGA2beGA4kFUI3kUYJ2kUjb@[color=green][b][/cuetable][/b][/center]

[hr]

[b]Visit:[/b] [url=http://www.customsmf.net][color=red][b]CustomSMF[/b][/color][/url] 



