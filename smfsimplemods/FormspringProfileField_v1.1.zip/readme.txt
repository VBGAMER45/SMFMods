The Formspring Profile Field modification creates a new textfield in the profile template for entering formspring usernames. This mod is configured just like other networking fields such as MSN, AIM, etc.

[b]Created by [url=http://www.simplemachines.org/community/index.php?action=profile;u=164151]Project Evolution[/url][/b]