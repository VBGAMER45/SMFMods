[center][color=blue][size=4][color=green]GoogAd Mod - vicram10[/color][/size][/color]
[color=green]Add Advertising in your Message Body[/color][/center]
[hr]
[b]Author[/b]:
- vicram10

[b]Changelog[/b]:
[list]
[li]
1.4
[list]
[li]Compatible with SMF 2.0[/li]
[/list]
[/li]
[li]
1.3
[list]
[li]Compatible with SMF 2.0 RC5[/li]
[/list]
[/li]
[li]
1.2
[list]
[li]Compatible with SMF 2.0 RC4[/li]
[/list]
[/li]
[li]
1.1
[list]
[li]Fix bug (wap, wap2, imode version)[/li]
[li]No need to uninstall the previous version, just install the new package[/li]
[/list]
[/li]
[li]
1.0
[list]
[li]Initial Release[/li]
[/list]
[/li]
[/list]

[b]Features[/b]:
[list]
[li]
Add advertising in your Message Body
[list]
[li][b]Adapts to any theme[/b][/li]
[li]Enable/Disable the GoogAd mod[/li]
[li]Only Show the visitors or not (users and visitors)[/li]
[li]Select the position to show the advertising[/li]
[li]Show only in the first Post or not (first post and replies)[/li]
[/list]
[/li]
[li][b]Support for SMF 2.0 RC2+[/b][/li]
[/list]

[b]Languages[/b]
[img]http://www.simplemachines.org/site_images/lang/english.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/russian.gif[/img][img]http://www.simplemachines.org/site_images/lang/italian.gif[/img]

[list]
[li]Russian� by [url=http://www.simplemachines.org/community/index.php?action=profile;u=229017]Bugo[/url][/li]
[li]Italian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=286972]bruce86[/url][/li]
[/list]
[hr]

Visit 
[list]
[li][url=http://www.smfsimple.com][color=red][b]SMFSimple.com[/b][/color][/url][/li]
[/list]