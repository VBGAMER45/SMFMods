<?php
global $scripturl;
$txt['fblike_admin_title'] = 'FBLikes Mod';
$txt['fblike_admin_title_desc'] = 'Configuracion FBLikes Mod';
$txt['fblike_enable'] = 'Habilitar FBlike';
$txt['fblike_guest_can'] = 'Mostrar a invitados';
$txt['fblike_message_unhide'] = 'Mostrar contenido cuando se responde';
$txt['fblike_count'] = 'Tiempo para refrescar la pagina';
$txt['fblike_count_seconds'] = 'Segundos';
$txt['fblike_button_lang'] = 'FB Lenguage';
$txt['fblike_bbc'] = 'Esconder contenido con facebook';
$txt['fblike_all_ok'] = 'Gracias por compartir, ahora podras ver el contenido!!';
$txt['fblike_all_bad'] = 'Algo salio mal, contacte al administrador';
$txt['fblike_hidden_txt'] = 'Este contenido esta oculto, para verlo debera clickear el icono de facebook';
$txt['fblike_guest_txt'] = 'Los visitantes no podran ver el contenido, Por favor <a href="'.$scripturl.'?action=register">Registrese</a> o <a href="'.$scripturl.'?action=login">Ingrese</a>';