<?php
global $scripturl;
$txt['fblike_admin_title'] = 'FBLikes Mod';
$txt['fblike_admin_title_desc'] = 'FBLikes Mod Settings';
$txt['fblike_enable'] = 'Enable FBlike';
$txt['fblike_guest_can'] = 'Show to guests';
$txt['fblike_message_unhide'] = 'Unhide When topic reply';
$txt['fblike_count'] = 'Time before reload the page';
$txt['fblike_count_seconds'] = 'Seconds';
$txt['fblike_button_lang'] = 'FB Language';
$txt['fblike_bbc'] = 'Hide content using facebook';
$txt['fblike_all_ok'] = 'Thanks for sharing, now you can see the content!!';
$txt['fblike_all_bad'] = 'Something went wrong, contact the administrator';
$txt['fblike_hidden_txt'] = 'This content is hidden, if you want to see you need to click in facebook button';
$txt['fblike_guest_txt'] = 'The guest can\'t se this content, Please <a href="'.$scripturl.'?action=register">Register</a> or <a href="'.$scripturl.'?action=login">Logging</a>';