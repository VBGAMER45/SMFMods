[center][img width=443 height=115]http://bit.ly/kZVDB6[/img]

[glow=black,2,300][color=purple][size=16pt][b]Facebook Likes Hide[/b][/size][/color][/glow]
[b]Developed by [url=http://www.smfsimple.com/index.php?action=profile;u=55]4Kstore[/url] for [url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0 - 2.0.X[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com
Official Support in [url=http://www.SmfSimple.com]www.SmfSimple.com[/url][/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]With this mod you can hide content selected in any post and will only be visible if you click on the facebook like button[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Con este mod podras ocultar contenido que selecciones dentro de cualquier post y solo sera visible si se da click en el boton me gusta de facebook[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
1. Hooks used
2. Enable - Disable
3. Allow users to unhide the topic when they replied to 
4. Show the button to guests
5. Time before reload the page
6. Facebook lang

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
1. Usa Hooks
2. Habilitar - Deshabilitar mod
3. Permitir a los usuarios ver el contenido oculto si responden al topic
4. Mostrar el boton a los invitados
5. Tiempo antes de recargar la pagina
6. Configurar el idioma de Facebook

[color=teal][u][b]IMAGENES | IMAGES[/b][/u][/color]
[IMG]http://i.imgur.com/WITTp.png[/IMG]

[IMG]http://i.imgur.com/dPwt4.png[/IMG]

[IMG]http://i.imgur.com/2Y0pS.png[/IMG]

[IMG]http://i.imgur.com/svgzj.png[/IMG]

[IMG]http://i.imgur.com/KOyLA.png[/IMG]

[hr]
[IMG]http://i.imgur.com/WITTp.png[/IMG]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]English & Spanish[/b][/color]
[hr]

[color=purple][size=14pt][b]Settings[/b][/size][/color]
Administration Center � Modification Settings � FBlikes Mod
(index.php?action=admin;area=modsettings;sa=Fblike)

[color=red][size=14pt][b]Notes:[/b][/size][/color]
This Mod Uses Jquery.
This Mod Uses CSS3.
This Mod Uses Hooks.

[color=purple][size=14pt][b]License:[/b][/size][/color]
 * This SMF modification is subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this SMF modification except in compliance with
 * the License. You may obtain a copy of the License at
 * [url=http://www.mozilla.org/MPL/]http://www.mozilla.org/MPL/[/url]
 
[center][glow=black,2,300][color=green][size=15pt][b]Facebook Likes Hide[/b][/size][/color][/glow][/center]