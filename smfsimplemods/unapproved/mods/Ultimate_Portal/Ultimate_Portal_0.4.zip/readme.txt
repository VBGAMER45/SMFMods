[center][img width=600 height=80]http://www.smfsimple.com/img/ultimateportallogo.png[/img][/center][center][color=orange][size=12pt][b]Ultimate Portal By Smfsimple Ya esta Aqui![/b][/size][/color][/center][center]Ultimate Portal 0.3 esta disponible para la version estable de SMF. [color=red][b]SMF 2.0[/b][/color][/center][color=orange][size=12pt][b]Caracteristicas generales UP 0.3:[/b][/size][/color]
o Es totalmente gratuito! 
o Consta de soporte gratuito las 24hs del dia!
o Se adapta perfectamente a cualquier estilo que tu foro tenga.
o La administracion es sumamente intuitiva, no necesitaras ser un experto para conseguir lo que quieras para tu foro!

[color=orange][size=12pt][b]Que tiene la version 0.3 que no tenga la 0.2?[/b][/size][/color]
La version 0.3 de ultimate Portal se redise&#241;o para que el portal tenga un mejor rendimiento y dise&#241;o en todo aspecto.
Se agrego el idioma espa&#241;ol por defecto para que no tengas que instalar paquetes de idiomas aparte.
Se repararon peque&#241;os bugs encontrados que afectaban al ssi y al wap.

[color=orange][size=10pt][b]Nuevos bloques por defecto de la version 0.3![/b][/size][/color]
o Bloque "Ultimos Usuarios" (Con este bloque tendras un listado de los ultimos usuarios registrados en tu foro)
o Bloque "Temas recientes" (Muestra tus temas mas recientes en un bloque de tu portal) 

[color=orange][size=12pt][b]Caracteristicas Avanzadas UP 0.3[/b][/size][/color]
o Podras administrar tus bloques y editarlos a tu medida con un sofisticado sistema de edicion unico!
o Podras desactivar o activar UP con un solo click.  
o Podras editar tus archivos de lenguaje directamente desde la administracion del porta!  
o Podras editar los permisos para cada rango de usuario. Tu puedes ocultar/mostrar modulos en funcion de lo que tu foro requiera. 
o Tendras la opcion de activar el PORTAL MENU, quien se encargara de generar un menu muy elegante tanto en un bloque como tambien en el top de tu foro, suplantando al slogan de tu foro. 
o Podras usar las mejores tecnicas SEO directamente configurando UP con unos pocos clicks! Configura tu robot.txt, tus keywords, introduce tu codigo Google Analytics y muchas opciones mas! 

[hr]
[center][color=orange][size=12pt][b]Y como si esto fuera poco! Todavia queda muchisimo mas para contarles![/b][/size][/color][/center][color=orange][size=12pt][b]Nuevas Caracteristicas UP 0.3[/b][/size][/color]
o MultiBlok Up! Con multiblok Up podras tener el portal que tanto querias, adaptando mas de 1 bloque por columna o fila, lo que hara que el estilo de tu portada sea unico y no redundante como hasta ahora los conociamos!
o Reduccion de sobrecarga de tu sitio mediante 1 solo click! De esta manera tu podras reducir la sobrecarga (las consultas a la base de datos es solo una ves cada 30 minutos) del Portal.
o Nuevo estilo del administrador de modulos![center][color=orange][size=12pt][b]Queres mas?[/b][/size][/color][/center]o Edicion de las cadenas de idioma desde el panel de administracion: olvidate de temblar al abrir archivos php.
o Creacion de paginas internas: Si quieres agregar informacion extra, hazlo desde la comodidad del Panel del Ultimate Portal.
o SEO: Seguimiento de estadisticas, improve title, Creacion de archivo robots.txt
o Permisos: Decide quien puede ver determinados bloques, con un par de clicks.
o Bloque afiliados, Seccion Quienes Somos (About us), Sistema de descargas, chat,..

Ademas es un completo portal con caracteristicas de linksharing, con el cual no tendras que hacer mayores cambios para compartir informacion.
o Novedades en portada, con un novedoso estilo[center][color=orange][size=12pt][b]Bloques por defecto de Ultimate Portal[/b][/size][/color][/center]o Afiliados
o Menu del Portal
o Noticias (Bloque propio del Modulo Noticias)
o Usuarios en Linea
o Menu Personal
o Estadisticas del Sitio

[center][color=orange][size=12pt][b]Modulos por defecto del Ultimate Portal[/b][/size][/color][/center]
o Aportes destacados (Greats Posts Module, Modulo especializado y desarrollado enteramente por vicram10, especial para los Foros del tipo Link Sharing)
o Noticias (NEWS)
o Noticias del Foro (Boards News)
o Descargas (Download Module)
o Paginas Internas (Internal Page Module)
o Afiliados (Affiliates Module)
o Quienes Somos (About Us Module)
o Preguntas Frecuentes (FAQs Module)

 * OBS: Los bloques y modulos puede aumentar, no seran solo esto, dependera de lo que se vaya agregando en el transcurso del desarrollo del portal.[center][color=orange][size=12pt][b]Administrador de Bloques[/b][/size][/color][/center]Ultimate Portal, cuenta con un Area de Administracion de bloques, facil, he intuitivo en su forma de uso. Dentro de esta area del panel de Administracion del Ultimate Portal puedes hacer lo siguiente:
 [list]
	[li][u]Posicion de los Bloques[/u]: de esta forma tendras una alta facilidad de configuracion del orden y activacion de cualquier bloque que se quiera usar dentro de Ultimate Portal ([url=http://www.ultimate-portal.net/image/blocks/admin-block-position.jpg][b]Ver Grafica[/b][/url])[/li]
	[li][u]Titulos de los Bloques[/u]: en esta zona, tendras la facilidad de establecer titulos diferentes para cada bloque ([url=http://www.smfsimple.com/img/ultimateportal/admin-block-title.jpg][b]Ver Grafica[/b][/url])[/li]
	[li][u]Crear Bloque[/u]: zona en la que podras crear tus propios bloques personalizados ([url=http://www.smfsimple.com/img/ultimateportal/admin-block-create.jpg][b]Ver Grafica[/b][/url]), tanto en forma de HTML ([url=http://www.smfsimple.com/img/ultimateportal/admin-block-html.jpg][b]Ver Grafica[/b][/url]) o creando bloques PHP ([url=http://www.smfsimple.com/img/ultimateportal/admin-block-php.jpg][b]Ver Grafica[/b][/url])[/li]
	[li][u]Administrando Bloques[/u]: en esta area ([url=http://www.smfsimple.com/img/ultimateportal/admin-block.jpg][b]Ver Grafica[/b][/url]), tendras entera disposicion de los bloques tanto del Sistema (Bloques por defecto), asi como los bloques personalizados (Bloques hechos por ustedes), podran: Asignarle permisos[/li]
[/list][list]
	[li]Asignarle Permisos: de esta forma, tendras entera facilidad de permitir que grupos de usuarios tendran derecho de visualizar el bloque creado.[/li]
	[li]Editar Bloques[/li]
	[li]Borrar Bloques[/li]
[/list] 

Todos los bloques que sean agregados en la Zona de Bloques, tendra su autoinstalador, simplemente usando el [b]Instalador de Paquetes de SMF ([/b]regla obligatoria[b]).[/b]

[hr]
[center][color=green][size=12pt][b]Por todo esto y mucho mas que no podemos explicar porque se haria tan largo el tema que seria mejor descargar el portal y probarlo! Ya no les quedarian dudas de que Ultimate Portal (UP para los amigos)  es el portal que todos estaban buscando![/b][/size][/color][/center]
[b][url=https://www.smfsimple.com]SMFSimple[/url][/b] agradece a todos los que ayudaron a hacer [b] Ultimate Portal[/b] lo que es hoy.

[b]Fundador de Ultimate Portal y Director del proyecto:[/b] Victor "vicram10" Ramirez 

[b]Staff:[/b] vicram10, Lean, 4kstore & Distante. 

[b]Gracias especiales a[/b] Nino_16, royalduke, Suki, Liam, Near, Frony & Maliante! 

 [b]Gracias especiales por los iconos utilizados de: [/b] [url=http://www.famfamfam.com/lab/icons/silk/]FamFamFam[/url] | [url=http://dryicons.com/]DryIcons[/url] | [url=http://www.iconfinder.com/]Iconfinder[/url] 

 Y para todos aquellos que olvidamos saludar y que ayudaron al desarrollo del portal, [b]Muchas gracias[/b]