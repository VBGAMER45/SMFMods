<?php
/*---------------------------------------------------------------------------------
*	Ultimate Portal
*	Version 0.3
*	Project manager: vicram10
*	Copyright 2011
*	Powered by SMFSimple.com
**********************************************************************************/

global $settings, $txt, $scripturl, $boardurl, $mbname;

//Titles Modules
$txt['up_module_title'] = 'Module';
$txt['up_module_about_title'] = 'About Us';
$txt['about_date_registered'] = 'Registered Date';
$txt['about_email_address'] = 'Email';

//Errors
$txt['ultport_error_no_active'] = 'Error, the module is not enabled';
$txt['ultport_error_no_members'] = 'No users belong to this membergroup';

?>