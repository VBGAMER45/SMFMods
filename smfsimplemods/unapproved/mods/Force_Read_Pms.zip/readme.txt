[center][img width=443 height=115]http://bit.ly/kZVDB6[/img]

[glow=black,2,300][color=purple][size=16pt][b]Force Read Pms[/b][/size][/color][/glow]
[b]Developed by [url=http://www.smfsimple.com/index.php?action=profile;u=55]4Kstore[/url]
For [url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0 - 2.0.X[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com
Official Support in [url=http://www.SmfSimple.com]www.SmfSimple.com[/url][/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Force users to read PMs when they have more than X Unread Pms[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Obliga a los usuarios a leer los Mensajes Privdaos cuando tenga mas de X sin leer[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
Administration:
Enable - Disable the mod.
Minimum number of unread PMs to redirect
Excludes Groups


[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
Administracion:
Habilitar - Deshabilitar el mod.
Minima cantidad de MP no leidos para redireccionar
Grupos Excluidos

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Screnshoot | Capturas[/b][/u][/size][/color][/glow]
[IMG]http://i.imgur.com/PUJq55N.png[/IMG]
[hr]

[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]English & Spanish[/b][/color]
[hr]

[color=purple][size=14pt][b]Settings[/b][/size][/color]
Administration Center � Configuration � Modification Settings � Force Read Pms
[code]index.php?action=admin;area=modsettings;sa=forcereadpm[/code]

[color=red][size=14pt][b]Notes:[/b][/size][/color]
This Mod Uses Hooks.

[color=purple][size=14pt][b]License:[/b][/size][/color]
 * This SMF modification is subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this SMF modification except in compliance with
 * the License. You may obtain a copy of the License at
 * [url=http://www.mozilla.org/MPL/]http://www.mozilla.org/MPL/[/url]