<?php
$txt['frp_admin'] = 'Force Read Pms';
$txt['frp_admin_desc'] = 'From here you can configure Force Read Pm mod.';
$txt['frp_enabled'] = 'Enable Force Read Pms';
$txt['frp_min_mps'] = 'Minimum number of unread PMs to redirect';
$txt['frp_min_mps_desc'] = 'When user have more than this number, will be redirected to PM area';
$txt['frp_excludes_groups'] = 'Excludes Groups';
$txt['frp_excludes_groups_desc'] = 'Put the ID group separated with commas Ex: 1,4,5';