<?php
$txt['frp_admin'] = 'Force Read Pms';
$txt['frp_admin_desc'] = 'Desde aqui podra configurar el mod Force Read Pm.';
$txt['frp_enabled'] = 'Activar Force Read Pms';
$txt['frp_min_mps'] = 'Minima cantidad de MP no leidos para redireccionar';
$txt['frp_min_mps_desc'] = 'Cuando un usuario tenga mas de esta cantidad de Mps no leidos sera redireccionado al area de MPs';
$txt['frp_excludes_groups'] = 'Grupos Excluidos';
$txt['frp_excludes_groups_desc'] = 'Poner el ID de los grupos separados por coma, Ej: 1,4,5';