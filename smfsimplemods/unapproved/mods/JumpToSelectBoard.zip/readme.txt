[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Jump To Select Board 1.1[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.X[/b][/i][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Go to a specific board from anywhere in the forum[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b] Ir a un foro determinado desde cualquier lugar del foro[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Changelog:[/b][/u][/size][/color][/glow]
[code]
- V1.1:
- Clean code.
- Added hooks, no more file edits
- Added cache system, no more querys in every page.
- Html Validated.
- Work in all languages
[/code]

[hr]
[glow=black,2,300][color=orange][size=13pt][u][b]Historial de Cambios:[/b][/u][/size][/color][/glow]
[code]
- V1.1:
- Codigo mas limpio
- Se agregaron hooks, no se editan mas archivos del sistema, funciona en todos los themes
- Se agrego un sistema de cacheo, el mod no realiza consultas a la base de datos
- Validado el codigo HTML.
- Funciona en todos los lenguajes
[/code]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center][img width=600 height=271]http://i.imgur.com/29O09.jpg[/img][/center]

[center][img width=600 height=271]http://i.imgur.com/xpw2Q.jpg[/img][/center]

[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Jump To Select Board[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2014 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]