﻿[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Remember Position After Login/Logout | Recordar tu posición al entrar/salir[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=2]distante[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 1.1.x - 2 RCx - 2.0 [/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en www.SMFSimple.com / Official Support in www.SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]This simple Mod allows your forum users to stay in the same page where they login or logout. If they login in the login page like yourforum.com/index.php?action=login or yourforum.com/login/ (if you use Pretty Urls) then they will be redirected to your forum's main page.

[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Este simple mod le permite a los usuarios de tu foro mantenerse en la misma pagina donde se loguean o desloguean. Si ellos entran desde la pagina de logueo como yourforum.com/index.php?action=login o yourforum.com/login/ (si usas Pretty Urls) entonces serán redireccionados a la pagina principal de tu foro.

[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]Compatible with PrettyUrls /login/ url[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Compatible con Urls de Pretty Url[/li]
[/list]

[hr]


[center][glow=black,2,300][color=green][size=15pt][b]Remember Position After Login/Logout | Recordar tu posición al entrar/salir[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]