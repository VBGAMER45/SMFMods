[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Limit Posters[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0.X[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Allows administrator to select how many new topics and replies can create users per day.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Permite al administrador seleccionar cuantos nuevos temas y respuestas pueden crear los usuarios por dia.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]Configuration: Administration Center � Membergroups (From here you can set the limit oer each membergroup)[/li]
	[li]Configuration: Administration Center � Maintence � Scheduled Tasks (From here you can enable and set the setting)[/li]
	[li]In the profile, each user can see how many messages have left on that day[/li]
	[li]The administrator can change the limit to each user from the user's profile[/li]
	[li]The mod also works with the quick reply.[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Configuracion: Admin Panel -> Grupos de Usuarios (desde aqui se puede setear el limite de posteos para cada grupo)[/li]
	[li]Configuracion: Admin Panel -> Mantenimiento -> Tareas Programadas (Desde aqui se puede setear cada cuanto se va a actualizar el limite)[/li]
    [li]En el perfil, cada usuario puede ver cuantos mensajes le quedan para postear[/li]
	[li]El administrador puede cambiar el limite a cada usuario desde el perfil del usuario[/li]
	[li]El mod tambien limita la respuesta rapida a los usuarios.[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center]
[IMG width=700 height=242]http://i.imgur.com/5vlPc.png[/IMG]
[IMG width=700 height=242]http://i.imgur.com/DpwZ5.png[/IMG]
[IMG width=700 height=242]http://i.imgur.com/L0xrE.png[/IMG]
[IMG width=700 height=242]http://i.imgur.com/j93wE.png[/IMG]
[IMG width=700 height=242]http://i.imgur.com/GezN0.png[/IMG]
[IMG width=700 height=242]http://i.imgur.com/kEkPn.png[/IMG]

[/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]
- English
- Spanish_latin
- Spanish_es
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Limit Posters[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]