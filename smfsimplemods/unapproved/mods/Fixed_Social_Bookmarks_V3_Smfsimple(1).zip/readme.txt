[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Fixed Social Bookmarks 3.0[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url] , [url=http://www.smfsimple.com/index.php?action=profile;u=425]Daniiel[/url] & [url=http://www.smfsimple.com/index.php?action=profile;u=1]Lean[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.X[/b][/i][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Create a vertical bar to the left or right of the forum with social networking icons.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Crea una barra vertical a la izquierda o derecha del foro con iconos de redes sociales.[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
    [li]Turn the bar only in the index, only the subjects or in any forum.[/li]
	[li]Choice of position, right or left[/li]
	[li]Choice of active social network icons[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
    [li]Activar la barra solo en el indice, solo en los temas o en todo el foro.[/li]
	[li]Eleccion de posicion, izquierda o derecha[/li]
	[li]Eleccion de iconos de redes sociales activos[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center][img width=600 height=343]http://i.imgur.com/JrzkT.png[/img][/center]

[center][img width=600 height=391]http://i.imgur.com/bUiY5.png[/img][/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
- Spanish_latin-utf8
- Spanish_es
- Spanish_es-utf8
- Italian
- Italian-utf8[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Fixed Social Bookmarks[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2014 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]