[hr]
[center][img]http://www.smfsimple.com/img/logomod/rulesonpost.png[/img][/center][center]-------------------------------------
[color=navy][size=10pt][b]Desarrollado por [url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url] & [url=http://www.smfsimple.com/index.php?action=profile;u=1]Lean[/url][/b][/size][/color]
[b]Version V1 Full Version[/b][/center]

English:
[b]This mod allows the administrator to display the forum rules in the area of the user posting the preferred range.[/b]

Spanish:
[b]Este mod le permite al administrador mostrar las reglas del foro en el area de posteo a los usuarios del rango que prefiera.[/b]
[hr]

Features:
Enable or disable the mod from the administration.
Choose the forums where the rules don't see.
Choose by group permissions the user group does not see the rules.
The block to write the message allows html and bbcode.
You can customize the rules block with the CSS style  from administration.

Caracteristicas:
Activar o desactivar el mod desde la administracion.
Elegir los foros donde las reglas no se veran.
Elegir por medio de los permisos de grupos de usuario que grupo no vera las reglas.
El bloque para escribir el mensaje permite html y bbcode.
Puedes personalizar el bloque de las reglas con Estilos CSS desde administracion.

[color=#660033][b][size=12pt]Lenguajes soportados[/size][/b][/color]
o English
o Spanish_latin
o Spanish_latin-utf8
o Spanish_es
o Spanish_es-utf8

[color=#660033][b][size=12pt]Disponible para la version Smf 2.0 RC5 - 2.0[/size][/b][/color]

[center][color=black][size=18pt][b]Rules On Post V1 Full Version[/b][/size][/color]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center][center]Rules On Post  by [url=http://www.smfsimple.com/index.php?action=downloads;sa=view;down=38]Lean[/url] is licensed under a 
[url=http://creativecommons.org/licenses/by-nc-sa/3.0/]Creative Commons Reconocimiento-NoComercial-CompartirIgual 3.0 Unported License[/url].
Creado a partir de la obra en [url=http://www.smfsimple.com]www.smfsimple.com[/url].
Permissions beyond the scope of this license 
may be available at [url]http://www.smfsimple.com/index.php/page,licencias.html[/url].[/center]

[/center][center][color=green][size=13pt][b]Copyright 2011 by [url=http://www.smfsimple.com]Smfsimple.com[/url][/b][/size][/color][/center]