[url=http://www.smfsimple.com/index.php?action=downloads;sa=view;download=63]Link al Archivo[/url]

[center][img]http://i.imgur.com/J7AHpcX.png[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]SMFSimple Double Email Checker[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.saninnsalas.com]Distante[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com

[/url][/b]
[i][b]SMF 2.x[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=orange][size=14pt][b]Official Support only in SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]This mod forces the user to write 2 times the email in the register page by removing the option of copy/paste the email and 

preventing to show the previous user emails (history)[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Este mod obliga a ingresar el email 2 veces para poder registrarse removiendo la habilidad de copiar y pegar el correo, as� 

como el listado de correos anteriores del usuario (historial).[/b][/i]

[hr]

[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin / Spanish_latin-utf8
- Spanish_es / Spanish_es-utf8
- Portuguese_pt / Portuguese_pt-utf8 (thanks to FragaCampos)
- Turkish/ Turkish-utf8 (Thanks to Shard)
[/b][/color]
[hr]

[b][size=18pt]Changelog[/size][/b]
[b]Ver 1.3[/b]
+ Added Turkish language (Thanks to Shard)
+ Added Italian language (Thanks to bruce86)

+ A�adida traducci�n al Turco (Gracias a  Shard)
+A�adida traducci�n al Italiano( Gracias a bruce86)

[b]Ver 1.2[/b]
+ Now ignore emails from user history.
+ Prevent copy/paste email from one field to another.
+ Added Portuguese language (thanks to FragaCampos)

+ Ahora se ignora el historial de correos pasados.
+ El usuario no puede usar Copiar/pegar en el campo extra del correo.
+ A�adido traducci�n al portugues (gracias a FragaCampos)

[b]Ver 1.1[/b]
+Prevent Copy/Paste in the repeat email input field

+Prevenci�n del uso de copiar/pegar en el cuadro de repetici�n del email

[b]Ver 1.0[/b]
Versi�n Inicial

Initial Release 

[hr]
[center][glow=black,2,300][color=green][size=15pt][b]SMFSimple Double Email Checker[/b][/size][/color][/glow][/center]
[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011-2014 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img]
[/url][/center]