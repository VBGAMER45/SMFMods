[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Board Color V1[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0 and 2.0.1[/b][/i][/center]


[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]With this mod you can choose custom colors for the titles of the boards using a smart picker in js.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Con este mod podras elegir colores personalizados para los titulos de los foros utilizando un elegante picker en js.[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]Select Boards[/li]
	[li]Select colors using a color picker[/li]
        [li]Putting colors by name: eg: Red, Green, Etc.[/li]
	[li]If you select a color nothing happens[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Seleccionar Foros[/li]
	[li]Seleccionar Colores mediantes un color picker (Idea: Gay de lea?)[/li]
        [li]Poner colores por su nombre: eg: Red, Green, Etc[/li]
	[li]Si no se selecciona un color no pasa nada[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center][img width=800 height=194]http://i.imgur.com/DFAyB.png[/img][/center]

[center][img width=800 height=448]http://i.imgur.com/BGN7I.png[/img][/center]
[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
- Spanish_latin-utf8
- Spanish_es
- Spanish_es-utf8
[url=http://www.smfsimple.com/index.php/topic,4697.0.html]MORE TRANSLATIONS[/url][/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Board Color V1[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]