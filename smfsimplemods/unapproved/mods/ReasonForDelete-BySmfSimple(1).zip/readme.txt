[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Reason For Delete[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0.X[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]With this mod you can send a private message to the user that you delete an issue with templates that you create yourself.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Con este mod podras enviar un mensaje privado al usuario al cual le eliminas un tema con plantillas que tu mismo puedes crear.[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]Exclusive administration panel mod[/li]
	[li]You can activate or deactivate the mod from the ADMINISTRATION[/li]
        [li]You can only send additional information without a template[/li]
	[li]You can create as many templates as you want, you can use these variables to help you to customize the message to your liking.[/li]
        [li]You can create, edit and delete templates anytime.[/li]
        [li]You can use your templates with the additional information.[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
        [li]Panel de administracion exclusivo del mod[/li]
	[li]Puedes Activar o Desactivar el mod desde la admnistracion[/li]
	[li]Puedes enviar solo informacion adicional sin contar con una plantilla.[/li]
        [li]Puedes crear todas las plantillas que quieras, en estas podras utilizar variables que te ayudaran a personalizar el mensaje a tu gusto.[/li]
	[li]Puedes crear, editar y eliminar las plantillas cuando quieras.[/li]
        [li]Puedes utilizar tus plantillas junto con la informacion adicional.[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center][img]http://i.imgur.com/zX2Mz.png[/img][/center]

[center][img]http://i.imgur.com/eVOSB.png[/img][/center]

[center][img]http://i.imgur.com/WZiFP.png[/img][/center]

[center][img]http://i.imgur.com/LiI3i.png[/img][/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
- Spanish_latin-utf8
- Spanish_es
- Spanish_es-utf8[/b][/color]
[hr]

 * This SMF modification is subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this SMF modification except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/

[center][glow=black,2,300][color=green][size=15pt][b]Reason For Delete[/b][/size][/color][/glow][/center]