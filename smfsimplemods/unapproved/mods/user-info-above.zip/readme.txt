[b]User Info Above Posts[/b]

Version: 1.0 
Compatibility: 2.0RC1

[b][u]Features[/u][/b]
Moves the user information from the left side of posts to above posts.

[b][u]Configuration[/u][/b]
ADMIN --> CURRENT THEME --> Display user information above posts

[b][u]Support[/u][/b]
For support with this mod, feel free to visit the SMF mod site or http://ipostyoupost.com

[b][u]Credit[/u][/b]
Thanks go to Dragooon & Nas @ SMF Forums for coding assistance

[color=maroon][size=3][b][u]NOTE: Other Display Template Mods[/u][/b][/size][/color]
If you have any other mods which effect the Display template (points, (advanced) karma, OS Detectors...), you may need to add that mod's line(s) of code where ever you want them to display. When looking for where to place your code, look for one of these two areas:

[code]
// Begin (LEFT SIDE INFO) User Name & Titles Cell
[/code]

[code]
// Begin (RIGHT SIDE INFO) Custom Fields, Karma, Post Count, Message & Member Icons
[/code]