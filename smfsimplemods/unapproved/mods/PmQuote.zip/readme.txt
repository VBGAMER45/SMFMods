[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]PM QUOTE[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
Thanks for the idea to [b][url=http://www.simplemachines.org/community/index.php?action=profile;u=267533]HunterP[/url][/b]
[i][b]SMF 2.0.X[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]With this mod you can send a PM to any users quoting a particular post[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Con este mod podras enviar un MP a cualquier usuarios citando un post en particular[/b][/i]

[IMG]http://i.imgur.com/TZqBz.png[/IMG]

[IMG]http://i.imgur.com/Bm0QQ.png[/IMG]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]
- English
- Spanish_latin
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]PM QUOTE[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]