<?php
$txt['pvm_guest'] = 'Visitantes';
$txt['pvm_visits'] = 'Visitas';
$txt['pvm_title_log'] = 'Perfiles Log';
$txt['pvm_admin_desc'] = 'Profile Views Mods V2';
$txt['pvm_enabled'] = 'Activar Profile Views Mod';
$txt['pvm_height'] = 'Altura del cuadro de visitantes (Numero en PX)';
$txt['pvm_show_avatar'] = 'Mostrar el avatar de los visitantes';
$txt['pvm_show_visits'] = 'Mostrar cuantas visitas realizo cada usuario';
$txt['pvm_show_latest_visits'] = 'Mostrar la fecha de la ultima visita de cada usuario';