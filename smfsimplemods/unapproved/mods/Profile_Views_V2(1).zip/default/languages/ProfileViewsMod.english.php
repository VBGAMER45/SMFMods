<?php
$txt['pvm_guest'] = 'Guests';
$txt['pvm_visits'] = 'Visits';
$txt['pvm_title_log'] = 'Profile Visitors';
$txt['pvm_admin_desc'] = 'Profile Views Mods V2';
$txt['pvm_enabled'] = 'Enable Profile Views Mod';
$txt['pvm_height'] = 'Height of profile views box (number in PX)';
$txt['pvm_show_avatar'] = 'Show viewers avatars';
$txt['pvm_show_visits'] = 'Show total visits for each viewer';
$txt['pvm_show_latest_visits'] = 'Show date for the last view for each viewer';