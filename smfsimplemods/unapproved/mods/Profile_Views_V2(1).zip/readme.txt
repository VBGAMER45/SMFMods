[center][img width=443 height=115]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Profile Views V2[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0.X[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Crea una lista en cada perfil de todos los usuarios mostrando quienes visitaron su perfil.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Create a list in each profile showing all users who visited your profile.[/b][/i]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Im�genes[/b][/size][/color][/glow][/center]

[center]
[IMG]http://i.imgur.com/Aob0yqB.png[/IMG]
[IMG]http://i.imgur.com/a4SvvxZ.png[/IMG]
[/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u]
[b]English - Espa�ol[/b][/color]