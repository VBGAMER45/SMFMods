[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Recent Activity[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=4288]DIBILO[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0, SMF 2.0.4[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Sample recent user activities on the forum.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripci�n:[/b][/u][/size][/color][/glow]
[i][b]�Muestra las recientes actividades del usuario en el foro.![/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
[li][b]You can enable or disable from the administration.[/b][/li]
[li][b]You can see it from the user's profile.[/b][/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracter�sticas:[/b][/u][/size][/color][/glow]
[list]
[li][b]Muestra las recientes actividades del usuario en el foro.[/b][/li]
[li][b]Puedes verlo desde el perfil del usuario.[/b][/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]


[center][img]http://i.imgur.com/XxmB8gG.png[/img][/center][br]
[hr]
[center][img]http://i.imgur.com/l9WVEHB.png[/img][/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English[/b][/color]
[color=teal][b]- Spanish_es[/b][/color]
[color=teal][b]- Spanish_es-utf8[/b][/color]
[color=teal][b]- Spanish_latin[/b][/color]
[color=teal][b]- Spanish_latin-utf8[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Recent Activity[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2013 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]