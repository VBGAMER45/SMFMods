[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Slashout Banned Members[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[b]Creator:[/b] [b][url=http://www.simplemachines.org/community/index.php?action=profile;u=164151]Project Evolution[/url][/b]
[i][b]SMF 1.1.15 & 2.0.1[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]The Slashout Banned Members modification is a simple mod which allows administrators to set a slash on the names of banned members[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]El Slashout Banned Members Mod es una simple modificacion que permite a los administradores cambiar el aspecto de los usuarios que fueron baneados [/b][/i]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center][img]http://i.imgur.com/O9MDV.png[/img]

[img]http://i.imgur.com/vhbSX.png[/img]

[img]http://i.imgur.com/1fIn3.png[/img]

[img]http://i.imgur.com/v6IzW.png[/img][/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]ALL LANGUAGES! | TODOS LOS LENGUAJES![/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Slashout Banned Members[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]