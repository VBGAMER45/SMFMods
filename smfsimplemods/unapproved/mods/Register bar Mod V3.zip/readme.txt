[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Register Bar Mod V3[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=1]Lean[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0[/b][/i][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]This mod allows the administration activated from a bar that invites guests to your forum to register.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Este mod permite activar desde la administracion una barra que invita a los visitantes de tu foro a registrarse.[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]Enable or disable the mod from the administration.[/li]
	[li]You can choose the background color of the bar or leave the default one.[/li]
    [li]You can choose the color of the words of the message or leave the default one.[/li]
	[li]You can write a custom message using both bbcode and html if you do not write anything the mod will do it[/li]
	[li]You have the option to disable the button that allows visitors to close the bar.[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Activar o desactivar el mod desde la administracion.[/li]
	[li]Podras elegir el color de fondo de la barra o dejar el que viene por defecto.[/li]
    [li]Podras elegir el color de las palabras del mensaje o dejar el que viene por defecto.[/li]
	[li]Podras escribir el mensaje personalizado utilizando tanto bbcode como html, si no escribes nada el mod lo hara por ti![/li]
	[li]Tienes la opcion de deshabilitar el boton que permite a los visitantes cerrar la barra.[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center][img]http://i.imgur.com/xcGZa.png[/img][/center]

[center][img]http://i.imgur.com/lyaYB.png[/img][/center]

[center][img]http://i.imgur.com/3K3Wr.png[/img][/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
- Spanish_latin-utf8
- Spanish_es
- Spanish_es-utf8[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Register Bar Mod V3[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]