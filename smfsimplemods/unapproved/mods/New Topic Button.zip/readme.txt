[center][img]http://www.smfsimple.com/img/logomod/newtopicbutton.png[/img][/center]
[center]-------------------------------------
[color=red][size=10pt][b]Developed By [url=http://www.smfsimple.com/index.php?action=profile;u=1]Lean[/url][/b][/size][/color]
[color=red][size=10pt][b]Smf 2.0 RC2 - RC3 - RC4 - RC5 - 2.0[/b][/size][/color]
[/center]
[center][u][color=red][size=14pt][b]English[/b][/size][/color][/u][/center]
[color=red][size=11pt][b]Description:[/b][/size][/color]
This mod adds an extra button in the index of forums with a single click takes users to create topics in this forum.
[hr]
[center][u][color=red][size=14pt][b]Espa�ol[/b][/size][/color][/u][/center]
[color=red][size=11pt][b]Descripcion:[/b][/size][/color]
Este mod agrega un boton extra en el indice de los foros para que con un solo click lleve a los usuarios a crear un tema en ese foro.

[center][color=red][size=18pt][b]New Topic Button[/b][/size][/color]
[/center]
[center][color=green][size=13pt][b]Copyright 2011 by [url=http://smfsimple.com]Smfsimple.com[/url][/b][/size][/color][/center]