[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Table Plus BBCodes v1.2[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[b]Created by[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=192278][b].LORD.[/b][/url]
[i][b]SMF 1.1.X, 2.0 RCX, 2.0.X[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]This MOD Improves and Adds the 'Table BBCodes Buttons' and adds a best style for tables in posts.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Este mod agrega botones para hacer el armado de tablas un poco mas facil ademas de agregarle un estilo un poco mas agradable al resultado[/b][/i]

[hr]

[center][table]
[tr]
[td][/td][td][center][b]SMF 1.1.X[/b][/center][/td][td][center][b]SMF 2[/b][/center][/td][td][center][b]Now[/b][/center][/td]
[/tr]
[tr]
[td][center][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/table.gif[/img][/center][/td][td][nobbc][table][/table][/nobbc][/td][td][nobbc][table]
[tr]
[td][/td]
[/tr]
[/table][/nobbc][/td][td][nobbc][table]
[tr]
[td][/td][td][/td]
[/tr]
[/table][/nobbc][/td]
[/tr]
[tr]
[td][center][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/tr.gif[/img][/center][/td][td][nobbc][tr][/tr][/nobbc][/td][td][center]-[/center][/td][td][t[i][/i]r]
[t[i][/i]d][/t[i][/i]d][t[i][/i]d][/t[i][/i]d]
[/t[i][/i]r][/td]
[/tr]
[tr]
[td][center][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/td.gif[/img][/center][/td][td][nobbc][td][/td][/nobbc][/td][td][center]-[/center][/td][td][nobbc][td][/td][/nobbc][/td]
[/tr]
[/table][/center]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center]
[IMG]http://i.imgur.com/mYj9U.png[/IMG]

[IMG]http://i.imgur.com/mhHPp.gif[/IMG]
[/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]
ALL - TODOS
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Table Plus BBCodes[/b][/size][/color][/glow][/center]