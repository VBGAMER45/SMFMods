[center][img width=443 height=115]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]SMFSimple Rewards System[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] & [b]Designed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=1]Lean[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0.XX[/b][/i][/center]

[center][b][size=14pt][url="http://www.smfsimple.com"]Visita SMFSIMPLE.com[/url][/size][/b][/center]

