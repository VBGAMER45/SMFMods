[center][img width=443 height=115]http://bit.ly/kZVDB6[/img]

[glow=black,2,300][color=purple][size=16pt][b]Tiny Comment System[/b][/size][/color][/glow]
[b]Developed by [url=http://www.smfsimple.com/index.php?action=profile;u=2501]Manix[/url] and [url=http://www.smfsimple.com/index.php?action=profile;u=55]4Kstore[/url]
For [url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0 - 2.0.X[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com
Official Support in [url=http://www.SmfSimple.com]www.SmfSimple.com[/url][/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Add the ability to comments replies from a topic, easily and quickly[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Agrega un sistema de comentarios a las respuesta de los temas, con esto podras comentar cada respuesta que se realiza en un tema de forma rapida y facil.[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
1. Hooks used.
2. Show avatar and color group from a member.
3. Display more comments clicking in the show more button.
4. Use Ajax to add and delete comments without refreshing page.
5. Use JQuery to add nice effects.
6. Can post using BBC and Smileys

Administration:
Enable - Disable the mod.
Permissions for users, who can use the mod.
Permissions per board, where can use the mod.
Number of comments to display initially in each post 
Number of comments to bring when you click on "see more" button
Limit of characters per comment
Enable - Disable BBC on comments 
Enable - Disable smileys on comments

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
1. Uso de hooks, menos ediciones a archivos.
2. Muestra el avatar y color de grupo del usuario que comenta.
3. Mostrar mas comentarios clickeando en el boton "Mostrar mas".
4. Usa ajax para no refrezcar la pagina al agregar o eliminar comentarios.
5. Usa Jquery para agregar animaciones con efectos mas suaves.
6. Puede postear comentarios usando BBC y emoticones

Administracion:
Habilitar - Deshabilitar el mod.
Permisos para usuarios, quien puede usar el mod.
Permisos por foro, donde se pueden comentar las respuestas
Numero de comentarios a mostrar inicialmente
Numero de comentarios a mostrar al clickear en el boton "Mostrar Mas"
Limite de caracteres por comentario
Habilitar - Deshabilitar el uso de BBC en los comentarios.
Habilitar - Deshabilitar el uso de emoticones en los comentarios.
[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Screnshoot | Capturas[/b][/u][/size][/color][/glow]
[IMG]http://i.imgur.com/2jppXbm.png[/IMG]
[IMG]http://i.imgur.com/C1khDAX.png[/IMG]
[IMG]http://i.imgur.com/MbwhAYR.png[/IMG]
[hr]

[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]English & Spanish[/b][/color]
[hr]

[color=purple][size=14pt][b]Settings[/b][/size][/color]
Administration Center � Configuration � Tiny Comments System
[code]index.php?action=admin;area=comments;[/code]

[color=red][size=14pt][b]Notes:[/b][/size][/color]
This Mod Uses Jquery.
This Mod Uses Hooks.

[color=purple][size=14pt][b]License:[/b][/size][/color]
 * This SMF modification is subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this SMF modification except in compliance with
 * the License. You may obtain a copy of the License at
 * [url=http://www.mozilla.org/MPL/]http://www.mozilla.org/MPL/[/url]