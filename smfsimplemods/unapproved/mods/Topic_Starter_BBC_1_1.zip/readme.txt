[center][img width=443 height=115]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Topic Starter BBC[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]
Changelog: 
Version 1.1
+ Added Hooks (no file edits) - Hooks agregados (no se editan archivos)
+ No more extra querys - No hace consultas de mas a la base de datos

[hr]
[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]With this modification can show the creator of the thread using [starter] BBC tag[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Con esta modificacion podras mostrar el creador del tema usando [starter] tag[/b][/i]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center]
[IMG]http://i.imgur.com/9ORa1.png[/IMG]
[IMG]http://i.imgur.com/E1FvE.png[/IMG][/center]


[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]All[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Topic Starter BBC[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img width=88 height=31]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]