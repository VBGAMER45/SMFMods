[center][img width=443 height=115]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Global Message Box[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=1]Lean[/url][/b] & [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0[/b][/i][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]This mod allows users to show a global message in a box with a unique design! Css3 and jquery using as a basis.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Este mod permite mostrarle a sus usuarios un mensaje global dentro de un box con un dise�o unico! Utilizando jquery y css3 como base.[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li] Activate / deactivate the mod from the administration [/li]
        [li] From the administration you can edit the message box with a textarea. [/li]
        [li] You can use both HTML in the message board. [/li]
        [li] You can choose which group of users will not see the box. [/li]
        [li] You can choose which forum or subforum not see the box. [/li]
        [li] You can choose from several styles to match the block to your forum. [/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Activar/desactivar el mod desde la administracion[/li]
	[li]Desde la administracion podras editar el mensaje del box mediante un textarea.[/li]
        [li]Puedes utilizar tanto HTML como BBcode en el mensaje.[/li]
        [li]Puedes elegir que grupo de usuarios NO vera el box.[/li]
        [li]Puedes elegir en que foro o subforo no se vea el box.[/li]
        [li]Puedes elegir entre varios estilos para adecuar el bloque a tu foro.[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center][img width=800 height=432]http://i.imgur.com/Tf1a2.png[/img][/center]

[center][img width=800 height=414]http://i.imgur.com/SyPZb.png[/img][/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
- Spanish_latin-utf8
- Spanish_es
- Spanish_es-utf8[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Global Message Box V1 Full Version[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img width=88 height=31]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]