<?php
/*---------------------------------------------------------------------------------
*	SMFSIMPLE BBCUserInfo													 	  *
*	Author: SSimple Team - 4KSTORE										          *
*	Powered by www.smfsimple.com												  *
**********************************************************************************/

$txt['uic_admin_title'] = 'BBC User Info Mod';
$txt['uic_admin_title_desc'] = 'BBC User Info mod Settings';
$txt['uic_enable'] = 'Enable Mod';
$txt['uic_guest_can'] = 'Guest can see the user info card?';
$txt['uic_style'] = 'Select card style';
$txt['uic_act_group_image'] = 'Show image group?';
$txt['uic_act_personal_text'] = 'Show personal text?';
$txt['uic_act_contact_icons'] = 'Show contact icons?';
$txt['uic_no_user'] = 'User not found..';
$txt['agebb'] = 'Age';
$txt['uic_no_user'] = 'User not found..';
$txt['des_userInfo'] = 'Add UserInfo';
$txt['uic_loading'] = 'Loading...';
$txt['uic_style_n1'] = 'Blue (Default)';
$txt['uic_style_n2'] = 'Light';
$txt['uic_style_n3'] = 'Dark';
$txt['uic_style_n4'] = 'Red';
$txt['uic_style_n5'] = 'Green';
$txt['uic_style_n6'] = 'Plain';
$txt['uic_pm_title'] = 'Has been mentioned';
$txt['uic_pm_body'] = 'You just be mentioned in the following topic:';