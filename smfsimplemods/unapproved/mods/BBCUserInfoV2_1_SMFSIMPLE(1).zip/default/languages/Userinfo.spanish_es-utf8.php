<?php
/*---------------------------------------------------------------------------------
*	SMFSIMPLE BBCUserInfo													 	  *
*	Author: SSimple Team - 4KSTORE										          *
*	Powered by www.smfsimple.com												  *
**********************************************************************************/

$txt['uic_admin_title'] = 'BBC User Info Mod';
$txt['uic_admin_title_desc'] = 'Configuracion BBC User Info mod';
$txt['uic_enable'] = 'Habilitar Mod';
$txt['uic_guest_can'] = 'Invitados pueden ver el UserInfo Card?';
$txt['uic_style'] = 'Seleccionar el estilo';
$txt['uic_act_group_image'] = 'Mostrar la imagen del grupo del usuario';
$txt['uic_act_personal_text'] = 'Mostrar el texto personal del usuario?';
$txt['uic_act_contact_icons'] = 'Mostrar iconos de contacto?';
$txt['uic_no_user'] = 'No se encontro el usuario';
$txt['agebb'] = 'Edad';
$txt['des_userInfo'] = 'Agregar UserInfo';
$txt['uic_loading'] = 'Cargando...';
$txt['uic_style_n1'] = 'Azul';
$txt['uic_style_n2'] = 'Claro';
$txt['uic_style_n3'] = 'Oscuro';
$txt['uic_style_n4'] = 'Rojo';
$txt['uic_style_n5'] = 'Verde';
$txt['uic_style_n6'] = 'Simple';
$txt['uic_pm_title'] = 'Ha sido mencionado';
$txt['uic_pm_body'] = 'Acabo de mencionarte en el siguiente tema:';