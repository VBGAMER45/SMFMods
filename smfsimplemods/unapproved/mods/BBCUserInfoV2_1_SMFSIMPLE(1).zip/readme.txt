[center][img width=443 height=115]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]BBC USER INFO V2[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0.X[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]With this mod you would be able to show the most important information from the users named on your posts. To do it, it uses its own bbcode and an elegant box developed in Jquery[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Nueva version del mod para mencionar personas, mas eficiente, mas estilos para seleccionar y nuevos items en el box![/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]See important information for each user[/li]
	[li]Mention one user using BBC[/li]
	[li]Jquery to give a special design[/li]
	[li][url=http://craigsworks.com/projects/qtip2/]Qtip2[/url] and ajax to return information.[/li]
	[li]Possibility to visit web and profile - send mails and private messages[/li]
	[li]Possibility to visit social networks with [url=http://custom.simplemachines.org/mods/index.php?mod=3304]Add Social Media Icons To Profiles MOD[/url]
	[li]Enable and disable the mod and some functions[/li]
	[li]Hooks and CSS3[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Ver la informacion importante de cada usuario al nombrarlo[/li]
	[li]El uso de tags para nombrar usuarios[/li]
	[li]Jquery para darle un dise�o especial[/li]
	[li][url=http://craigsworks.com/projects/qtip2/]Qtip2[/url] y ajax para mostrar solo la informacion deseada[/li]
	[li]Posibilidad de visitar perfil y web -  mandar mails y mensajes privados[/li]	
	[li]Posibilidad de visitar redes sociales instalando el mod: [url=http://custom.simplemachines.org/mods/index.php?mod=3304]Add Social Media Icons To Profiles[/url]
	[li]Habilitar y deshabilitar completamente el mod y alguna de sus funciones[/li]
	[li]Hooks y CSS3, ya no se necesitan hacer modificaciones.. :)[/li]
[/list]



[color=purple][size=14pt][b]License:[/b][/size][/color]
 * This SMF modification is subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this SMF modification except in compliance with
 * the License. You may obtain a copy of the License at
 * [url=http://www.mozilla.org/MPL/]http://www.mozilla.org/MPL/[/url]