<?php
// Version: 2.0; Settings

global $settings, $scripturl, $context;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Losox Theme By SMFSimple.com<br /><br />Autor: Lean';

$txt['link_facebook'] = 'URL Facebook';
$txt['link_twitter'] = 'URL Twitter';
$txt['link_google'] = 'URL Google+';
$txt['link_youtube'] = 'URL Canal Youtube';

$txt['login_los'] = 'Please, sign in if you are registered  :)';
$txt['clav_olvi'] = 'Password forget?';
$txt['registr_los'] = 'Register';
$txt['user_los'] = 'User';
$txt['clave_los'] = 'Password';
$txt['welcome_los'] = 'Welcome, ';
$txt['sig_en'] = 'follow us on... ';
$txt['copy_losox'] = 'Losox Theme By SMFSimple.com';
$txt['title_copy'] = 'SMFSimple.com';

$txt['link_facebook_disable'] = 'Disable Facebook Icon';
$txt['link_twitter_disable'] = 'Disable Twitter Icon';
$txt['link_google_disable'] = 'Disable Google+ Icon';
$txt['link_youtube_disable'] = 'Disable Youtube Channel Icon';
$txt['link_rss_disable'] = 'Disable Rss Icon';

?>