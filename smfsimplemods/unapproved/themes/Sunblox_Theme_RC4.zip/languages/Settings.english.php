<?php
/*--------------------------------------
*	Smfsimple.com
*   Theme: SunBlox Theme
*   Version Smf: RC4
*	Author: Lean
*	Copyright 2011
*	Desarrollado para www.smfsimple.com
***************************************/

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Sunblox<br /><br />Theme by <a href="http://www.smfsimple.com">Smfsimple.com</a>.';

?>