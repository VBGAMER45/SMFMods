<?php
/*--------------------------------------
*	Smfsimple.com
*   Theme: SunBlox Theme
*   Version Smf: RC4
*	Author: Lean
*	Copyright 2011
*	Desarrollado para www.smfsimple.com
***************************************/

global $scripturl;

$txt['sunpubli'] = 'Insert your Advertising';
$txt['sunpubli_des'] = 'Allow BBcode & HTML';
$txt['sunpubli_ad'] = 'Advertising';
$txt['sunbloxcopy'] = 'Write your copyright';
$txt['sunbloxcopy_des'] = 'Allow bbcode & html.';
$txt['show_stats_center'] = 'Enable/Disable stats center';
$txt['active_publi'] = 'Enable/Disable Advertising';
$txt['pm_unread'] = 'Unread';
$txt['messages_total'] = 'Total Messages: ';
$txt['messages_new'] = 'New';
$txt['maintenance'] = '(Maintenance)';
$txt['approval_member'] = 'Approval';
$txt['open_reports'] = 'Reports';
$txt['view_unread'] = 'Show Unread';
$txt['view_replies'] = 'Show Replies';

?>