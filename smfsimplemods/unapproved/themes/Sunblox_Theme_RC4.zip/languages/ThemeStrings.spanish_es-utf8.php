<?php
/*--------------------------------------
*	Smfsimple.com
*   Theme: SunBlox Theme
*   Version Smf: RC4
*	Author: Lean
*	Copyright 2011
*	Desarrollado para www.smfsimple.com
***************************************/

global $scripturl;

$txt['sunpubli'] = 'Inserta aqui tu publicidad';
$txt['sunpubli_des'] = 'Puede utilizar BBcode & HTML';
$txt['sunpubli_ad'] = 'Publicidad';
$txt['sunbloxcopy'] = 'Coloca aqui tu copyright';
$txt['sunbloxcopy_des'] = 'Podras utilizar bbcode y html.';
$txt['show_stats_center'] = 'Mostrar/Ocultar Centro de estadisticas';
$txt['active_publi'] = 'Activar/Desactivar publicidad';

$txt['pm_unread'] = 'No leido';
$txt['messages_total'] = 'MPs:';
$txt['messages_new'] = 'Nuevos';
$txt['maintenance'] = '(Mantenimiento)';
$txt['approval_member'] = 'Aprobaci�n';
$txt['open_reports'] = 'Reportes';
$txt['view_unread'] = 'Nuevos temas';
$txt['view_replies'] = 'Nuevas respuestas';

?>