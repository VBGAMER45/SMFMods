<?php
// Version: 2.0; ThemeStrings

$txt['newstats_enable'] = 'Enable statistics in jquery';
$txt['unread'] = 'Show unread posts';
$txt['unread_replies'] = 'Show new replies';

?>