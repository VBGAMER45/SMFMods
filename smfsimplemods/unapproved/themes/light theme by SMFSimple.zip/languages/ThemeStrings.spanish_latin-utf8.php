﻿<?php
// Version: 2.0; ThemeStrings

$txt['newstats_enable'] = 'Activar estadisticas en jquery';
$txt['unread'] = 'Mostrar mensajes no le&iacute;dos';
$txt['unread_replies'] = 'Mostrar nuevas respuestas';

?>