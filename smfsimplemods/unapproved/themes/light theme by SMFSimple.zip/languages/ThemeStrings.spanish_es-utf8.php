﻿<?php
// Version: 2.0; ThemeStrings

$txt['newstats_enable'] = 'Activar estadisticas en jquery';
$txt['unread'] = 'Mostrar mensajes no leidos';
$txt['unread_replies'] = 'Mostrar nuevas respuestas';

?>