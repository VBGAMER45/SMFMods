<?php
// Version: 2.0; ThemeStrings

$txt['newstats_enable'] = 'Attiva le statistiche in jquery';
$txt['unread'] = 'Visualizza i messaggi non letti';
$txt['unread_replies'] = 'Mostra nuove risposte';

?>