<?php
// Version: 2.0; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Firox Multicolor by SMFSimple.com<br /><br />Author: Lean';

?>