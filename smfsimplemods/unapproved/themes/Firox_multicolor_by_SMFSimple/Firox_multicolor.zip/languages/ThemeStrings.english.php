<?php
// Version: 2.0; Themes

global $scripturl;

$txt['firox_change_color'] = 'Choose style: ';

?>