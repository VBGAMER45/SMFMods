<?php
// Version: 2.0; Settings


$txt['login_los'] = 'Please, sign in if you are registered  :)';
$txt['clav_olvi'] = 'Password forget?';
$txt['registr_los'] = 'Register';
$txt['user_los'] = 'User';
$txt['clave_los'] = 'Password';
$txt['welcome_los'] = 'Welcome, ';
$txt['sig_en'] = 'follow us on... ';
$txt['copy_losox'] = 'Losox Theme By SMFSimple.com';
$txt['title_copy'] = 'SMFSimple.com';



?>