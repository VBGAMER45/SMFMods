<?php
// Version: 2.0; Settings



$txt['login_los'] = 'Logueate si ya estas registrado :)';
$txt['clav_olvi'] = 'Clave olvidada?';
$txt['registr_los'] = 'Registrate';
$txt['user_los'] = 'Usuario';
$txt['clave_los'] = 'Clave';
$txt['welcome_los'] = 'Bienvenido, ';
$txt['sig_en'] = 'Siguenos en... ';
$txt['copy_losox'] = 'Losox Theme By SMFSimple.com';
$txt['title_copy'] = 'SMFSimple.com, Todo para tu foro SMF';


?>