<?php
// Version: 2.0; Settings

global $settings, $scripturl, $context;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Losox Theme By SMFSimple.com<br /><br />Author: Lean';

$txt['link_facebook'] = 'URL Facebook';
$txt['link_twitter'] = 'URL Twitter';

$txt['link_youtube'] = 'URL Channel Youtube';


$txt['link_facebook_disable'] = 'Disable Facebook Icon';
$txt['link_twitter_disable'] = 'Disable Twitter Icon';
$txt['link_youtube_disable'] = 'Disable Youtube Channel Icon';
$txt['link_rss_disable'] = 'Disable Rss Icon';

?>