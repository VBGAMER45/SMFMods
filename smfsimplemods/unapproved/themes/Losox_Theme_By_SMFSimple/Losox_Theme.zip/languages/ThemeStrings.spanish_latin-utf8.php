<?php
// Version: 2.0; Settings

global $settings;

$txt['login_los'] = 'Logueate si ya estas registrado :)';
$txt['clav_olvi'] = 'Clave olvidada?';
$txt['registr_los'] = 'Registrate';
$txt['user_los'] = 'Usuario';
$txt['clave_los'] = 'Clave';
$txt['sig_en'] = 'Siguenos en... ';
$txt['welcome_los'] = 'Bienvenido, ';



?>