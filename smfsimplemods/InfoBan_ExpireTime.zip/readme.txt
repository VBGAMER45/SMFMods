[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]InfoBan - Expire Time[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[b]Created by[/b] [b][url=http://www.simplemachines.org/community/index.php?action=profile;u=192278].LORD.[/url][/b]
[i][b]SMF 1.1.15 (IN SMF 2.X THIS IS A DEFAULT FEATURE[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Will be displayed the date expire ban in the ban message.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Muestra la fecha en la que expira el ban en el mensaje[/b][/i]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center]
[glow=black,2,300][color=orange][size=12pt][u][b]BEFORE/ANTES:[/b][/u][/size][/color][/glow]
[img]http://i.imgur.com/u1vkJ.png[/img]

[glow=black,2,300][color=orange][size=12pt][u][b]AFTER/DESPUES:[/b][/u][/size][/color][/glow]
[img]http://i.imgur.com/881CQ.png[/img][/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
- Spanish_latin-utf8
- Spanish_es
- Spanish_es-utf8
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]InfoBan - Expire Time[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]