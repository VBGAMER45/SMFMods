[center][img width=443 height=115]http://bit.ly/kZVDB6[/img]

[glow=black,2,300][color=purple][size=16pt][b]Post Group Stars[/b][/size][/color][/glow]
[b]Created by [url=http://www.smfsimple.com/index.php?action=profile;u=2501]Manix[/url] for [url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[b]Developed by [url=http://www.smfsimple.com/index.php?action=profile;u=55]4Kstore[/url] for [url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0 - 2.0.X[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]This mod will display the stars of the post group according to a specific member group. The regular group stars also are displayed.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Este mod mostrar� las estrellas de los grupos basados en el conteo de mensajes y adem�s mostrar� las estrellas de los grupos regulares. Los grupos a los que se les mostrar� las estrellas basados en el conteo de mensajes son especificados por el ID en la area de administraci�n[/b][/i]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow]



[img width=700 height=229]http://img560.imageshack.us/img560/9171/imagen001p.png[/img]


[/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]English & Spanish[/b][/color]
[hr]

[color=purple][size=14pt][b]Settings[/b][/size][/color]
Administration > SMFSimple Rewards System > Likes Comments

[color=red][size=14pt][b]Nota Importante:[/b][/size][/color]
El archivo SsrsLikeCommentsAjax.php debe tener permisos 755 (Se encuentra en el root del servidor. Donde hay archivos como settings.php o index.php del foro)
El MiniMod Utiliza Jquery
El MiniMod necesita la ultima version del sistema SSRS (SMFSimple Rewards System) para funcionar.
Recuerden que si el rango de usuario no tiene permiso para dar puntos, tampoco podra dar likes. 

[color=purple][size=14pt][b]License:[/b][/size][/color]
 * This SMF modification is subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this SMF modification except in compliance with
 * the License. You may obtain a copy of the License at
 * [url=http://www.mozilla.org/MPL/]http://www.mozilla.org/MPL/[/url]

Special thanks to [url=http://www.iconfinder.com]iconfinder.com[/url] for icons!

[center][glow=black,2,300][color=green][size=15pt][b]SSRS Like/Unlike Comments MiniMod[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2012 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]
