*******************************
Hide Unused Profile Display Fields Version 1.0
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 1.1.x

Hides unused profile information on profile display.
For instance if the user does not have ICQ does not show the ICQ field

Other mods at 
http://www.smfhacks.com

SMF Gallery
SMF Store
SMF Classifieds
Download System Pro
EzPortal

