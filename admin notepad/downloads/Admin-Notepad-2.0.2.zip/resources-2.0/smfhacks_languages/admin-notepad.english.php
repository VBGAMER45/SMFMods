<?php
/**
 * Admin Notepad (an_)
 *
 * @file ./smfhacks_languages/admin-notepad.english.php
 * @author SMFHacks <http://www.smfhacks.com/>
 * @copyright SMFHacks.com Team, 2012
 *
 * @version 2.0.2
 */

$txt['admin_notepad'] = array(
	'title' => 'Admin Notepad',
	'desc' => 'Place to leave notes to your fellow admins on your forum.',
	'save' => 'Save Notes',
	'success' => 'Notes successfully saved!'
);