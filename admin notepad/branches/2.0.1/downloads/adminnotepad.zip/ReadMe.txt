*******************************
Admin Notepad
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 1.1.X and SMF 2.0.x

Adds an textbox in the admin main page which allows administrators to leave notes.


Other mods can be found at SMFHacks.com
Include:
SMF Trader System
SMF Gallery
SMF Store
Downloads System
Newsletter Pro
SMF Classifieds
Ad Seller Pro

SMFHacks package server address is:
http://www.smfhacks.com