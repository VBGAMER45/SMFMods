*******************************
Download Attachment Permission
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x

Adds a seperate download and view permission for attachments

Other mods can be found at SMFHacks.com
Include:
SMF Gallery
Newsletter Pro
SMF Store
SMF Classifieds
Downloads System
EzPortal


SMFHacks package server address is:
https://www.smfhacks.com