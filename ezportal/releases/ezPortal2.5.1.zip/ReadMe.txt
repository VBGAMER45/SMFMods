*******************************
EzPortal
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 1.1.x and SMF 2.0.x
A next generation Portal System for SMF

Install Information:
Install via the SMF's Package Manager via upload package.

Icon Credits:
Using the Silk Icons from Fam Fam Fam
http://www.famfamfam.com/lab/icons/silk/


############################################
License Information:
Links to http://www.ezportal.com and http://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
Download System Pro
SMF Store
Newsletter Pro
Ad Seller Pro
Social Login Pro

