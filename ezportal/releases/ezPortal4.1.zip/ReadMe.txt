*******************************
EzPortal
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1 Beta 3 and SMF 2.0.x and SMF 1.1.x
A next generation Portal System for SMF

Install Information:
Install via the SMF's Package Manager via upload package.

Icon Credits:
Using the Silk Icons from Fam Fam Fam
http://www.famfamfam.com/lab/icons/silk/


############################################
License Information:
Links to https://www.ezportal.com and https://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
Download System Pro
SMF Store
Newsletter Pro
Ad Seller Pro
Pretty Urls SEO Pro
