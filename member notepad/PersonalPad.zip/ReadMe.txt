*******************************
Member Notepad
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0 And SMF 1.1.x

Adds an textbox in the user's profile where they can leave notes.


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Downloads System Pro
Newsletter Pro
Ad Seller Pro
EzPortal


SMFHacks package server address is:
http://www.smfhacks.com