*******************************
Global Headers and Footers
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x SMF 1.1.x

Adds an area in your admin panel where you can add headers and footers to every theme.


Other mods can be found at
SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Staff Mod
SMF Trader System
SMF Archive
SMF Classifieds
SMF Store
Newsletter Pro
EzPortal

