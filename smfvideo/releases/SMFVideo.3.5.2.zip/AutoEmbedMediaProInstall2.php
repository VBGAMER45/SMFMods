<?php
/*
Simple Audio Video Embedder
Version 1.0.12
by:vbgamer45
http://www.smfhacks.com

License Information:
Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
*/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
  require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
  die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');


$smcFunc['db_query']('', "CREATE TABLE IF NOT EXISTS {db_prefix}mediapro_sites (
  id int(11) NOT NULL auto_increment,
  title varchar(255),
  enabled tinyint default 0,
  website varchar(255),
  regexmatch text,
  embedcode text,
  processregex text,
  height int(5) default 0,
  width int(5) default 0,

  PRIMARY KEY (id)
) ");


$smcFunc['db_query']('', "REPLACE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(1, 'Youtube','http://www.youtube.com', 'http://[" . '\\' .'\\' . "w.]+youtube" . '\\' .'\\' . ".[" . '\\' .'\\' . "w]+/watch[" . '\\' .'\\' . "?" . '\\' .'\\' . "#!]+v=([" . '\\' .'\\' . "w-]+)[" . '\\' .'\\' . "w&;+=-]*[" . '\\' .'\\' . "#t=]*([" . '\\' .'\\' . "d]*)[&;10wshdq=]*','" . '<object width="640" height="385">
<param name="movie" value="http://www.youtube.com/v/$1&fs=1&start=$2"></param>
<param name="allowFullScreen" value="true"></param>
<embed src="http://www.youtube.com/v/$1&fs=1&start=$2" type="application/x-shockwave-flash" allowfullscreen="true" width="640" height="385" wmode="transparent"></embed></object>' . "'),

(2, 'Metacafe','http://www.metacafe.com', 'http://www" . '\\' .'\\' . ".metacafe" . '\\' .'\\' . ".com/watch/([" . '\\' .'\\' . "w-]+/[" . '\\' .'\\' . "w_]*)[" . '\\' .'\\' . "w&;=" . '\\' .'\\' . "+_" . '\\' .'\\' . "-" . '\\' .'\\' . "/]*','" . '<embed src="http://www.metacafe.com/fplayer/$1.swf" width="540" height="334" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent"></embed>' . "'),

(3, 'Facebook','http://www.facebook.com', 'http://www" . '\\' .'\\' . ".facebook" . '\\' .'\\' . ".com/video/video" . '\\' .'\\' . ".php" . '\\' .'\\' . "?v=([" . '\\' .'\\' . "w]+)&*[" . '\\' .'\\' . "w;=]*','" . '<object width="640" height="385" >
       <param name="allowfullscreen" value="true" />
       <param name="allowscriptaccess" value="always" />
       <param name="movie" value="http://www.facebook.com/v/$1" />
       <embed src="http://www.facebook.com/v/$1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="385"></embed></object>' . "'),

(4, 'Vimeo','http://www.vimeo.com', 'http://[w" . '\\' .'\\' . ".]*vimeo" . '\\' .'\\' . ".com/([" . '\\' .'\\' . "d]+)[" . '\\' .'\\' . "w&;=" . '\\' .'\\' . "?+%/-]*','" . '<object type="application/x-shockwave-flash" width="640" height="385" data="http://vimeo.com/moogaloop.swf?clip_id=$1&amp;server=vimeo.com&amp;fullscreen=1&amp;video_info=1">	<param name="quality" value="best"><param name="allowfullscreen" value="true"><param name="scale" value="showAll"><param name="movie" value="http://vimeo.com/moogaloop.swf?clip_id=$1&amp;server=vimeo.com&amp;fullscreen=1&amp;video_info=1"></object>' . "'),


(5, 'College Humor','http://www.collegehumor.com', 'http://]*[a-z]*?[" . '\\' .'\\' . ".]?collegehumor" . '\\' .'\\' . ".com/video:([0-9]+)','" . '<embed src="http://www.collegehumor.com/moogaloop/moogaloop.swf?clip_id=$1" quality="best" width="640" height="385" type="application/x-shockwave-flash"></embed>' . "'),

(6, 'Google Video', 'http://video.google.com','[http://]*video" . '\\' .'\\' . ".google" . '\\' .'\\' . ".[" . '\\' .'\\' . "w.]+/videoplay" . '\\' .'\\' . "?docid=([-" . '\\' .'\\' . "d]+)[&" . '\\' .'\\' . "w;=" . '\\' .'\\' . "+.-]*','" . '<embed style="width:640px; height:385px;" id="VideoPlayback" type="application/x-shockwave-flash" src="http://video.google.com/googleplayer.swf?docId=$1" flashvars="" wmode="transparent"> </embed>' . "')

");


$smcFunc['db_query']('', "INSERT IGNORE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(7, 'Veoh', 'http://www.veoh.com', 'http://www" . '\\' .'\\' . ".veoh" . '\\' .'\\' . ".com/(.*)/watch/([A-Z0-9]*)','" . '<object width="410" height="341" id="veohFlashPlayer" name="veohFlashPlayer"><param name="movie" value="http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.5.2.1066&permalinkId=$2&player=videodetailsembedded&videoAutoPlay=0&id=anonymous"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.5.2.1066&permalinkId=$2&player=videodetailsembedded&videoAutoPlay=0&id=anonymous" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="410" height="341" id="veohFlashPlayerEmbed" name="veohFlashPlayerEmbed"></embed></object>' . "'),
(8, 'Youku', 'http://www.youku.com', 'http://([A-Z0-9]*).youku.com/v_show/id_([A-Z0-9]*).html','" . '
<embed src="http://player.youku.com/player.php/sid/$2/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"></embed>' . "'),


(9, 'USteam.tv', 'http://www.ustream.tv', 'http://([A-Z0-9]*).ustream.tv/recorded/([0-9]*)','" . '
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="480" height="386" id="utv159159" name="utv_n_278276"><param name="flashvars" value="beginPercent=0.4193&amp;endPercent=0.4316&amp;autoplay=false&locale=en_US" /><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /><param name="src" value="http://www.ustream.tv/flash/video/$2" /><embed flashvars="beginPercent=0.4193&amp;endPercent=0.4316&amp;autoplay=false&locale=en_US" width="480" height="386" allowfullscreen="true" allowscriptaccess="always" id="utv159159" name="utv_n_278276" src="http://www.ustream.tv/flash/video/$2" type="application/x-shockwave-flash" /></object>

' . "')


");



$smcFunc['db_query']('', "INSERT IGNORE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES

(10, 'Rutube', 'http://rutube.ru', 'http://rutube.ru/tracks/([A-Z0-9]*).html" . '\\' .'\\' . "?v=([A-Z0-9]*)','" . '
<OBJECT width="470" height="353"><PARAM name="movie" value="http://video.rutube.ru/$2"></PARAM><PARAM name="wmode" value="window"></PARAM><PARAM name="allowFullScreen" value="true"></PARAM><EMBED src="http://video.rutube.ru/$2" type="application/x-shockwave-flash" wmode="window" width="470" height="353" allowFullScreen="true" ></EMBED></OBJECT>
' . "'),

(11, 'Novamov', 'http://www.novamov.com', 'http://www.novamov.com/video/([A-Z0-9]*)','" . '
<iframe style="overflow: hidden; border: 0; width: 600px; height: 480px" src="http://embed.novamov.com/embed.php?width=600&height=480&v=$1" scrolling="no"></iframe>
' . "'),

(12, 'MyVideo.de', 'http://www.MyVideo.de', 'http://www.myvideo.de/watch/([A-Z0-9]*)/(.*)','" . '
<object style="width:470px;height:285px;" width="470" height="285"><param name="movie" value="http://www.myvideo.de/movie/$1"></param><param name="AllowFullscreen" value="true"></param><param name="AllowScriptAccess" value="always"></param><embed src="http://www.myvideo.de/movie/$1" width="470" height="285" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"></embed></object>
' . "'),

(13, 'LiveLeak', 'http://www.liveleak.com', 'http://www.liveleak.com/view" . '\\' .'\\' . "?i=(.*)','" . '
<object width="450" height="370"><param name="movie" value="http://www.liveleak.com/e/$1"></param><param name="wmode" value="transparent"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.liveleak.com/e/8ee_1281467692" type="application/x-shockwave-flash" wmode="transparent" allowscriptaccess="always" width="450" height="370"></embed></object>

' . "'),


(14, 'Sevenload', 'http://www.sevenload.com', 'http://([A-Z0-9]*).sevenload.com/videos/([A-Z0-9]*)-(.*)','" . '
<object type="application/x-shockwave-flash" data="http://$1.sevenload.com/pl/$2/500x408/swf" width="500" height="408"><param name="allowFullscreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="movie" value="http://$1.sevenload.com/pl/$2/500x408/swf" /></object>

' . "'),

(15, 'Gametrailers', 'http://www.gametrailers.com', 'http://www.gametrailers.com/video/(.*)/([0-9]*)(.*)','" . '
<div style="width: 480px;">
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" id="gtembed" width="480" height="392">	<param name="allowScriptAccess" value="sameDomain" /> <param name="allowFullScreen" value="true" /> <param name="movie" value="http://www.gametrailers.com/remote_wrap.php?mid=$2"/><param name="quality" value="high" /> <embed src="http://www.gametrailers.com/remote_wrap.php?mid=$2" swLiveConnect="true" name="gtembed" align="middle" allowScriptAccess="sameDomain" allowFullScreen="true" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="480" height="392"></embed> </object>
</div>
' . "'),

(16, 'Funnyordie.com', 'http://www.funnyordie.com', 'http://www.funnyordie.com/videos/([A-Z0-9]*)/(.*)','" . '
<object width="480" height="400" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" id="ordie_player_$1"><param name="movie" value="http://player.ordienetworks.com/flash/fodplayer.swf" /><param name="flashvars" value="key=$1" /><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always"></param><embed width="480" height="400" flashvars="key=$1" allowfullscreen="true" allowscriptaccess="always" quality="high" src="http://player.ordienetworks.com/flash/fodplayer.swf" name="ordie_player_$1" type="application/x-shockwave-flash"></embed></object>

' . "'),

(17, 'Mevio', 'http://www.mevio.com', 'http://www.mevio.com/channels/" . '\\' .'\\' . "?cId=([0-9]*)" . '\\' .'\\' . "&amp;mId=([0-9]*)','" . '
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="600" height="336" id="MevioWM" align="middle"><param name="allowScriptAccess" value="never" /><param name="allowFullScreen" value="true" /><param name="movie" value="http://ui.mevio.com/widgets/mwm/MevioWM.swf?r=36745 " /><param name="quality" value="high" /><param name="FlashVars"     value="distribConfig=http://www.mevio.com/widgets/configFiles/distribconfig_mwm_pcw_default.php?r=36745&autoPlay=false&container=false&rssFeed=/%3FcId=$1%26cMediaId=$2%26format=json&playerIdleEnabled=false&fwSiteSection=DistribGeneric" /><param name="bgcolor" value="#000000" />	<embed src="http://ui.mevio.com/widgets/mwm/MevioWM.swf?r=36745 " quality="high" bgcolor="#000000"width="600" height="336" FlashVars="distribConfig=http://www.mevio.com/widgets/configFiles/distribconfig_mwm_pcw_default.php?r=36745&autoPlay=false&container=false&rssFeed=/%3FcId=$1%26cMediaId=$2%26format=json&playerIdleEnabled=false&fwSiteSection=DistribGeneric"name="MevioWM"align="middle"allowScriptAccess="never"allowFullScreen="true"type="application/x-shockwave-flash"pluginspage="http://www.macromedia.com/go/getflashplayer" /></object>

' . "')


");


$smcFunc['db_query']('', "INSERT IGNORE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES

(18, 'Crackle', 'http://www.crackle.com', 'http://www.crackle.com/c/(.*)/(.*)/([0-9]*)','" . '
<embed src="http://www.crackle.com/p/$1/$2.swf" quality="high" bgcolor="#869ca7" width="500" height="281" name="mtgPlayer" align="middle" play="true" loop="false" allowFullScreen="true" flashvars="id=$3&mu=0&ap=0" quality="high" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer"> </embed>

' . "'),

(19, 'justin.tv', 'http://www.justin.tv', 'http://www.justin.tv/([A-Z0-9]*)(.*)','" . '
<object type="application/x-shockwave-flash" height="300" width="400" id="live_embed_player_flash" data="http://www.justin.tv/widgets/live_embed_player.swf?channel=$1" bgcolor="#000000"><param name="allowFullScreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="allowNetworking" value="all" /><param name="movie" value="http://www.justin.tv/widgets/live_embed_player.swf" /><param name="flashvars" value="channel=$1&auto_play=false&start_volume=25" /></object>

' . "'),

(20, 'SchoolTube', 'http://www.schooltube.com', 'http://www.schooltube.com/video/([A-Z0-9]*)/(.*)','" . '
<object width="500" height="375"><param name="movie" value="http://www.schooltube.com/v/$1" /><param name="allowFullScreen" value="true" /><param name="allowscriptaccess" value="always" /><embed src="http://www.schooltube.com/v/16483926ba522476e7ae" type="application/x-shockwave-flash" allowFullScreen="true" allowscriptaccess="always" width="500" height="375" FlashVars="gig_lt=1281633293655&gig_pt=1281633309820&gig_g=2"></embed> <param name="FlashVars" value="gig_lt=1281633293655&gig_pt=1281633309820&gig_g=2" /></object>

' . "'),


(21, 'MySpace', 'http://www.myspace.com', 'http://vids.myspace.com/index.cfm" . '\\' .'\\' . "?fuseaction=vids.individual" . '\\' .'\\' . "&amp;videoid=([0-9]*)','" . '
<object width="425px" height="360px" ><param name="allowFullScreen" value="true"/><param name="wmode" value="transparent"/><param name="movie" value="http://mediaservices.myspace.com/services/media/embed.aspx/m=$1,t=1,mt=video"/><embed src="http://mediaservices.myspace.com/services/media/embed.aspx/m=$1,t=1,mt=video" width="425" height="360" allowFullScreen="true" type="application/x-shockwave-flash" wmode="transparent"></embed></object>

' . "'),

(22, 'Mefeedia', 'http://www.mefeedia.com', 'http://www.mefeedia.com/watch/([0-9]*)','" . '
<iframe scrolling="no" frameborder="0" width="640" height="450" src="http://www.mefeedia.com/watch/$1&iframe"></iframe>
' . "'),


(24, 'DailyMotion', 'http://www.dailymotion.com', 'http://www.dailymotion.com/video/([A-Z0-9]*)_(.*)','" . '
<object width="480" height="360"><param name="movie" value="http://www.dailymotion.com/swf/video/$1?additionalInfos=0"></param><param name="allowFullScreen" value="true"></param><param name="allowScriptAccess" value="always"></param><embed type="application/x-shockwave-flash" src="http://www.dailymotion.com/swf/video/$1?additionalInfos=0" width="480" height="360" allowfullscreen="true" allowscriptaccess="always"></embed></object>
' . "'),


(25, 'Clipfish.de', 'http://www.clipfish.de', 'http://www.clipfish.de/video/([0-9]*)/(.*)/','" . '
<object codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="464" height="384" > <param name="allowScriptAccess" value="always" /> <param name="movie" value="http://www.clipfish.de/cfng/flash/clipfish_player_3.swf?as=0&videoid=$1&r=1&area=e&c=990000" /> <param name="bgcolor" value="#ffffff" /> <param name="allowFullScreen" value="true" /> <embed src="http://www.clipfish.de/cfng/flash/clipfish_player_3.swf?as=0&vid=$1&r=1&area=e&c=990000" quality="high" bgcolor="#990000" width="464" height="384" name="player" align="middle" allowFullScreen="true" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></embed></object>

' . "'),

(26, 'Goear', 'http://www.goear.com', 'http://www.goear.com/listen/([A-Z0-9]*)/(.*)','" . '
<object width="353" height="132"><embed src="http://www.goear.com/files/external.swf?file=$1" type="application/x-shockwave-flash" wmode="transparent" quality="high" width="353" height="132"></embed></object>

' . "'),


(27, 'Clipmoon', 'http://www.clipmoon.com', 'http://www.clipmoon.com/videos/([0-9]*)/(.*).html','" . '
<embed src="http://www.clipmoon.com/flvplayer.swf" FlashVars="config=http://www.clipmoon.com/flvplayer.php?viewkey=$1&external=no" quality="high" bgcolor="#000000" wmode="transparent" width="460" height="357" loop="false" align="middle" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"  scale="exactfit" > </embed>

' . "')


");


// 1.0.4
$smcFunc['db_query']('', "REPLACE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(28, 'Stagevu', 'http://www.stagevu.com', 'http://stagevu.com/video/([A-Z0-9]*)','" . '
<iframe style="overflow: hidden; border: 0; width: 720px; height: 362px" src="http://stagevu.com/embed?width=720&amp;height=306&amp;background=000&amp;uid=$1" scrolling="no"></iframe>
' . "'),
(29, 'Mail.ru', 'http://www.mail.ru', 'http://video.mail.ru/mail/([0-9]*)/([0-9]*)/([0-9]*).html','" . '
<object width=626 height=367><param name="allowScriptAccess" value="always" /><param name="movie" value="http://img.mail.ru/r/video2/player_v2.swf?movieSrc=mail/$1/$2/$3" /><embed src=http://img.mail.ru/r/video2/player_v2.swf?movieSrc=mail/$1/$2/$3 type="application/x-shockwave-flash" width=626 height=367 allowScriptAccess="always"></embed></object>
' . "'),
(30, 'Twitvid', 'http://www.twitvid.com', 'http://www.twitvid.com/([A-Z0-9]*)','" . '
<object width="425" height="344"><param name="movie" value="http://www.twitvid.com/player/$1"></param><param name="allowscriptaccess" value="always"></param><param name="allowFullScreen" value="true"></param><embed type="application/x-shockwave-flash" src="http://www.twitvid.com/player/$1" quality="high" allowscriptaccess="always" allowNetworking="all" allowfullscreen="true" wmode="transparent" height="344" width="425"></object>
' . "'),
(31, 'Trtube', 'http://www.trtube.com', 'http://www.trtube.com/(.*)-([0-9]*).html','" . '
<object width="425" height="350"><param name="allowScriptAccess" value="always"><param name="movie" value="http://www.trtube.com/mediaplayer_3_15.swf?file=http://www.trtube.com/playlist.php?v=$2&image=http://resim.trtube.com/a/102/$2.gif&logo=http://load.trtube.com/img/logoembed.gif&linkfromdisplay=false&linktarget=_blank&autostart=false"><param name="quality" value="high"><param name="bgcolor" value="#ffffff"><param name="allowfullscreen" value="true"><embed src="http://www.trtube.com/mediaplayer_3_15.swf?file=http://www.trtube.com/playlist.php?v=$2&image=http://resim.trtube.com/a/102/$2.gif&logo=http://load.trtube.com/img/logoembed.gif&linkfromdisplay=false&linktarget=_blank&autostart=false" quality="high" bgcolor="#ffffff" allowfullscreen="true" width="450" height="370" name="player" align="middle" type="application/x-shockwave-flash" allowScriptAccess="always" pluginspage="http://www.macromedia.com/go/getflashplayer"></object>
' . "'),
(32, 'BlogTV', 'http://www.blogtv.com', 'http://www.blogtv.com/Shows/([0-9]*)/([A-Z_0-9]*)(.*)','" . '
<embed width="445" height="374" src="http://www.blogtv.com/vb/$2" type="application/x-shockwave-flash" allowFullScreen="true"></embed>
' . "'),
(33, 'MegaVideo', 'http://www.megavideo.com', 'http://(.*)megavideo.com/" . '\\' .'\\' . "?v=([A-Z_0-9]*)','" . '
<object width="640" height="344"><param name="movie" value="http://www.megavideo.com/v/$2.0.0"></param><param name="allowFullScreen" value="true"></param><embed src="http://www.megavideo.com/v/$2.0.0" type="application/x-shockwave-flash" allowfullscreen="true" width="640" height="344"></embed></object>
' . "'),
(34, 'VH1', 'http://www.vh1.com', 'http://www.vh1.com/video/(.*)/([0-9]*)/(.*).jhtml(.*?)','" . '
<embed src="http://media.mtvnservices.com/mgid:uma:video:vh1.com:$2" width="512" height="319" wmode="transparent" type="application/x-shockwave-flash" flashVars="configParams=vid%3D$2%26uri%3Dmgid%3Auma%3Avideo%3Avh1.com%3A$2%26instance%3Dvh1" allowFullScreen="true" allowScriptAccess="always" base="."></embed>
' . "'),
(35, 'BET', 'http://www.bet.com', 'http://www.bet.com/video/([0-9]*)','" . '
<embed src="http://media.mtvnservices.com/mgid:media:video:bet.com:$1" width="512" height="319" wmode="transparent" type="application/x-shockwave-flash" flashVars="" allowFullScreen="true" allowScriptAccess="always" base="."></embed>
' . "')


");      

// 1.0.5

$smcFunc['db_query']('', "REPLACE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(36, 'Espn', 'http://espn.go.com', 'http://espn.go.com/video/clip" . '\\' .'\\' . "?id=([0-9]*)','" . '
<object width="384" height="216" type="application/x-shockwave-flash" id="ESPN_VIDEO" data="http://espn.go.com/videohub/player/embed.swf" allowScriptAccess="always" allowNetworking="all"><param name="movie" value="http://espn.go.com/videohub/player/embed.swf" /><param name="allowFullScreen" value="true"/><param name="wmode" value="opaque"/><param name="allowScriptAccess" value="always"/><param name="allowNetworking" value="all"/><param name="flashVars" value="id=$1"/></object>
' . "'),
(37, 'CNN iReport', 'http://ireport.cnn.com', 'http://ireport.cnn.com/docs/DOC-([0-9]*)','" . '
<object width="400" height="300" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="ep"><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /><param name="movie" value="http://ireport.cnn.com/themes/custom/resources/cvplayer/ireport_embed.swf?player=embed&configPath=http://ireport.cnn.com&playlistId=$1&contentId=$1/0&" /><param name="bgcolor" value="#FFFFFF" /><embed src="http://ireport.cnn.com/themes/custom/resources/cvplayer/ireport_embed.swf?player=embed&configPath=http://ireport.cnn.com&playlistId=$1&contentId=$1/0&" type="application/x-shockwave-flash" bgcolor="#FFFFFF" allowfullscreen="true" allowscriptaccess="always" width="400" height="300"></embed></object>
' . "'),
(38, 'PBS', 'http://video.pbs.org', 'http://video.pbs.org/video/([0-9]*)/','" . '
<object width = "512" height = "328" > <param name = "movie" value = "http://www-tc.pbs.org/video/media/swf/PBSPlayer.swf" > </param><param name="flashvars" value="video=$1&player=viral&chapter=1" /> <param name="allowFullScreen" value="true"></param > <param name = "allowscriptaccess" value = "always" > </param><param name="wmode" value="transparent"></param ><embed src="http://www-tc.pbs.org/video/media/swf/PBSPlayer.swf" flashvars="video=$1&player=viral&chapter=1" type="application/x-shockwave-flash" allowscriptaccess="always" wmode="transparent" allowfullscreen="true" width="512" height="328" bgcolor="#000000"></embed></object>

' . "'),
(39, 'TNT', 'http://www.tnt.tv', 'http://www.tnt.tv/dramavision/index.jsp" . '\\' .'\\' . "?oid=([0-9]*)','" . '
<object width="442" height="375" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="ep"><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /><param name="movie" value="http://i.cdn.turner.com/v5cache/TNT/cvp/tnt_embed.swf?context=embed&videoId=$1" /><param name="bgcolor" "value="#FFFFFF" /><embed src="http://i.cdn.turner.com/v5cache/TNT/cvp/tnt_embed.swf?context=embed&videoId=$1" type="application/x-shockwave-flash" bgcolor="#FFFFFF" allowfullscreen="true" allowscriptaccess="always" width="442" height="375"></embed></object>

' . "'),
(40, 'Comedy Central', 'http://www.comedycentral.com', 'http://www.comedycentral.com/videos/index.jhtml" . '\\' .'\\' . "?videoId=([0-9]*)" . '\\' .'\\' . "&amp;title=(.*)','" . '
<embed style="display:block" src="http://media.mtvnservices.com/mgid:cms:item:comedycentral.com:$1" width="360" height="301" type="application/x-shockwave-flash" wmode="window" allowFullscreen="true" flashvars="autoPlay=false" allowscriptaccess="always" allownetworking="all" bgcolor="#000000"></embed>

' . "'),
(41, 'Stream.cz', 'http://www.stream.cz', 'http://(.*)stream.cz/video/([0-9]*)(.*)','" . '
<object height="382" width="624"><param name="movie" id="VideoSpot" value="http://www.stream.cz/object/$2$3"><param name="allowfullscreen" value="true"><param name="allowscriptaccess" value="always"><param name="wmode" value="transparent"><embed src="http://www.stream.cz/object/$2$3" type="application/x-shockwave-flash" wmode="transparent" allowfullscreen="true" allowscriptaccess="always" height="382" width="624"></object>
' . "')


");

// 1.0.6
$smcFunc['db_query']('', "INSERT IGNORE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES

(42, 'BlogDumpsVideo', 'http://www.blogdumpsvideo.com', 'http://www.blogdumpsvideo.com/action/viewvideo/([0-9]*)/(.*)/','" . '
<embed src="http://www.blogdumpsvideo.com/HDplayer.swf" FlashVars="config=http://www.blogdumpsvideo.com/videoConfigXmlCodeHD.php?pg=video_$1_no_0_extsite&playList=http://www.blogdumpsvideo.com/videoPlaylistXmlCodeHD.php?pg=video_$1" quality="high" bgcolor="#000000" width="600" height="350" name="flvplayer" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" allowFullScreen="true" />
' . "'),
(43, 'Reuters', 'http://www.reuters.com', 'http://www.reuters.com/news/video/story" . '\\' .'\\' . "?videoId=([0-9]*)(.*)','" . '
<object type="application/x-shockwave-flash" data="http://www.reuters.com/resources_v2/flash/video_embed.swf?videoId=$1" width="460" height="259"><param name="movie" value="http://www.reuters.com/resources_v2/flash/video_embed.swf?videoId=$1"></param><param name="allowFullScreen" value="true"></param><param name="allowScriptAccess" value="always"></param><param name="wmode" value="transparent"><embed src="http://www.reuters.com/resources_v2/flash/video_embed.swf?videoId=$1" type="application/x-shockwave-flash" allowfullscreen="true" allowScriptAccess="always" width="460" height="259" wmode="transparent"></embed></object>
' . "'),
(44, 'MarketNewsVideo', 'http://www.marketnewsvideo.com', 'http://www.marketnewsvideo.com/embed/" . '\\' .'\\' . "?id=([A-Z_0-9]*)(.*)','" . '
<iframe src="http://www.marketnewsvideo.com/?id=$1&mv=1&embed=1&width=400&height=320" frameborder="0" width="400" height="320" marginheight="0" marginwidth="0" scrolling="no" name="mnv1282073139"></iframe>
' . "'),
(45, 'Clipsyndicate', 'http://www.clipsyndicate.com', 'http://www.clipsyndicate.com/video/playlist/([0-9]*)/([0-9]*)(.*)','" . '
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="cs_player" width="425" height="330"><param name="movie" value="http://eplayer.clipsyndicate.com/cs_api/get_swf/3/&amp;pl_id=$1&amp;page_count=5&amp;windows=1&amp;show_title=0&amp;va_id=$2&amp;rwpid=273&amp;auto_start=0&amp;auto_next=1" /><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /><embed src="http://eplayer.clipsyndicate.com/cs_api/get_swf/3/&amp;pl_id=$1&amp;page_count=5&amp;windows=1&amp;show_title=0&amp;va_id=$2&amp;rwpid=273&amp;auto_start=0&amp;auto_next=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="425" height="330" /></object>
' . "'),
(46, 'NyTimes', 'http://video.nytimes.com', 'http://video.nytimes.com/video/([0-9]*)/([0-9]*)/([0-9]*)/([A-Z_0-9]*)/([0-9]*)/(.*)','" . '
<iframe width="480" height="373" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" id="nyt_video_player" title="New York Times Video - Embed Player" src="http://graphics8.nytimes.com/bcvideo/1.0/iframe/embed.html?videoId=$5&playerType=embed"></iframe>

' . "')

");


$smcFunc['db_query']('', "INSERT IGNORE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(47, 'Clipshack', 'http://www.clipshack.com', 'http://www.clipshack.com/Clip.aspx" . '\\' .'\\' . "?key=([A-Z0-9]*)','" . '
<embed src="http://www.clipshack.com/player.swf?key=$1" width="430" height="370" wmode="transparent"></embed>
' . "'),
(48, 'Mpora', 'http://video.mpora.com', 'http://video.mpora.com/watch/([A-Z0-9]*)/','" . '
<object id="mpora_$1" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="480" height="315"><param name="movie" value="http://video.mpora.com/p/$1" /><param name="allowfullscreen" value="true" /><embed src="http://video.mpora.com/p/$1" width="480" height="315" allowfullscreen="true"></embed></object>
' . "'),
(49, 'Izlesene.com', 'http://www.izlesene.com', 'http://www.izlesene.com/video/(.*)/([0-9]*)','" . '
<object width="400" height="300"><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /><param name="movie" value="http://www.izlesene.com/embedplayer.swf?video=$2" /><embed src="http://www.izlesene.com/embedplayer.swf?video=$2" wmode="window" bgcolor="#000000" allowfullscreen="true" allowscriptaccess="always" menu="false" scale="noScale" width="400" height="300" type="application/x-shockwave-flash"></embed></object>
' . "'),
(50, 'Rambler.ru', 'http://www.rambler.ru', 'http://vision.rambler.ru/users/([A-Z0-9]*)/([0-9]*)/([0-9]*)/','" . '
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="390" height="370"><param name="wmode" value="transparent"/><param name="allowFullScreen" value="true"/><param name="movie" value="http://vision.rambler.ru/i/e.swf?id=$1/$2/$3&logo=1" /><embed src="http://vision.rambler.ru/i/e.swf?id=$1/$2/$3&logo=1" width="390" height="370" type="application/x-shockwave-flash" wmode="transparent" allowFullScreen="true" /></object>
' . "'),
(51, 'Tangle.com', 'http://www.tangle.com', 'http://www.tangle.com/view_video" . '\\' .'\\' . "?viewkey=([A-Z0-9]*)','" . '
<embed src="http://www.tangle.com/flash/swf/flvplayer.swf" FlashVars="viewkey=$1" wmode="transparent" quality="high" width="330" height="270" name="tangle" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed>
' . "')
");



$smcFunc['db_query']('', "INSERT IGNORE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(52, 'Trophy-clips.com', 'http://www.trophy-clips.com', 'http://www.trophy-clips.com/view_video.php" . '\\' .'\\' . "?viewkey=([A-Z0-9]*)','" . '
<object type="application/x-shockwave-flash" width="390" height="320" wmode="transparent" data="http://www.trophy-clips.com/embedplayer.swf?config=http://www.trophy-clips.com/embedconfig.php?vkey=f3bde58293de74387141">
        <param name="movie" value="http://www.trophy-clips.com/embedplayer.swf?config=http://www.trophy-clips.com/embedconfig.php?vkey=$1" />
        <param name="wmode" value="transparent" />
        <param name="quality" value="high" />
        <param name="menu" value="false" />
		<param name="allowScriptAccess" value="sameDomain" />
		<param name="allowfullscreen" value="true" />
<embed src="http://www.trophy-clips.com/embedplayer.swf" FlashVars="config=http://www.trophy-clips.com/embedconfig.php?vkey=$1" width="390" height="320" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" ></embed>
</object>
' . "'),
(53, 'Yahoo', 'http://video.yahoo.com', 'http://video.yahoo.com/watch/([0-9]*)/([0-9]*)','" . '
 <object width="512" height="322"><param name="movie" value="http://d.yimg.com/static.video.yahoo.com/yep/YV_YEP.swf?ver=2.2.46" /><param name="allowFullScreen" value="true" /><param name="AllowScriptAccess" VALUE="always" /><param name="bgcolor" value="#000000" /><param name="flashVars" value="id=$2&vid=$1&lang=en-us&intl=us&thumbUrl=http%3A//l.yimg.com/a/i/us/sch/cn/video05/$1_rnd3230d645_19.jpg&embed=1" /><embed src="http://d.yimg.com/static.video.yahoo.com/yep/YV_YEP.swf?ver=2.2.46" type="application/x-shockwave-flash" width="512" height="322" allowFullScreen="true" AllowScriptAccess="always" bgcolor="#000000" flashVars="id=$2&vid=$1&lang=en-us&intl=us&thumbUrl=http%3A//l.yimg.com/a/i/us/sch/cn/video05/$1_rnd3230d645_19.jpg&embed=1" ></embed></object>

' . "')
");

$smcFunc['db_query']('', "REPLACE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(54, 'Bungie.net', 'http://www.bungie.net', 'http://www.bungie.net/Silverlight/bungiemediaplayer/embed.aspx" . '\\' .'\\' . "?fid=([0-9]*)','" . '
<iframe src="http://www.bungie.net/Silverlight/bungiemediaplayer/embed.aspx?fid=$1" scrolling="no" style="padding:0;margin:0;border:0;" width="640" height="360" ></iframe>

' . "')
");

// 1.0.10
$smcFunc['db_query']('', "REPLACE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(55, 'XFire', 'http://www.xfire.com', 'http://www.xfire.com/video/([A-Z0-9]*)/','" . '
<object width="380" height="344"><embed src="http://media.xfire.com/swf/embedplayer.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="380" height="344" flashvars="videoid=$1"></embed></object>
' . "'),
(56, 'Worldstarhiphop.com', 'http://www.worldstarhiphop.com', 'http://www.worldstarhiphop.com/videos/video.php" . '\\' .'\\' . "?v=([A-Z0-9]*)','" . '
<object width="448" height="374"><param name="movie" value="http://www.worldstarhiphop.com/videos/e/16711680/$1"><param name="allowFullScreen" value="true"></param><embed src="http://www.worldstarhiphop.com/videos/e/16711680/$1" type="application/x-shockwave-flash" allowFullscreen="true" width="448" height="374"></embed></object>
' . "'),
(57, 'TinyPic.com', 'http://www.tinypic.com', 'http://[" . '\\' .'\\' . "w.]+tinypic.com/player.php" . '\\' .'\\' . "?v=([A-Z0-9]*)" . '\\' .'\\' . "&amp;s=([A-Z0-9]*)','" . '
<embed width="440" height="420" type="application/x-shockwave-flash" src="http://v$2.tinypic.com/player.swf?file=$1&s=$2">
' . "'),
(58, 'JibJab', 'http://www.jibjab.com', 'http://sendables.jibjab.com/view/([A-Za-z0-9]*)','" . '
<object id="A64060" quality="high" data="http://aka.zero.jibjab.com/client/zero/ClientZero_EmbedViewer.swf?external_make_id=$1" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent" height="319" width="425"><param name="wmode" value="transparent"></param><param name="movie" value="http://aka.zero.jibjab.com/client/zero/ClientZero_EmbedViewer.swf?external_make_id=$1"></param><param name="scaleMode" value="showAll"></param><param name="quality" value="high"></param><param name="allowNetworking" value="all"></param><param name="allowFullScreen" value="true" /><param name="FlashVars" value="external_make_id=$1"></param><param name="allowScriptAccess" value="always"></param></object>
' . "'),
(59, 'G4tv', 'http://www.g4tv.com', 'http://g4tv.com/videos/([0-9]*)/([a-zA-Z0-9_" . '\\' .'\\' . ""   . "-]*)/','" . '
<object classId="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="480" height="418" id="VideoPlayerLg$1"><param name="movie" value="http://g4tv.com/lv3/$1" /><param name="allowScriptAccess" value="always" /><param name="allowFullScreen" value="true" /><embed src="http://g4tv.com/lv3/$1" type="application/x-shockwave-flash" name="VideoPlayer" width="480" height="382" allowScriptAccess="always" allowFullScreen="true" /></object>
' . "'),
(60, 'IGN', 'http://www.ign.com', 'http://www.ign.com/videos/([0-9]*)/([0-9]*)/([0-9]*)/([a-zA-Z0-9_=" . '\\' .'\\' . ""  . "-" . '\\' .'\\' . ""  . "?]*)','" . '
<object id="vid" class="ign-videoplayer" width="480" height="270" data="http://media.ign.com/ev/prod/embed.swf" type="application/x-shockwave-flash"><param name="movie" value="http://media.ign.com/ev/prod/embed.swf" /><param name="allowfullscreen" value="true" /><param name="allowscriptaccess" value="always" /><param name="bgcolor" value="#000000" /><param name="flashvars" value="url=http://www.ign.com/videos/$1/$2/$3/$4"/></object>
' . "'),
(61, 'Joystiq', 'http://www.joystiq.com', 'http://www.joystiq.com/video/([a-zA-Z0-9]*)','" . '
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="437" height="266" id="viddler"><param name="movie" value="http://www.viddler.com/simple/$1" /><param name="allowScriptAccess" value="always" /><param name="allowFullScreen" value="true" /><param name="flashvars" value="fake=1"/><embed src="http://www.viddler.com/simple/$1" width="437" height="266" type="application/x-shockwave-flash" allowScriptAccess="always" allowFullScreen="true" flashvars="fake=1" name="viddler" ></embed></object>
' . "')

");

$smcFunc['db_query']('', "REPLACE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(62, 'VideoBB.com', 'http://www.videobb.com/', 'http://www.videobb.com/video/([a-zA-Z0-9]*)','" . '
<object id="vbbplayer" width="425" height="344" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" ><param name="movie" value="http://www.videobb.com/e/$1" ></param><param name="allowFullScreen" value="true" ></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.videobb.com/e/$1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="425" height="344"></embed></object>
' . "')
");


// 1.0.12

$smcFunc['db_query']('', "REPLACE INTO {db_prefix}mediapro_sites
	(ID,title, website, regexmatch, embedcode)
VALUES
(63, 'HostingCup', 'http://www.hostingcup.com/', 'http://www.hostingcup.com/([a-zA-Z0-9]*).html','" . '
<iframe src="http://www.hostingcup.com/embed-$1.html" frameborder="0" marginheight="0" marginheight="0" scrolling="no" width="540" height="416"></iframe>
' . "'),
(64, 'Movshare.net', 'http://www.Movshare.net/', 'http://www.movshare.net/video/([a-zA-Z0-9]*)','" . '
<iframe style="overflow: hidden; border: 0; width: 720px; height: 362px" src="http://www.movshare.net/embed/$1/?width=720&height=306" scrolling="no"></iframe>
' . "'),
(65, 'HostingBulk.com', 'http://www.hostingbulk.com/', 'http://hostingbulk.com/([a-zA-Z0-9]*).html','" . '
<iframe src="http://hostingbulk.com/embed-$1-640x344.html" frameborder="0" marginheight="0" marginheight="0" scrolling="no" width="640" height="344"></iframe>
' . "')

");


?>