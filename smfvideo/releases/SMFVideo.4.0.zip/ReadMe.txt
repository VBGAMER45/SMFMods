SMF Gallery Pro - Video Addon
By: vbgamer45
http://www.smfhacks.com

Allows vidoes to be uploaded to the Gallery System, or inked videos from popular video sharing sites.
Supports: avi,youtube,googlevideo,flv,wmv,mov,mpg

Requires SMF Gallery Pro 1.4 or higher


Other mods.
SMF Store
SMF Classifieds
Downloads System Pro
Newsletter Pro
Ad Seller Pro
EzPortal
