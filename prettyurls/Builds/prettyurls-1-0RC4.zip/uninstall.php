<?php

//	Pretty URLs - Base v0.8.1

//	All I do is disable URL rewriting. If you're uninstalling the mod manually, please just ignore me.

$modSettings['pretty_enable_filters'] = false;

?>
