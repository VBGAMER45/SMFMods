*******************************
Who Quoted Me
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x

Shows the user a list of people that have quoted them.
Has built in option to rebuild quote history for all old posts


Install Information:
Install via the SMF's Package Manager via upload package.


############################################
License Information:
Links to https://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
Download System Pro
SMF Store
Newsletter Pro

