<?php
/*
Who Quoted Me
Version 1.0
by:vbgamer45
https://www.smfhacks.com

License Information:
Links to https://www.smfhacks.com must remain unless
branding free option is purchased.
*/

$txt['whoquoted_txt_settings'] = 'Settings';
$txt['whoquoted_txt_rebuild'] = 'Rebuild';
$txt['whoquoted_txt_settings_desc'] = 'Settings and options for Who Quoted Me';
$txt['whoquoted_txt_savesettings'] = 'Save Settings';
$txt['whoquoted_admin'] = 'Who Quoted Me Settings';


$txt['whoquoted_enabled'] = 'Enable Who Quoted Me System';

$txt['whoquoted_txt_me'] = 'Who Quoted Me';

$txt['whoquoted_txt_rebuild'] = 'Rebuild Who Quoted Me History';

$txt['whoquoted_txt_continue'] = 'Continue';

$txt['whoquoted_txt_date'] = 'Date';

$txt['whoquoted_txt_quoted_by'] = 'Quoted By';

$txt['whoquoted_txt_show_whoquoted'] = 'Show who quoted your posts';

$txt['whoquoted_pages'] = 'Pages: ';

$txt['who_quoted_click_redbuild'] = 'Click here to rebuild quote log history';

?>