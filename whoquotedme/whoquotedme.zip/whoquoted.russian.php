<?php
/*
Who Quoted Me
Version 1.0
by:vbgamer45
https://www.smfhacks.com

License Information:
Links to https://www.smfhacks.com must remain unless
branding free option is purchased.
*/

$txt['whoquoted_txt_settings'] = 'Настройки';
$txt['whoquoted_txt_rebuild'] = 'Пересоздать';
$txt['whoquoted_txt_settings_desc'] = 'Настройки мода "Кто цитировал меня"';
$txt['whoquoted_txt_savesettings'] = 'Сохранить';
$txt['whoquoted_admin'] = 'Настройки "Кто цитировал меня"';


$txt['whoquoted_enabled'] = 'Включить мод "Кто цитировал меня"';

$txt['whoquoted_txt_me'] = 'Кто цитировал меня';

$txt['whoquoted_txt_rebuild'] = 'Пересоздать историю цитирования';

$txt['whoquoted_txt_continue'] = 'Продолжить';

$txt['whoquoted_txt_date'] = 'Дата';

$txt['whoquoted_txt_quoted_by'] = 'Кто';

$txt['whoquoted_txt_show_whoquoted'] = 'Кто цитировал ваши сообщения.';

$txt['whoquoted_pages'] = 'Страницы: ';

$txt['who_quoted_click_redbuild'] = 'Нажмите, чтобы пересоздать историю цитирования';
