*******************************
Tweet Topics/FB Post System
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x and SMF 1.1.x

Tweet topics automaticly tweets selected boards to your Twitter account.
Anytime a new topic is posted a new tweet is posted on Twitter.
Mod supports Twitter's OAuth system and Bitly for link shortening

Must do steps for Tweet Topics:
You need to signup for a twitter app at dev.twitter.com
Step 2 the app must have read and write permissions under the settings tab.
In the settings tab. Change the callbackurl to http://www.yourforum.com/twittercallback.php


Must do steps for FB Post Topics:
You need to create a FB application at https://developers.facebook.com/apps
For Basic Settings do the following
App Domain - Enter the domain name for your forum
Settings under Select how your app integrates with Facebook
Check the "Website" and enter your domain name

Step 2 grab the app id and app secret and fill them out in FB Post Topics Settings and Save
Step 3 click the link in FB Post Topics to get the token to post.
Step 4 Select boards to auto FB post and click Save Facebook Settings


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Newsletter Pro
EzPortal
Downloads Pro
