*******************************
SMF Links
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x and SMF 1.1.x

A links system for SMF.
Links can be added to catagories.
User's can submit links if they are allowed to.
Permission to add links, edit links, delete links, view links, and also manage categories
Category order can be arranged.

Version 2.5.3
!bugfix: Superglobal variable substance checks implemented.
!bugfix: Some invalid XHTML cleaned up.
!bugfix: 2.0 queries now utilize proper sanitation methods.
!bugfix: session verification failed (SMF 1.1.x) due to $context['session_var'] (undefined in 1.1.x) being used.
!enhancement: submit buttons now use SMF styling (class: button_submit).

Version 1.6
Sorting of links on link display.
Added new layout for the admin panel.
Separated settings, categories, category permissions and approve links to their own sections in the admin panel.
Added page listing to approve links.
Added category level permissions for adding, editing, deleting and viewing links.
Added settings to toggle what information is shown on link display
Added Subcategories
Started basic support for Alexa and PageRank still need to make the functions work.

Version 1.5
Updated the mod to use language files
Better Guest add link support
New layout display
Added Image category icon option
You can change the category of a link easier now under edit link
Settings to show information on index and bbc control for link descriptions
Pages setting allows you to show how many links per page in a category


Version 1.2
You can now add links from main page includes category select.
Added who action says they are viewing links.


Version 1.1
Added BBC code is allowed for category titles, and description.
Added Top 5 Links Top 5 Most popular links on main page.
Approval of Links
Link Rating
Links now open in new window.



Other mods can be found at SMFHacks.com
Include:
SMF Trader System
SMF Archive
SMF Staff
SMF Gallery
SMF Store
SMF Classifieds
Newsletter Pro
EzPortal
Downloads Pro


SMFHacks package server address is:
http://www.smfhacks.com