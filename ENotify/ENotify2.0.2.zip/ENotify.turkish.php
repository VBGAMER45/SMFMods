<?php
// ENotify Language 1.0

header('Content-Type: text/html; charset="ISO-8859-9"');

// Frontend strings
$txt['notification_feed'] = 'Bildirim Beslemesi';
$txt['notification_generator'] = 'Simple Machines Forum ��in ENotify Modu';
$txt['notification_pm_sent'] = 'sana bir ki�isel ileti g�nderdi:';
$txt['notification_pm_new'] = 'Yeni Ki�isel �leti';
$txt['notification_reply_sent'] = '�u iletine yan�t yazd�:';
$txt['notification_reply_new'] = 'Yeni �leti Yan�t�';

// Backend strings
$txt['enotify_admin'] = 'ENotify Y�netimi';
$txt['enotify_replies'] = 'Konu yan�t bildirimleri etkin?';
$txt['enotify_pms'] = 'Ki�isel ileti bildirimleri etkin?';
$txt['enotify_refresh'] = 'Bildirimler i�in yenileme aral���:<div class="smalltext"><strong>�nemli:</strong> Bu de�eri �ok d���k girmek sunucunuza zarar verir! (Varsay�lan: 10000 ms {on saniye})</div>';
$txt['enotify_life'] = 'Bildirimlerin ekranda duraca�� s�re:';
$txt['enotify_exp'] = 'Kay�t ��elerinin sistemde tutulaca�� zaman:';

?>