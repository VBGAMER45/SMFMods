*******************************
Push Notifications
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x

Adds push notifications for chrome and firefox using the OneSignal api.
Works for replies and adds support for the following mods
Awesome Post Ratings
@Mentions Mod
Who Quoted Me

Requires an OneSignal account and cURl support for PHP


Install Information:
Install via the SMF's Package Manager via upload package.


############################################
License Information:
Links to https://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
Download System Pro
SMF Store
Newsletter Pro

