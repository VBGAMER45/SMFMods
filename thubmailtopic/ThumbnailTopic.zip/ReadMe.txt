*******************************
Thumbnail Toic Mod
By: vbgamer45/Niko
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x SMF 1.1.x

This mod takes the thumbnail of a topic and adds it on the topic listing page.

Based on Niko's post found in this topic
http://www.simplemachines.org/community/index.php?topic=133417.0



Other mods can be found at SMFHacks.com
Include:
SMF Trader System
SMF Archive
SMF Gallery
SMF Tags
SMF Links
SMF Store
SMF Classifieds
Downloads System Pro
EzPortal
Newsletter Pro


SMFHacks package server address is:
http://www.smfhacks.com