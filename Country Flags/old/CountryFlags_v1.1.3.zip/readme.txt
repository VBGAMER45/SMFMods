[size=16pt]CountryFlags[/size]
[hr]

CountryFlags will allow your members to choose the country and flag that they currently reside or were born. There are a few settings available such as allowing members to select a country on registration, make it mandatory and select it in profile.

[b]Support[/b]
Support for this modification can be found in the support topic.

[b]Thanks[/b]
Thank you to Mark James for his [url=http://famfamfam.com/lab/icons/flags/]famfamfam Flag Icons[/url]

[b]Legal[/b]
famfamfam Icons are free to redistribute and are under public domain.