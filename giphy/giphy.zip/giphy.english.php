<?php
global $editortxt;
$editortxt['scegiphy'] = 'Giphy';

$txt['giphyapikey'] = 'Giphy API Key';
$txt['giphyapikey_extra'] = 'Signup for an API key at <a href="https://developers.giphy.com/" target="_blank">https://developers.giphy.com/</a>';

?>