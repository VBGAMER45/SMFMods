*******************************
Welcome Topic Mod
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x, SMF 2.0.x and SMF 1.1.x

This mod creates a new topic when a user registers on the forum.
If the member requires activation the topic will be created at that time or after the member is approved.
If the member is approved or activated via the admin panel the topic is also created.

Features:
Allows the use of multiple topic texts to be used randomly.
Select which board to post the topic in.
Select which member to post the topic under.



Other mods can be found at SMFHacks.com
Include:
SMF Trader System
SMF Gallery
SMF Links
SMF Store
SMF Classifieds
Newsletter Pro
EzPortal
Ad Seller Pro
Download System Pro


SMFHacks package server address is:
https://www.smfhacks.com