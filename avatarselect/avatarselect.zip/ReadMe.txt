*******************************
Avatar Select
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x And SMF 1.1.x

Adds a avatar select to the user registration page.


Other mods can be found at SMFHacks.com
Include:
SMF Trader System
SMF Archive
SMF Staff
SMF Gallery Pro
SMF Classifieds
SMF Store
Downloads System Pro
EzPortal
Ad Seller Pro

SMFHacks package server address is:
http://www.smfhacks.com