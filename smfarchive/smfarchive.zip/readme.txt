SMF Archive
http://www.smfhacks.com
By:vbgamer45

Requirements: SMF 2.0.X SMF 1.1.x  may work with other versions as well.

Install: Just copy archive.php and archive.css to your forum's root directory and your done!!
Access it via your http://www.yourdomain.com/forums/archive.php for SMF 1.1.X
For SMF 2
Access it via your http://www.yourdomain.com/forums/archive2.php for SMF 2.0.X

License: Links in the template footer must remain. To remove you need to to order copyright removal
http://www.smfhacks.com/copyright_removal.php

Other mods at SMFHacks.com
SMF Gallery
SMF Store
SMF Classifieds
Download System
Newsletter Pro
EzPortal