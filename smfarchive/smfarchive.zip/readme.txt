SMF Archive
https://www.smfhacks.com
By:vbgamer45

Requirements: SMF 2.1.x SMF 2.0.X SMF 1.1.x  may work with other versions as well.

Install via package manager:

For SMF 1.1.
Just copy archive.php and archive.css to your forum's root directory and your done!!
Access it via your http://www.yourdomain.com/forums/archive.php for SMF 1.1.X
For SMF 2.1 and SMF 2.0.x
Access it via your http://www.yourdomain.com/forums/archive2.php for SMF 2.0.X

License: Links in the template footer must remain. To remove you need to order copyright removal
http://www.smfhacks.com/copyright_removal.php

Other mods at SMFHacks.com
SMF Gallery
SMF Store
SMF Classifieds
Download System
Newsletter Pro
EzPortal