<?php
/*
SMF Archive
Version 3.0
by:vbgamer45
https://www.smfhacks.com
Copyright 2008-2023 http://www.samsonsoftware.com
*/

$txt['txt_archive'] = 'Archive';

?>