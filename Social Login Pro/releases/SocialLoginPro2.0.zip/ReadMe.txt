*******************************
Social Login Pro
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x and SMF 1.1.x

Ties together login/registration with the social networking sites. Which will allow users to quickly join your site and join in any discussion. This feature is found on the login page and on the registration page of your site.

Example sites supported:
Facebook, Twitter,Yahoo,Microsoft Messenger,Google,Linked-In,MySpace,AOL,Blogger,WordPress  and more!

Setup Guide can be found on our forums at
http://www.smfhacks.com/index.php/topic,4896.0.html



Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Downloads System
EzPortal.com
Newsletter Pro


SMFHacks package server address is:
http://www.smfhacks.com