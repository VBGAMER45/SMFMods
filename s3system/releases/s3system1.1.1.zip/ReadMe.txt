*******************************
S3 System for SMF
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x and SMF 2.0.x

This modification adds Amazon's S3 support for the attachment system SMF for storing and displaying attachments

Install Instructions:
The modification is installed though SMF's package manager.

Includes:
Settings to enable/disable the system. Bucket, Region, and custom CNAME.
Files are stored securely on Amazon S3 with a private ACL
File links are only valid for one hour via a signed link
Attachments that are deleted are also deleted on S3 if they are linked
Sync system to automatically copy existing attachments to your S3 Bucket
S3 Indicator in attachments section in SMF

############################################
License Information:

Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at
SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
SMF Store
Newsletter Pro
Ad Seller Pro
Download System Pro


