*******************************
Quick Ban on Account Delete
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x and SMF 2.0.x and SMF 1.1.x
Adds delete triggers on delete account for admin. Helpful against spammers

Other mods at 
https://www.smfhacks.com

SMF Gallery
SMF Store
SMF Classifieds
Newsletter Pro
Downloads System Pro
EzPortal.com
AdSeller Pro

