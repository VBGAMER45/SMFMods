*******************************
Download System
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x and SMF 1.1.x

A complete download system for SMF.


Includes:
Uploadable or linked downloads
Approval of downloads option
Reporting of downloads
Option to have comments on an download
Subcategory support
Ability to rate downloads
Who is viewing download or category
Category level permissions by membergroups
File space manager to see which users are using up the most space
Options to control category display settings
Options to control download display settings
Linking code options
Integrates with SMF Shop allows points with adding downloads


############################################
License Information:

Links to http://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at
SMFHacks.com
Include:
SMF Gallery Pro
SMF Staff Mod
SMF Links
SMF Trader System
SMF Archive
SMF Tags
Profile Comments
SMF Classifieds
SMF Store
Newsletter Pro
EzPortal
Downloads Pro
AdSeller Pro

