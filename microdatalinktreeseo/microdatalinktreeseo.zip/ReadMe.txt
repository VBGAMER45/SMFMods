*******************************
MicroData SEO Linktree
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x 
Adds Microdata Breadcrumbs to the linktree

If you are using a custom theme make sure when you install with package manager to select Install on Other Themes!!!!



Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Newsletter Pro
Ad Seller Pro

SMFHacks package server address is:
http://www.smfhacks.com