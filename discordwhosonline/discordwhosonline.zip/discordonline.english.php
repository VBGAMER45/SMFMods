<?php


$txt['discord_online_title'] = 'Discord Who\'s Online';
$txt['discord_online_visit_discord'] = 'Visit Discord Server';

$txt['discord_online_server_id'] = 'Server ID';
$txt['discord_online_server_id_extra'] = 'The server widget must be enabled and the server ID can be found under the channel settings. <a href="https://www.smfhacks.com/images/serverwdiget.png" target="_blank">Screenshot</a>';

$txt['discord_online_enabled'] = 'Discord Who\'s Online Enabled';
$txt['discord_online_show_avatars'] = 'Show Discord Avatars';
$txt['discord_online_cache_minutes'] = 'Cache time in minutes';
$txt['discord_online_server_link'] = 'Discord Server Link';


$txt['discord_online_err_not_configured'] = 'Discord Widget not configured';
$txt['discord_online_err_rate_limited'] = 'Discord Widget rate-limited';
?>