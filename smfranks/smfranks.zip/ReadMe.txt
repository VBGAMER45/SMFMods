*******************************
SMF Ranks Version 1.0
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x SMF 1.1.x
Allows you to have one central location for all your rank images instead of by theme.
Files will be kept at http://www.yoursite.com/ranks/
After mod is installed copy your ranks images to the Ranks folder in your board directory.
Always keep a backup of your files just in case.

Other mods at 
http://www.smfhacks.com

SMF Gallery
SMF Store
SMF Classifieds
Newsletter Pro
Downloads System Pro
EzPortal.com

