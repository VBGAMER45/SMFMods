Tenor for SMF
By: vbgamer45

For: SMF 2.1.x

Adds a fun way to search for animated gifs in the message editor for user posts powered by Tenor!

Please get your own API key at https://tenor.com/gifapi/documentation#quickstart


https://www.smfhacks.com