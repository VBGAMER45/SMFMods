<?php
global $editortxt;
$editortxt['scetenor'] = 'Tenor';

$txt['tenorapikey'] = 'Tenor API Key';
$txt['tenorapikey_extra'] = 'Signup for an API key at <a href="https://developers.google.com/tenor/guides/quickstart" target="_blank">https://developers.google.com/tenor/guides/quickstart</a>';

?>