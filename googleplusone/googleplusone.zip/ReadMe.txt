*******************************
Google +1 on Topics
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x AND SMF 1.1.x

Adds Google +1 to the first post in a topic

Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Newsletter Pro
Ad Seller Pro

SMFHacks package server address is:
http://www.smfhacks.com