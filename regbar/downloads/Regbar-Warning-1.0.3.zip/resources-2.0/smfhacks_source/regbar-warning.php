<?php
/**
 * Regbar Warning (regbar-warning_)
 *
 * @file ./smfhacks_source/regbar-warning.php
 * @author SMFHacks <http://www.smfhacks.com/>
 * @copyright SMFHacks.com Team, 2012
 *
 * @version 1.0.3
 */

if (!defined('SMF'))
	die('Hacking attempt...');

function RegbarWarning()
{
	global $context;
	loadLanguage('smfhacks_languages/regbar-warning');
	loadTemplate('smfhacks_templates/regbar-warning', array('smfhacks_css/regbar-warning'));
	$context['insert_after_template'] .= template_regbar_warning();
}