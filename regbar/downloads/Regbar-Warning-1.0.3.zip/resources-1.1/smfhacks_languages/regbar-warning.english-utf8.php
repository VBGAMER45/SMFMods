﻿<?php
/**
 * Regbar Warning (regbar-warning_)
 *
 * @file ./smfhacks_languages/regbar-warning.english-utf8.php
 * @author SMFHacks <http://www.smfhacks.com/>
 * @copyright SMFHacks.com Team, 2012
 *
 * @version 1.0.3
 */

$txt['regbar_warning'] = array(
	'message' => 'It appears that you have not registered with %s. To register, please click here...'
);