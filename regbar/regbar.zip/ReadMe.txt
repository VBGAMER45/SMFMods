*******************************
Reg Bar
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 1.1.x and SMF 1.0.x and SMF 2.0.x

Adds a registration bar a the top of your page to guests that informs the user to register.



Other mods can be found at SMFHacks.com
Include:
SMF Trader System
SMF Staff
SMF Gallery
SMF Classifieds
SMF Store
SMF Downloads
Newsletter Pro
EzPortal
AdSeller Pro

SMFHacks package server address is:
http://www.smfhacks.com