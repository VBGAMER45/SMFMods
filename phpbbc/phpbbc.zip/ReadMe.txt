*******************************
php BBC Button Version 1.0
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x SMF 1.1.x

Adds a php BBC button to the Post.template.php

Other mods:
SMF Classifieds
SMF Gallery
SMF Store
Downloads System Pro
EzPortal
Newsletter Pro

Can be found at
http://www.smfhacks.com

