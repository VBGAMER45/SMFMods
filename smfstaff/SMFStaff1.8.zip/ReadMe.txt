*******************************
SMF Staff Page
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 1.1.x and SMF 2.0.x

SMF 1.0.x has some support but doesn't include all the features.

Adds a staff page to default template.

Version 1.6.1
Better support for mod_security

Version 1.6
Adds support for additional groups on the staff page.
Changed the display for the admin options on the staff page.

Version 1.5 for SMF 1.1.1 Major Release
Added settings to show information on staf lising.
You can now choose which groups to show on the page and delete groups
You can now display the avatar of a group member.
You can now reorder the categories.
Option to hide local mods display.



Other mods can be found at SMFHacks.com
Include:
SMF Trader System
SMF Gallery
SMF Links
SMF Store
SMF Classifieds
Newsletter Pro
EzPortal
Downloads Pro
Ad Seller Pro


SMFHacks package server address is:
http://www.smfhacks.com