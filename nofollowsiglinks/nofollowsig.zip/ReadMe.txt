*******************************
Nofollow Signature Links
By: vbgamer45
https://www.smfhacks.com
*******************************

For SMF 2.1.x, SMF 2.0.x and SMF 1.1.x


This mod makes any signature link a nofollow link. This reduces the value of links for SEO spammers


Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Trader System
SMF Links
SMF Classifieds
NewsLetter Pro
SMF Store
EzPortal
Downloads System Pro
Community Suite
Ad Seller Pro

SMFHacks package server address is:
https://www.smfhacks.com