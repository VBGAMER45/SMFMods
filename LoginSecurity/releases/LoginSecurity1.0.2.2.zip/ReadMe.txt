*******************************
Login Security
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x and SMF 1.1.x

Login security system. Adds extra protection against multiple login attempts.
Has the option to restrict login by ip address

Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Classifieds
Downloads System
EzPortal.com


SMFHacks package server address is:
http://www.smfhacks.com