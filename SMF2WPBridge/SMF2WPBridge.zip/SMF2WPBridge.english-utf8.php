<?php
$txt['smf2wp_admin'] = 'SMF2WPBridge';
$txt['smf2wp_wp_path'] = 'WP folder path';
$txt['smf2wp_error'] = 'Your WP path is invalid! could not locate wp-config.php';

$txt['smf2wp_addon'] = 'Wordpress to <a href="https://www.smfhacks.com/WP2SMFBridge.zip" target="_blank">SMF Addon Download</a>';

?>