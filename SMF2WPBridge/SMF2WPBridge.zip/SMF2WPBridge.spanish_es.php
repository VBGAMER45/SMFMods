<?php
$txt['smf2wp_admin'] = 'SMF2WPBridge';
$txt['smf2wp_wp_path'] = 'Ruta de la carpeta de WP';
$txt['smf2wp_error'] = 'Su ruta a WP no es válida! no se pudo localizar wp-config.php';

$txt['smf2wp_addon'] = 'Wordpress to <a href="https://www.smfhacks.com/WP2SMFBridge.zip" target="_blank">SMF Addon Download</a>';

?>