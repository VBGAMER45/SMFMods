<?php
$txt['smf2wp_admin'] = 'SMF2WPBridge';
$txt['smf2wp_wp_path'] = 'Ścieżka do folderu WP';
$txt['smf2wp_error'] = 'Twoja ścieżka do WP jest nieprawidłowa! Nie można zlokalizować wp-config.php';

$txt['smf2wp_addon'] = 'Pobierz wtyczkę <a href="https://www.smfhacks.com/WP2SMFBridge.zip" target="_blank">WP2SMFBridge do WordPressa</a>';

?>