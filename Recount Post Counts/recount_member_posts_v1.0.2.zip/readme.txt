[size=16pt]Recount Member Posts[/size] 
[hr]

This mod will allow the admin to recount every members post counts back to their respective numbers. Due to a variety of mods as well as human who can manipulate members' post counts, this mod may serve many well for when they wish to reset their forums.


[b]Thanks[/b]
Thank you for installing this mod