*******************************
Bluesky Auto Embed
Packaged By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x and SMF 2.0.x

Auto embeds Bluesky. Caches Bluesky posts to reduce requests.

Install Information:
Install via the SMF's Package Manager via upload package.


Other mods can be found at SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
Download System Pro
SMF Store
Newsletter Pro

Licensed under: https://creativecommons.org/licenses/by-nd/4.0/ Attribution-NoDerivs
CC BY-ND 