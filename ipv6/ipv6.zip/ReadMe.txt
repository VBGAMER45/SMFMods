*******************************
IPv6
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x



############################################
License Information:

Links to https://www.smfhacks.com must remain unless
branding free option is purchased.
#############################################

Other mods can be found at
SMFHacks.com
Include:
SMF Gallery Pro
SMF Classifieds
SMF Store
Newsletter Pro
EzPortal
Downloads Pro
AdSeller Pro

